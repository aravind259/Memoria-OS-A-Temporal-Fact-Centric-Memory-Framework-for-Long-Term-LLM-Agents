"""
Memoria PDF Documentation Builder
Renders the complete 25-chapter specification into an enterprise-grade,
publication-quality PDF document using ReportLab.
"""

import os
import re
import html
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether, Preformatted
)
from reportlab.pdfgen import canvas

from generate_doc_text import get_all_chapters, get_glossary, get_table_of_contents

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

class NumberedCanvas(canvas.Canvas):
    """
    Two-pass canvas to dynamically compute and print 'Page X of Y' footers
    and running top header rule across all pages except the cover page.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_decorations(num_pages)
            super().showPage()
        super().save()

    def draw_page_decorations(self, page_count):
        if self._pageNumber == 1:
            # Suppress running header/footer on Title Cover Page
            return

        self.saveState()
        self.setFont("Helvetica-Bold", 8)
        self.setFillColor(colors.HexColor("#64748B"))

        # Running Top Header
        self.drawString(40, letter[1] - 32, "MEMORIA: Scalable Agentic Memory Framework for Personalized Conversational AI")
        self.setStrokeColor(colors.HexColor("#CBD5E1"))
        self.setLineWidth(0.5)
        self.line(40, letter[1] - 38, letter[0] - 40, letter[1] - 38)

        # Running Bottom Footer
        self.setFont("Helvetica", 8)
        self.drawString(40, 28, "Confidential & Proprietary — Research & Technical Specification Report")
        page_str = f"Page {self._pageNumber} of {page_count}"
        self.drawRightString(letter[0] - 40, 28, page_str)
        self.line(40, 38, letter[0] - 40, 38)

        self.restoreState()

def clean_for_reportlab(text):
    """
    Converts markdown bold/italics and escapes raw XML characters for ReportLab Paragraph.
    """
    # First escape ampersands that aren't entities
    text = re.sub(r'&(?!amp;|lt;|gt;|quot;|#\d+;)', '&amp;', text)
    # Escape standalone < and >
    text = text.replace("<=", "&lt;=").replace(">=", "&gt;=")
    # Handle bold **text**
    text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
    # Handle italic *text*
    text = re.sub(r'(?<!\*)\*(?!\*)(.*?)(?<!\*)\*(?!\*)', r'<i>\1</i>', text)
    # Handle inline code `code`
    text = re.sub(r'`(.*?)`', r'<font face="Courier" color="#1E3A8A"><b>\1</b></font>', text)
    return text

def build_pdf_report(output_path):
    print(f"[PdfBuilder] Building publication-quality PDF report: {output_path}...")
    doc = SimpleDocTemplate(
        output_path,
        pagesize=letter,
        leftMargin=40,
        rightMargin=40,
        topMargin=46,
        bottomMargin=46
    )

    styles = getSampleStyleSheet()

    # Custom Typography Palette
    title_style = ParagraphStyle(
        'CoverTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=24,
        leading=28,
        textColor=colors.HexColor("#0F172A"),
        alignment=1, # Center
        spaceAfter=12
    )

    subtitle_style = ParagraphStyle(
        'CoverSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=11,
        leading=15,
        textColor=colors.HexColor("#475569"),
        alignment=1, # Center
        spaceAfter=20
    )

    h1_style = ParagraphStyle(
        'DocH1',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=16,
        leading=20,
        textColor=colors.HexColor("#0F172A"),
        spaceBefore=14,
        spaceAfter=8,
        keepWithNext=True
    )

    h2_style = ParagraphStyle(
        'DocH2',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor("#1E3A8A"),
        spaceBefore=12,
        spaceAfter=6,
        keepWithNext=True
    )

    h3_style = ParagraphStyle(
        'DocH3',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#334155"),
        spaceBefore=8,
        spaceAfter=4,
        keepWithNext=True
    )

    body_style = ParagraphStyle(
        'DocBody',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=11.5,
        textColor=colors.HexColor("#1E293B"),
        spaceAfter=5
    )

    bullet_style = ParagraphStyle(
        'DocBullet',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=11.5,
        leftIndent=15,
        textColor=colors.HexColor("#1E293B"),
        spaceAfter=3
    )

    code_style = ParagraphStyle(
        'DocCode',
        parent=styles['Normal'],
        fontName='Courier',
        fontSize=6.8,
        leading=8.2,
        backColor=colors.HexColor("#F1F5F9"),
        borderColor=colors.HexColor("#CBD5E1"),
        borderWidth=0.5,
        borderPadding=6,
        leftIndent=6,
        rightIndent=6,
        spaceBefore=4,
        spaceAfter=6,
        textColor=colors.HexColor("#0F172A")
    )

    th_style = ParagraphStyle(
        'DocTH',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8.0,
        leading=10.0,
        textColor=colors.white
    )

    td_style = ParagraphStyle(
        'DocTD',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=7.5,
        leading=9.5,
        textColor=colors.HexColor("#1E293B")
    )

    story = []

    # 1. TITLE COVER PAGE
    story.append(Spacer(1, 25))
    story.append(Paragraph("ACADEMIC &amp; TECHNICAL RESEARCH REPORT", ParagraphStyle(
        'PreHeader', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=10, leading=12,
        textColor=colors.HexColor("#1E3A8A"), alignment=1, spaceAfter=14
    )))
    story.append(Paragraph("MEMORIA<br/>A Scalable Agentic Memory Framework for Personalized Conversational AI", title_style))
    story.append(Paragraph("Comprehensive Architectural Specification, Mathematical Formulations, Implementation Analysis, and Empirical Evaluation", subtitle_style))
    story.append(Spacer(1, 10))

    # Title Page Metadata Table
    meta_data = [
        [Paragraph("<b>Project Attribute</b>", th_style), Paragraph("<b>System Specification Details</b>", th_style)],
        [Paragraph("Project Title", td_style), Paragraph("Memoria: Agentic Memory Operating System (AI-MOS)", td_style)],
        [Paragraph("Target Domain", td_style), Paragraph("Artificial Intelligence / Long-Term Conversational Memory / Cognitive Agents", td_style)],
        [Paragraph("Storage Architecture", td_style), Paragraph("Tri-Tier: L1 Working Memory (RAM) / L2 Active (ChromaDB) / L3 Cold (SQLite)", td_style)],
        [Paragraph("Decay Engine", td_style), Paragraph("Adaptive Ebbinghaus Exponential Decay with Category Weights & Rehearsal", td_style)],
        [Paragraph("Reconciliation Model", td_style), Paragraph("Atomic Lineage Tracking with Deterministic Contradiction Supersession", td_style)],
        [Paragraph("Hybrid Ranker", td_style), Paragraph("4-Factor Interpolation (0.45 Vector + 0.20 BM25 + 0.25 Decay + 0.10 Importance)", td_style)],
        [Paragraph("Relational Pipeline", td_style), Paragraph("V2 Structured Facts with Cardinality Constraints ('one' vs 'many') & Raw-Turn Fallback", td_style)],
        [Paragraph("REST Microservice", td_style), Paragraph("FastAPI / Uvicorn Asynchronous Service with Health & Admin Endpoints", td_style)],
        [Paragraph("Test Suite Result", td_style), Paragraph("<b>100.0% Pass Rate</b> across 9 Automated Verification Suites", td_style)]
    ]
    t_meta = Table(meta_data, colWidths=[160, 370])
    t_meta.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#1E3A8A")),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor("#F8FAFC")]),
    ]))
    story.append(t_meta)
    story.append(PageBreak())

    # 2. TABLE OF CONTENTS
    story.append(Paragraph("Table of Contents", h1_style))
    story.append(Spacer(1, 8))
    toc_data = [[Paragraph("<b>Chapter / Section</b>", th_style), Paragraph("<b>Title &amp; Subject Matter Scope</b>", th_style)]]
    for ch_num, ch_title in get_table_of_contents():
        toc_data.append([
            Paragraph(f"<b>{ch_num}</b>", td_style),
            Paragraph(html.escape(ch_title), td_style)
        ])
    t_toc = Table(toc_data, colWidths=[130, 400])
    t_toc.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#1E3A8A")),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3),
        ('TOPPADDING', (0,0), (-1,-1), 3),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor("#F8FAFC")]),
    ]))
    story.append(t_toc)
    story.append(PageBreak())

    # 3. CHAPTERS 1 TO 25
    chapters = get_all_chapters()
    for idx, ch in enumerate(chapters):
        if idx > 0:
            story.append(PageBreak())

        lines = ch["content"].split("\n")
        in_code = False
        code_buf = []
        in_table = False
        table_raw_rows = []

        for line in lines:
            stripped = line.strip()

            # Code Block Toggle
            if stripped.startswith("```"):
                if in_code:
                    raw_code = "\n".join(code_buf)
                    code_para = Preformatted(raw_code, code_style)
                    story.append(code_para)
                    code_buf = []
                    in_code = False
                else:
                    in_code = True
                continue

            if in_code:
                code_buf.append(line)
                continue

            # Markdown Table parsing
            if "|" in line and not in_code:
                if not in_table:
                    in_table = True
                    cols = [c.strip() for c in stripped.split("|")[1:-1]]
                    table_raw_rows = [cols]
                    continue
                elif in_table and ("---" in stripped or ":---" in stripped):
                    continue
                elif in_table and stripped.startswith("|"):
                    cols = [c.strip() for c in stripped.split("|")[1:-1]]
                    table_raw_rows.append(cols)
                    continue
            else:
                if in_table:
                    # Flush table to story
                    if table_raw_rows:
                        num_cols = len(table_raw_rows[0])
                        col_w = 530.0 / max(1, num_cols)
                        table_data = []
                        for r_i, r in enumerate(table_raw_rows):
                            row_cells = []
                            for c in r:
                                if r_i == 0:
                                    row_cells.append(Paragraph(clean_for_reportlab(c), th_style))
                                else:
                                    row_cells.append(Paragraph(clean_for_reportlab(c), td_style))
                            table_data.append(row_cells)

                        tbl = Table(table_data, colWidths=[col_w]*num_cols)
                        tbl.setStyle(TableStyle([
                            ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#1E3A8A")),
                            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
                            ('TOPPADDING', (0,0), (-1,-1), 3),
                            ('BOTTOMPADDING', (0,0), (-1,-1), 3),
                            ('LEFTPADDING', (0,0), (-1,-1), 5),
                            ('RIGHTPADDING', (0,0), (-1,-1), 5),
                            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
                            ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor("#F8FAFC")]),
                        ]))
                        story.append(Spacer(1, 4))
                        story.append(tbl)
                        story.append(Spacer(1, 4))
                    in_table = False
                    table_raw_rows = []

            # Headings & Text
            if stripped.startswith("# "):
                story.append(Paragraph(clean_for_reportlab(stripped[2:].strip()), h1_style))
            elif stripped.startswith("## "):
                story.append(Paragraph(clean_for_reportlab(stripped[3:].strip()), h2_style))
            elif stripped.startswith("### "):
                story.append(Paragraph(clean_for_reportlab(stripped[4:].strip()), h3_style))
            elif stripped.startswith("- ") or stripped.startswith("* "):
                bullet_txt = clean_for_reportlab(stripped[2:].strip())
                story.append(Paragraph(f"&bull;&nbsp;&nbsp;{bullet_txt}", bullet_style))
            elif stripped.startswith("> "):
                quote_txt = clean_for_reportlab(stripped[2:].strip())
                story.append(Paragraph(f"<i>{quote_txt}</i>", ParagraphStyle(
                    'DocQuote', parent=body_style, leftIndent=15, textColor=colors.HexColor("#475569")
                )))
            elif stripped == "" or stripped == "---":
                continue
            else:
                story.append(Paragraph(clean_for_reportlab(stripped), body_style))

        # Flush any remaining table at end of chapter
        if in_table and table_raw_rows:
            num_cols = len(table_raw_rows[0])
            col_w = 530.0 / max(1, num_cols)
            table_data = []
            for r_i, r in enumerate(table_raw_rows):
                row_cells = []
                for c in r:
                    if r_i == 0:
                        row_cells.append(Paragraph(clean_for_reportlab(c), th_style))
                    else:
                        row_cells.append(Paragraph(clean_for_reportlab(c), td_style))
                table_data.append(row_cells)
            tbl = Table(table_data, colWidths=[col_w]*num_cols)
            tbl.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#1E3A8A")),
                ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
                ('TOPPADDING', (0,0), (-1,-1), 3),
                ('BOTTOMPADDING', (0,0), (-1,-1), 3),
                ('LEFTPADDING', (0,0), (-1,-1), 5),
                ('RIGHTPADDING', (0,0), (-1,-1), 5),
                ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
                ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor("#F8FAFC")]),
            ]))
            story.append(tbl)

    # 4. APPENDIX: GLOSSARY
    story.append(PageBreak())
    story.append(Paragraph("Appendix A: Glossary of Important Technical Terms", h1_style))
    story.append(Spacer(1, 8))
    glossary_data = [[Paragraph("<b>Technical Term</b>", th_style), Paragraph("<b>Definition &amp; System Context</b>", th_style)]]
    for term, definition in get_glossary():
        glossary_data.append([
            Paragraph(f"<b>{clean_for_reportlab(term)}</b>", td_style),
            Paragraph(clean_for_reportlab(definition), td_style)
        ])
    t_glossary = Table(glossary_data, colWidths=[150, 380])
    t_glossary.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#1E3A8A")),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor("#F8FAFC")]),
    ]))
    story.append(t_glossary)

    # Build Document with NumberedCanvas
    doc.build(story, canvasmaker=NumberedCanvas)
    print(f"[PdfBuilder] Successfully generated: {output_path} ({os.path.getsize(output_path)} bytes)")

if __name__ == "__main__":
    out_file = os.path.join(CURRENT_DIR, "Memoria_Documentation.pdf")
    build_pdf_report(out_file)
