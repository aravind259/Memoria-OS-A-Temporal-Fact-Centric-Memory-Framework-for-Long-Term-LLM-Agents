"""
Memoria DOCX Documentation Builder
Renders the complete 25-chapter specification into an enterprise-grade,
professionally styled Word Document (DOCX).
"""

import os
import re
import docx
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

from generate_doc_text import get_all_chapters, get_glossary, get_table_of_contents

def set_cell_background(cell, hex_color):
    shading_xml = f'<w:shd {nsdecls("w")} w:fill="{hex_color}"/>'
    cell._tc.get_or_add_tcPr().append(parse_xml(shading_xml))

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/><w:bottom w:w="{bottom}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/><w:right w:w="{right}" w:type="dxa"/></w:tcMar>')
    tcPr.append(tcMar)

def create_styled_table(doc, headers, data_rows, col_widths=None):
    table = doc.add_table(rows=len(data_rows) + 1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False

    # Header Row
    hdr_cells = table.rows[0].cells
    for i, title in enumerate(headers):
        hdr_cells[i].text = title
        set_cell_background(hdr_cells[i], "1E3A8A")
        set_cell_margins(hdr_cells[i], 120, 120, 150, 150)
        p = hdr_cells[i].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        for run in p.runs:
            run.font.bold = True
            run.font.color.rgb = RGBColor(255, 255, 255)
            run.font.name = "Calibri"
            run.font.size = Pt(9.5)

    # Data Rows
    for r_idx, row in enumerate(data_rows):
        row_cells = table.rows[r_idx + 1].cells
        bg_color = "F8FAFC" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(row):
            row_cells[c_idx].text = str(val).strip()
            set_cell_background(row_cells[c_idx], bg_color)
            set_cell_margins(row_cells[c_idx], 80, 80, 120, 120)
            p = row_cells[c_idx].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            for run in p.runs:
                run.font.name = "Calibri"
                run.font.size = Pt(9.0)
                run.font.color.rgb = RGBColor(30, 41, 59)

    # Apply column widths if provided
    if col_widths and len(col_widths) == len(headers):
        for row in table.rows:
            for i, w in enumerate(col_widths):
                row.cells[i].width = Inches(w)

    doc.add_paragraph() # Spacing
    return table

def add_code_block(doc, code_text):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.cell(0, 0)
    set_cell_background(cell, "F1F5F9")
    set_cell_margins(cell, 120, 120, 180, 180)
    cell.width = Inches(6.5)

    p = cell.paragraphs[0]
    p.paragraph_format.line_spacing = 1.05
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run(code_text.strip())
    run.font.name = "Consolas"
    run.font.size = Pt(8.5)
    run.font.color.rgb = RGBColor(15, 23, 42)

    doc.add_paragraph() # Spacing

def render_markdown_section(doc, markdown_text):
    lines = markdown_text.split("\n")
    in_code_block = False
    code_lines = []
    in_table = False
    table_headers = []
    table_rows = []

    for line in lines:
        stripped = line.strip()

        # Code Block Toggle
        if stripped.startswith("```"):
            if in_code_block:
                add_code_block(doc, "\n".join(code_lines))
                code_lines = []
                in_code_block = False
            else:
                in_code_block = True
            continue

        if in_code_block:
            code_lines.append(line)
            continue

        # Markdown Table Detection
        if "|" in line and not in_code_block:
            if not in_table:
                # First line is header
                in_table = True
                cols = [c.strip() for c in stripped.split("|")[1:-1]]
                table_headers = cols
                table_rows = []
                continue
            elif in_table and ("---" in stripped or ":---" in stripped):
                # Separator line, ignore
                continue
            elif in_table and stripped.startswith("|"):
                cols = [c.strip() for c in stripped.split("|")[1:-1]]
                table_rows.append(cols)
                continue
        else:
            if in_table:
                create_styled_table(doc, table_headers, table_rows)
                in_table = False
                table_headers = []
                table_rows = []

        # Headings
        if stripped.startswith("# "):
            # Heading 1 already added per chapter, or add if standalone
            continue
        elif stripped.startswith("## "):
            h = doc.add_heading(stripped[3:].strip(), level=2)
            h.paragraph_format.space_before = Pt(14)
            h.paragraph_format.space_after = Pt(6)
            for run in h.runs:
                run.font.name = "Calibri"
                run.font.color.rgb = RGBColor(15, 23, 42)
                run.font.size = Pt(14)
                run.font.bold = True
        elif stripped.startswith("### "):
            h = doc.add_heading(stripped[4:].strip(), level=3)
            h.paragraph_format.space_before = Pt(10)
            h.paragraph_format.space_after = Pt(4)
            for run in h.runs:
                run.font.name = "Calibri"
                run.font.color.rgb = RGBColor(30, 58, 138)
                run.font.size = Pt(11.5)
                run.font.bold = True
        elif stripped.startswith("- ") or stripped.startswith("* "):
            p = doc.add_paragraph(style='List Bullet')
            p.paragraph_format.space_after = Pt(3)
            bullet_text = stripped[2:].strip()
            # Handle bold inside bullet
            parts = re.split(r'(\*\*.*?\*\*)', bullet_text)
            for part in parts:
                if part.startswith("**") and part.endswith("**"):
                    r = p.add_run(part[2:-2])
                    r.font.bold = True
                else:
                    r = p.add_run(part)
                r.font.name = "Calibri"
                r.font.size = Pt(10)
        elif stripped.startswith("> "):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.4)
            p.paragraph_format.space_after = Pt(4)
            r = p.add_run(stripped[2:].strip())
            r.font.italic = True
            r.font.color.rgb = RGBColor(71, 85, 105)
            r.font.size = Pt(9.5)
        elif stripped == "" or stripped == "---":
            continue
        else:
            p = doc.add_paragraph()
            p.paragraph_format.space_after = Pt(5)
            p.paragraph_format.line_spacing = 1.15
            # Handle bold formatting in paragraph
            parts = re.split(r'(\*\*.*?\*\*)', stripped)
            for part in parts:
                if part.startswith("**") and part.endswith("**"):
                    r = p.add_run(part[2:-2])
                    r.font.bold = True
                else:
                    r = p.add_run(part)
                r.font.name = "Calibri"
                r.font.size = Pt(10)
                r.font.color.rgb = RGBColor(30, 41, 59)

    # If document ends inside table
    if in_table:
        create_styled_table(doc, table_headers, table_rows)

def build_docx_report(output_path):
    print(f"[DocxBuilder] Building professional Word report: {output_path}...")
    doc = Document()

    # Configure Margins (0.8 inches all around)
    for section in doc.sections:
        section.top_margin = Inches(0.8)
        section.bottom_margin = Inches(0.8)
        section.left_margin = Inches(0.8)
        section.right_margin = Inches(0.8)

    # 1. TITLE PAGE
    p_pre = doc.add_paragraph()
    p_pre.paragraph_format.space_before = Pt(36)
    p_pre.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_pre = p_pre.add_run("ACADEMIC & TECHNICAL RESEARCH REPORT")
    r_pre.font.name = "Calibri"
    r_pre.font.size = Pt(11)
    r_pre.font.bold = True
    r_pre.font.color.rgb = RGBColor(30, 58, 138)

    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_title.paragraph_format.space_before = Pt(12)
    p_title.paragraph_format.space_after = Pt(12)
    r_title = p_title.add_run("MEMORIA\nA Scalable Agentic Memory Framework for Personalized Conversational AI")
    r_title.font.name = "Calibri"
    r_title.font.size = Pt(24)
    r_title.font.bold = True
    r_title.font.color.rgb = RGBColor(15, 23, 42)

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_sub.paragraph_format.space_after = Pt(28)
    r_sub = p_sub.add_run("Comprehensive Architectural Specification, Mathematical Formulations, Implementation Analysis, and Empirical Evaluation")
    r_sub.font.name = "Calibri"
    r_sub.font.size = Pt(12)
    r_sub.font.italic = True
    r_sub.font.color.rgb = RGBColor(71, 85, 105)

    # Metadata Table
    meta_headers = ["Project Attribute", "System Specification"]
    meta_rows = [
        ["Project Name", "Memoria: Agentic Memory Operating System (AI-MOS)"],
        ["Primary Domain", "Artificial Intelligence / Conversational NLP / Cognitive Agents"],
        ["Architecture", "Tri-Tier Hierarchy (L1 Working RAM / L2 ChromaDB / L3 SQLite)"],
        ["Decay Model", "Adaptive Ebbinghaus Retention Decay with Category Weights & Rehearsal"],
        ["Reconciliation", "Atomic Lineage Tracking & Semantic Contradiction Supersession"],
        ["Retrieval Engine", "4-Factor Hybrid (0.45 Vector + 0.20 BM25 + 0.25 Decay + 0.10 Importance)"],
        ["Relational Pipeline", "V2 Structured Facts with Cardinality Constraints & Raw-Turn Fallback"],
        ["Core API Framework", "FastAPI / Uvicorn (Asynchronous REST Microservice)"],
        ["Target Foundation LLM", "Google Gemini 3 Flash / Gemini 3.1 Flash-Lite (Google GenAI SDK)"],
        ["Evaluation Pass Rate", "100.0% Pass Rate across 9 Automated Verification Suites"]
    ]
    create_styled_table(doc, meta_headers, meta_rows, col_widths=[2.4, 4.1])

    doc.add_page_break()

    # 2. TABLE OF CONTENTS
    h_toc = doc.add_heading("Table of Contents", level=1)
    h_toc.paragraph_format.space_after = Pt(12)
    for run in h_toc.runs:
        run.font.name = "Calibri"
        run.font.color.rgb = RGBColor(15, 23, 42)
        run.font.bold = True

    toc_headers = ["Chapter Number", "Chapter Title & Scope"]
    toc_rows = []
    for ch_num, ch_title in get_table_of_contents():
        toc_rows.append([ch_num, ch_title])
    create_styled_table(doc, toc_headers, toc_rows, col_widths=[2.0, 4.5])

    doc.add_page_break()

    # 3. CHAPTERS 1 TO 25
    chapters = get_all_chapters()
    for idx, ch in enumerate(chapters):
        if idx > 0:
            doc.add_page_break()

        # Heading 1 for Chapter
        h1 = doc.add_heading(ch["title"], level=1)
        h1.paragraph_format.space_before = Pt(18)
        h1.paragraph_format.space_after = Pt(12)
        for run in h1.runs:
            run.font.name = "Calibri"
            run.font.color.rgb = RGBColor(15, 23, 42)
            run.font.bold = True
            run.font.size = Pt(18)

        render_markdown_section(doc, ch["content"])

    # 4. APPENDIX: GLOSSARY
    doc.add_page_break()
    h_app = doc.add_heading("Appendix A: Glossary of Important Technical Terms", level=1)
    h_app.paragraph_format.space_before = Pt(18)
    h_app.paragraph_format.space_after = Pt(12)
    for run in h_app.runs:
        run.font.name = "Calibri"
        run.font.color.rgb = RGBColor(15, 23, 42)
        run.font.bold = True
        run.font.size = Pt(18)

    glossary_headers = ["Technical Term", "Definition & System Context"]
    glossary_rows = get_glossary()
    create_styled_table(doc, glossary_headers, glossary_rows, col_widths=[2.2, 4.3])

    doc.save(output_path)
    print(f"[DocxBuilder] Successfully generated: {output_path} ({os.path.getsize(output_path)} bytes)")

if __name__ == "__main__":
    out_file = os.path.join(CURRENT_DIR, "Memoria_Documentation.docx")
    build_docx_report(out_file)
