"""
Memoria Project Documentation - Full Content Generator
Aggregates all 25 chapters, Table of Contents, and Glossary.
Provides generator functions for Markdown, DOCX, and PDF.
"""

import os
import sys

# Ensure current directory is in sys.path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from chapters_1_to_7 import get_chapters_1_to_7
from chapters_8_to_14 import get_chapters_8_to_14
from chapters_15_to_20 import get_chapters_15_to_20
from chapters_21_to_25 import get_chapters_21_to_25

def get_glossary():
    return [
        ("Active Memory (L2)", "The persistent vector storage tier (ChromaDB) housing currently valid long-term memories indexed for semantic similarity and hybrid RAG."),
        ("Adaptive Decay", "A biologically inspired forgetting mechanism where memory retention decays over time at a rate moderated by category permanence, importance, and access frequency."),
        ("Anaphora Resolution", "The process of resolving contextual references and pronouns (e.g., 'it', 'there', 'that capital') using recent conversational turns from Level-1 Working Memory."),
        ("Archival-First Invariant", "A transactional storage safety guarantee stipulating that an active vector memory record is never deleted from L2 until confirmed persistent write in L3 Cold Archive succeeds."),
        ("Atomic Assertion", "A self-contained, normalized factual proposition distilled into third-person canonical form (e.g., 'User lives in Bengaluru')."),
        ("BM25", "Best Matching 25, a probabilistic term-frequency/inverse-document-frequency ranking algorithm used for sparse lexical keyword retrieval."),
        ("Cardinality (One vs Many)", "A structural rule in relational memory schema where 'cardinality=one' attributes (e.g., current home city, marital status) trigger supersession, while 'cardinality=many' attributes (e.g., skills, visited locations) append."),
        ("Catastrophic Forgetting", "The tendency of neural networks and stateless conversational models to completely lose previously acquired knowledge upon receiving new context or starting new sessions."),
        ("Cold Archive (L3)", "A persistent relational database (SQLite) storing decayed, stale, or superseded historical memories, preventing active vector store bloat while enabling on-demand restoration."),
        ("Composite Hybrid Retrieval", "A multi-factor scoring function that ranks candidate memories by interpolating dense vector similarity (0.45), sparse BM25 (0.20), adaptive decay retention (0.25), and permanence importance (0.10)."),
        ("Context Drift", "The degradation of conversational relevance caused by accumulating irrelevant, contradictory, or outdated factual assertions within the prompt context window."),
        ("Cosine Similarity", "A metric measuring the cosine of the angle between two high-dimensional embedding vectors, indicating semantic similarity independently of vector magnitude."),
        ("Ebbinghaus Forgetting Curve", "The mathematical exponential model R(t) = exp(-t/S) formulated by Hermann Ebbinghaus describing the decline of memory retention over elapsed time."),
        ("FIFO Ring Buffer", "A fixed-capacity first-in, first-out circular memory buffer holding the most recent N dialogue turns in fast volatile RAM."),
        ("Importance Score", "A normalized scalar [0.0, 1.0] estimating the intrinsic permanence and lifelong utility of an extracted fact."),
        ("Lifecycle Scheduler", "An asynchronous non-blocking background daemon that periodically sweeps active storage to detect stale items, apply decay, and orchestrate cold compaction."),
        ("Lineage Tracking", "A bidirectional provenance graph maintaining historical links between outdated ('SUPERSEDED') facts and their newer replacements ('ACTIVE')."),
        ("LLM Memory Gate", "A specialized classification prompt that evaluates conversational turns to reject transient small talk, generic queries, and polite acknowledgments before vectorization."),
        ("LongMemEval", "A rigorous conversational benchmark designed to test long-term retention, multi-session knowledge updates, and temporal reasoning across hundreds of dialogue turns."),
        ("Multi-Tenant Isolation", "The architectural partitioning of all memory ingestion, storage, retrieval, and background maintenance by strict user_id and tenant_id boundaries."),
        ("Multimodal Ingestion", "The capability to ingest both textual utterances and image data, extracting visual factual assertions and storing multimodal embeddings."),
        ("Persona Synthesis", "The automated extraction and consolidation of durable user attributes (identity, skills, locations, goals) into a concise profile block."),
        ("PII Scrubbing", "Pre-storage regex and heuristic sanitization removing emails, phone numbers, SSNs, credit cards, and API secrets prior to vectorization."),
        ("Reciprocal Rank Fusion (RRF)", "An rank-aggregation method combining ranked lists from different retrieval engines (e.g., BM25 and dense embeddings) using formula 1 / (k + rank)."),
        ("Restoration Engine", "A subsystem that queries the L3 Cold Archive upon receiving historical user inquiries and reactivates relevant records back into L2 and L1."),
        ("Stability Score (S)", "The characteristic half-life parameter in the adaptive Ebbinghaus model, determined by importance, category weights, and logarithmic access reinforcement."),
        ("Supersession", "The atomic state transition where an existing memory is flagged as SUPERSEDED and invalidated by a conflicting or evolutionary newer fact."),
        ("Temporal Bracketing", "The practice of attaching valid_from and valid_to timestamps to retrieved facts in the LLM prompt, enabling explicit temporal reasoning."),
        ("Working Memory (L1)", "The high-speed volatile in-memory cache holding immediate turn context, active references, and hot memories for sub-millisecond retrieval.")
    ]

def get_table_of_contents():
    return [
        ("Chapter 1", "Project Title and Abstract"),
        ("Chapter 2", "Introduction and Background"),
        ("Chapter 3", "Problem Statement"),
        ("Chapter 4", "Motivation and Objectives"),
        ("Chapter 5", "Existing Systems and Their Limitations"),
        ("Chapter 6", "Proposed System and Its Advantages"),
        ("Chapter 7", "Complete System Architecture"),
        ("Chapter 8", "Detailed Explanation of Every Module"),
        ("Chapter 9", "Explanation of Every Important Function and Method"),
        ("Chapter 10", "Technologies, Frameworks, Libraries, and Tools Used"),
        ("Chapter 11", "Database Architecture and Storage Mechanisms"),
        ("Chapter 12", "Memory Management and Lifecycle"),
        ("Chapter 13", "Memory Encoding, Retrieval, Updating, and Deletion"),
        ("Chapter 14", "Memory Consolidation and Optimization"),
        ("Chapter 15", "Algorithms and Mathematical Concepts Used"),
        ("Chapter 16", "Complete End-to-End Execution Workflow"),
        ("Chapter 17", "API Endpoints and Their Functionality"),
        ("Chapter 18", "Installation and Environment Configuration"),
        ("Chapter 19", "Step-by-Step Execution Instructions"),
        ("Chapter 20", "Testing Methodology and Test Cases"),
        ("Chapter 21", "Experimental Results and Performance Evaluation"),
        ("Chapter 22", "Comparison with Existing Approaches"),
        ("Chapter 23", "Advantages, Limitations, and Challenges"),
        ("Chapter 24", "Security, Scalability, and Future Enhancements"),
        ("Chapter 25", "Conclusion and References"),
        ("Appendix A", "Glossary of Technical Terms"),
    ]

def get_all_chapters():
    all_ch = []
    all_ch.extend(get_chapters_1_to_7())
    all_ch.extend(get_chapters_8_to_14())
    all_ch.extend(get_chapters_15_to_20())
    all_ch.extend(get_chapters_21_to_25())
    return all_ch

def generate_master_markdown():
    lines = []
    lines.append("# MEMORIA: A SCALABLE AGENTIC MEMORY FRAMEWORK FOR PERSONALIZED CONVERSATIONAL AI")
    lines.append("\n**Comprehensive Technical and Academic Project Documentation**\n")
    lines.append("---\n")
    
    # Table of contents
    lines.append("## Table of Contents\n")
    for ch_num, ch_title in get_table_of_contents():
        anchor = ch_title.lower().replace(" ", "-").replace(",", "").replace("&", "")
        lines.append(f"- **{ch_num}**: {ch_title}")
    lines.append("\n---\n")

    # Chapters
    chapters = get_all_chapters()
    for ch in chapters:
        lines.append(ch["content"])
        lines.append("\n---\n")

    # Appendix Glossary
    lines.append("# Appendix A: Glossary of Important Technical Terms\n")
    lines.append("| Technical Term | Definition & System Context |")
    lines.append("| :--- | :--- |")
    for term, definition in get_glossary():
        lines.append(f"| **{term}** | {definition} |")
    lines.append("\n---\n")

    return "\n".join(lines)
