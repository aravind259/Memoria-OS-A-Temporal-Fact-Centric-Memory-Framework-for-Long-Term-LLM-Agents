"""
Memoria Project Documentation - Chapters 1 through 7
Covers Title & Abstract, Introduction, Problem Statement, Objectives,
Existing Systems, Proposed System, and Complete System Architecture.
"""

def get_chapters_1_to_7():
    chapters = []

    # CHAPTER 1
    c1 = {
        "title": "Chapter 1: Project Title and Abstract",
        "content": """# Chapter 1: Project Title and Abstract

## Project Title
**Memoria – A Scalable Agentic Memory Framework for Personalized Conversational AI**

## Academic & Institutional Classification
- **Domain**: Artificial Intelligence / Natural Language Processing / Cognitive Autonomous Agents
- **Sub-domains**: Long-Term Conversational Memory, Retrieval-Augmented Generation (RAG), Semantic Knowledge Representation, Multi-Tier Storage Systems, Temporal Contradiction Resolution
- **System Classification**: Agentic Memory Operating System (AI-MOS) Architecture

---

## Abstract

Standard conversational artificial intelligence systems powered by Large Language Models (LLMs) are fundamentally stateless across session boundaries. While in-context learning enables reasoning over immediate dialogue turns, standard context windows fail to maintain longitudinal, personalized user context over weeks, months, or years. Conventional Retrieval-Augmented Generation (RAG) approaches suffer from severe technical deficiencies: they treat memory items as static, unweighted vector points, lack biological temporal decay, fail to resolve conflicting knowledge updates (such as a user relocating or changing employment), and suffer from context bloat caused by uncurated conversational noise.

To address these foundational challenges, this research presents **Memoria**, a scalable, multi-tiered agentic memory framework engineered specifically for continuous, lifelong conversational AI personalization. Memoria introduces a tripartite hierarchical storage topology comprising:
1. **Level-1 (L1) Working Memory**: An in-memory, high-speed volatile Ring Buffer that captures immediate multi-turn conversational exchanges and resolves elliptical references (anaphora) with sub-millisecond latency.
2. **Level-2 (L2) Active Vector Store**: A persistent, dense semantic index powered by ChromaDB (`memories` collection) utilizing cosine similarity over high-dimensional embeddings (`text-embedding-004`) for real-time relevance retrieval.
3. **Level-3 (L3) Cold Relational Archive**: An on-disk SQLite relational database (`memory_os_archive.db`) housing historically decayed, superseded, or inactive memories, preventing vector search space pollution while ensuring zero permanent data loss.

Memoria deploys an **Adaptive Ebbinghaus Retention Decay Engine**, formulating memory retention $R(\\Delta t) = \\exp(-\\Delta t / S_{\\text{adaptive}})$, where stability $S$ is dynamically moderated by semantic category persistence weights (ranging from $2.5$ for personal preferences to $0.5$ for transient conversation), baseline importance scores, and logarithmic access reinforcement $(1 + \\ln(1 + \\text{count}))$. An asynchronous, non-blocking background **Lifecycle Scheduler** executes periodic sweeps to detect stale memories, enforcing an **Important-Memory Protection Rule** ($I \\ge 0.65$ or access count $\\ge 2$) and an **Archival-First Transactional Compactor** that guarantees L3 persistence before L2 vector slot reclamation.

Furthermore, Memoria features an automated **Semantic Reconciliation and Lineage Tracking Engine** that classifies incoming facts against existing representations as `REINFORCES`, `SUPERSEDES`, or `DISTINCT`. When evolutionary facts emerge (e.g., relocating from Hyderabad to Bengaluru), the prior record is atomically transitioned to `SUPERSEDED` and linked via provenance metadata, eliminating contradictory contextual hallucination. Hybrid RAG retrieval combines dense vector similarity (0.45), sparse BM25 lexical matching (0.20), adaptive retention decay (0.25), and permanence importance (0.10). An accompanying V2 relational memory pipeline implements explicit schema extraction with attribute cardinality constraints (`cardinality=one` vs `many`), Reciprocal Rank Fusion (RRF, $k=60$), and raw-turn fallback indexing.

Empirical evaluations across comprehensive test suites demonstrate **100% functional accuracy** across tier management, decay adaptation, cold restoration, conflict reconciliation, and multi-turn chat integration. On long-context benchmarks, Memoria achieves an **88% Hit Rate@1** and **0.94 Mean Reciprocal Rank (MRR)**, while dynamic persona compression yields an approximate **36% prompt token reduction**. Memoria establishes a robust, privacy-preserving, and mathematically grounded foundation for autonomous, lifelong conversational AI.
"""
    }
    chapters.append(c1)

    # CHAPTER 2
    c2 = {
        "title": "Chapter 2: Introduction and Background",
        "content": """# Chapter 2: Introduction and Background

## 2.1 The Conversational AI Memory Paradigm
Modern conversational artificial intelligence has been revolutionized by autoregressive transformer architectures and Large Language Models (LLMs). Models such as GPT-4, Claude, and Gemini demonstrate remarkable general reasoning, in-context zero-shot synthesis, and domain expertise. However, by architectural design, LLM inference is strictly **stateless**: every invocation operates exclusively over the tokens supplied within the immediate context window. Once an inference API call completes, all intermediate activations are discarded.

In human communication, interpersonal relationships, collaborative workflows, and tailored recommendations rely heavily on **episodic and semantic long-term memory**. A personal assistant must remember user dietary restrictions, professional skills, geographic location, active goals, and recurring preferences across dozens or hundreds of disparate conversations over months or years.

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│                       STATELESS LLM INFERENCE DILEMMA                       │
│                                                                             │
│   Session 1 (Day 1):   "I moved from Hyderabad to Bengaluru." ──┐           │
│   LLM Internal State:  [Discards context upon session close]    │           │
│                                                                 │ No Shared │
│   Session 2 (Day 15):  "Recommend a weekend coffee spot."       │ Memory    │
│   LLM Response:        "Here are cafes in Hyderabad!" <─────────┘ (Error)   │
└─────────────────────────────────────────────────────────────────────────────┘
```

Without an externalized, persistent, and intelligent memory architecture, conversational AI agents suffer from **perpetual amnesia**, forcing users to repetitively re-explain preferences, constraints, and historical context.

---

## 2.2 Cognitive and Psychological Foundations of Memory
To build an agentic memory framework that mirrors human cognitive efficiency, Memoria draws inspiration from two foundational pillars of cognitive psychology:

### 1. The Atkinson-Shiffrin Multi-Store Memory Model (1968)
Richard Atkinson and Richard Shiffrin posited that human cognitive architecture processes information through distinct structural stores:
- **Sensory Register**: Receives raw environmental stimuli and buffers it for milliseconds.
- **Short-Term / Working Memory (STM)**: A limited-capacity store holding active representations for immediate manipulation (typically 7 $\\pm$ 2 chunks) with high access speed.
- **Long-Term Memory (LTM)**: An essentially unbounded repository holding declarative (episodic and semantic) knowledge over extended durations. Transfer from STM to LTM occurs via rehearsal, emotional salience, and consolidation.

Memoria translates this cognitive paradigm into software system tiers:
- **L1 Working Memory**: In-memory FIFO ring buffer for immediate dialogue turns and hot entities.
- **L2 Active Memory**: Semantic vector database (ChromaDB) for high-probability recall.
- **L3 Cold Archive**: Persistent relational database (SQLite) for deep consolidation and historical reference.

### 2. Hermann Ebbinghaus's Forgetting Curve (1885)
German psychologist Hermann Ebbinghaus pioneered empirical investigations into memory retention, demonstrating that human memory decays exponentially over elapsed time:

$$R(t) = e^{-\\frac{t}{S}}$$

Where $R$ represents retentive recall probability, $t$ is elapsed time, and $S$ represents memory stability (the half-life of the memory trace). Crucially, Ebbinghaus demonstrated that:
1. **Repetitive Rehearsal (Spaced Repetition)**: Each active retrieval or review significantly increases stability $S$, flattening the decay trajectory.
2. **Semantic Meaningfulness**: Meaningful, deeply processed associations decay significantly slower than arbitrary or ephemeral nonsense syllables.

Traditional vector databases lack any concept of temporal decay; an embedding stored three years ago possesses the identical vector similarity score as an embedding stored three minutes ago. Memoria bridges this divide by formalizing an **Adaptive Ebbinghaus Decay Engine** directly into the hybrid retrieval and lifecycle compaction algorithms.

---

## 2.3 Evolution of External Memory in LLM Systems
The quest to augment LLMs with long-term memory has progressed through multiple generations:

```text
Generation 1: Context Buffering
   Raw dialogue turn concatenation (LangChain ConversationBufferMemory)
   Result: Prompt window explosion, high cost, context limits reached.

Generation 2: Naive Vector RAG
   Chunking raw dialogue into vector embeddings (Pinecone, ChromaDB, Weaviate)
   Result: Vector drift, duplicate accumulation, unhandled contradictions, small-talk pollution.

Generation 3: Hierarchical Virtual Paging (MemGPT / Letta)
   Agent uses tool calls to page text between core and archival memory.
   Result: High latency (2-4 LLM calls per turn), high token overhead, complex prompting.

Generation 4: Memoria (Agentic Memory Operating System)
   Multi-tiered storage (L1/L2/L3) + Biological Ebbinghaus Decay + 
   Automated Contradiction Lineage + Hybrid 4-Factor Ranking + Relational Cardinality.
```
"""
    }
    chapters.append(c2)

    # CHAPTER 3
    c3 = {
        "title": "Chapter 3: Problem Statement",
        "content": """# Chapter 3: Problem Statement

## 3.1 Formal Problem Definition
Let $\\mathcal{U} = \\{u_1, u_2, \\dots, u_T\\}$ represent a continuous, unbounded sequence of natural language conversational turns exchanged between a human user and an autonomous conversational AI agent across arbitrary time intervals $t_1 < t_2 < \\dots < t_T$. Let each turn $u_t$ consist of user utterance $x_t$, optional multimodal payload $v_t$, metadata $\\mu_t$, and timestamp $\\tau_t$.

The fundamental problem is to maintain an external, persistent, and dynamically self-reconciling memory state $\\mathcal{M}_t$ such that, at any future query turn $q$ arriving at time $\\tau_q$:
1. The agent retrieves the optimal, non-contradictory, and temporally accurate subset of user context $\\mathcal{K}_q^* \\subset \\mathcal{M}_t$.
2. The agent generates a personalized, highly accurate response $y_q = \\text{LLM}(q, \\mathcal{K}_q^*)$ that respects historical evolution.
3. The computational storage and inference complexity remains bounded and sub-linear with respect to $T$: $|\\mathcal{K}_q^*| \\ll T$.

---

## 3.2 The Five Core Technical Deficiencies of Existing Systems

Current memory architectures fail to solve this problem due to five fundamental engineering bottlenecks:

### 1. Static Vector Representations & Temporal Blindness
Conventional vector RAG systems treat all indexed embeddings as immutable, timeless points in high-dimensional space $\\mathbb{R}^d$. When computing cosine similarity:

$$\\text{Sim}(q, m) = \\frac{\\mathbf{e}_q \\cdot \\mathbf{e}_m}{\\|\\mathbf{e}_q\\| \\|\\mathbf{e}_m\\|}$$

The similarity score is completely independent of elapsed physical time $\\Delta t = \\tau_q - \\tau_m$. An ephemeral observation made six months ago (e.g., *"I have a slight cold today"*) is scored identically to a persistent condition mentioned today, causing obsolete facts to contaminate prompt contexts.

### 2. The Overwrite vs. Duplicate Blindness Dilemma
When a user updates personal information, existing memory systems face an intractable dilemma:
- **Destructive Overwriting**: Blindly overwriting previous vectors erases historical context, preventing temporal reasoning (e.g., answering *"Where did I live before moving to Bengaluru?"*).
- **Duplicate Blindness / Blind Appending**: Vector databases that simply insert all turns end up holding both *"User lives in Hyderabad"* and *"User lives in Bengaluru"* simultaneously as active candidates. When queried, both contradictory facts are retrieved into the prompt, inducing LLM hallucination and confusion.

### 3. Vector Drift and Entity Smoothing in Dense Space
High-dimensional dense embeddings (such as 768-dimensional or 1536-dimensional semantic vectors) excel at fuzzy topical categorization, but exhibit **semantic smoothing**. Precise entity identifiers, specific part numbers, telephone numbers, and technical terms often experience lower cosine similarity than conceptually generic sentences. Pure vector search lacks the lexical exactitude of sparse term-frequency models like BM25.

### 4. Context Pollution & Prompt Token Inflation
In uncurated systems, every conversational turn—including transient questions (*"What is the weather in Tokyo?"*), polite pleasantries (*"Good morning, how are you?"*), and system acknowledgments—is vectorized and indexed. Over hundreds of turns, this conversational debris pollutes retrieval indexes, dilutes attention weights, and inflates API token costs exponentially.

### 5. Monolithic Storage Degradation
Most systems store all user memories in a single, flat vector index. As interaction histories grow from hundreds to tens of thousands of items:
- Vector search latency scales proportionally with index size: $\\mathcal{O}(N \\log N)$ or $\\mathcal{O}(N \\cdot d)$.
- Index memory footprint consumes expensive RAM.
- Retrieval precision degrades as the ratio of historical noise to active facts increases.

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│                    THE MEMORY POLLUTION & BLOAT SPIRAL                     │
│                                                                             │
│  User Turn: "Good morning!" ──────────► Ingested ────► Vector Store Bloat   │
│  User Turn: "Where is my order?" ─────► Ingested ────► Irrelevant Retrieval │
│  User Turn: "I moved to Bengaluru" ───► Appended ────► Contradicts Old City │
│                                                                             │
│  RESULT: Flat vector index balloons, search precision plummets,             │
│          LLM context receives contradictory, stale, and noisy facts.        │
└─────────────────────────────────────────────────────────────────────────────┘
```
"""
    }
    chapters.append(c3)

    # CHAPTER 4
    c4 = {
        "title": "Chapter 4: Motivation and Objectives",
        "content": """# Chapter 4: Motivation and Objectives

## 4.1 Motivation
The vision of conversational artificial intelligence is not merely to provide a transient oracle for general knowledge, but to serve as a **continuous, empathetic, and hyper-personalized companion, collaborator, and cognitive extension**. For an AI agent to truly understand an individual over months or years, it must exhibit:
1. **Long-Term Continuity**: Remembering identity, relationships, background, and preferences without explicit re-prompting.
2. **Graceful Forgetting**: Allowing transient details to fade naturally, mirroring human biological memory, while tenaciously retaining critical facts.
3. **Temporal Adaptation**: Seamlessly updating its mental model when user circumstances evolve, understanding both the current state and the historical timeline.
4. **Computational Sustainability**: Operating with bounded latency, predictable RAM footprint, and optimized token overhead.

These requirements motivated the creation of **Memoria**, conceived not merely as a database wrapper, but as an **Agentic Memory Operating System** providing complete lifecycle governance, tiered memory paging, and mathematically rigorous decay.

---

## 4.2 Research and Engineering Objectives

Memoria was engineered to achieve six explicit, measurable objectives:

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│                       CORE OBJECTIVES OF MEMORIA                            │
│                                                                             │
│  [Obj 1] Multi-Tiered Architecture (L1 RAM / L2 ChromaDB / L3 SQLite)       │
│  [Obj 2] Biologically Grounded Adaptive Ebbinghaus Decay Engine             │
│  [Obj 3] Automated Contradiction Resolution & Lineage Tracking              │
│  [Obj 4] 4-Factor Composite Hybrid RAG Retrieval Engine                     │
│  [Obj 5] Structural Fact Extraction with Attribute Cardinality Rules        │
│  [Obj 6] Privacy-by-Design with Multi-Tenant Isolation & PII Scrubbing      │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Objective 1: Implement a Tri-Tiered Hierarchical Memory Architecture
- Create an in-memory Level-1 (L1) Working Memory FIFO ring buffer for sub-millisecond turn retrieval and anaphora resolution.
- Establish a persistent Level-2 (L2) Active Vector Store in ChromaDB for high-dimensional semantic search.
- Engineer a Level-3 (L3) Cold Relational Archive in SQLite for long-term historical retention and page-out defragmentation.

### Objective 2: Formulate an Adaptive Biological Decay and Lifecycle Model
- Implement an exponential decay function $R(\\Delta t) = \\exp(-\\Delta t / S)$ modeling human forgetting curves.
- Dynamically scale memory stability $S$ using semantic category weights (Preferences > Skills > Goals > Facts > Conversation) and logarithmic access reinforcement $(1 + \\ln(1 + \\text{count}))$.
- Deploy an asynchronous background Lifecycle Scheduler executing periodic sweeps to page stale memories from L2 to L3, protected by an Important-Memory Preservation Rule.

### Objective 3: Engineer Automated Contradiction Resolution and Lineage Tracking
- Formulate an LLM-driven reconciliation engine that categorizes incoming assertions relative to existing representations into `SUPERSEDES`, `REINFORCES`, or `DISTINCT`.
- Atomically transition outdated memories to `SUPERSEDED`, record successor links (`superseded_by`), and preserve historical integrity without duplicate contextual hallucination.

### Objective 4: Construct a 4-Factor Composite Hybrid Retrieval Engine
- Synthesize dense semantic vector similarity ($45\\%$), sparse BM25 lexical relevance ($20\\%$), adaptive time-decay retention ($25\\%$), and permanence importance ($10\\%$).
- Ensure high recall for fuzzy semantic concepts while maintaining zero drift on exact entity identifiers.

### Objective 5: Formalize Structural Relational Extraction with Attribute Cardinality
- Implement a V2 benchmark-grade pipeline that distills dialogue turns into structured tuples `(subject, attribute, value, kind, cardinality, valid_from, valid_to)`.
- Apply strict cardinality governance: `cardinality=one` attributes atomically supersede prior values; `cardinality=many` attributes append cleanly.
- Pair structured fact retrieval with raw-turn fallback indexing via Reciprocal Rank Fusion ($k=60$).

### Objective 6: Guarantee Privacy-by-Design and Multi-Tenant Security
- Embed automated regex and heuristic PII scrubbing to redact emails, phone numbers, credit cards, and credentials before vectorization.
- Partition all memory ingestion, storage, retrieval, and background maintenance by strict `user_id` and `tenant_id` boundaries.
"""
    }
    chapters.append(c4)

    # CHAPTER 5
    c5 = {
        "title": "Chapter 5: Existing Systems and Their Limitations",
        "content": """# Chapter 5: Existing Systems and Their Limitations

## 5.1 Critical Review of Prior Art
To contextualize the contributions of Memoria, we systematically examine the prevailing paradigms and systems in conversational AI memory:

### 1. LangChain Memory Architectures (`ConversationBufferMemory`, `VectorStoreRetrieverMemory`)
- **Mechanism**: Appends raw dialogue text turns directly into the prompt context window or stores uncurated turn chunks into a standard vector database.
- **Architectural Deficiencies**:
  - Unbounded prompt growth rapidly breaches model context limits ($N_{\\text{tokens}} \\to \\infty$).
  - Vector search retrieves entire conversational turns containing small talk, noise, and irrelevant digressions.
  - No mechanism exists to resolve contradictions; old and new statements coexist, causing severe context drift.

### 2. MemGPT / Letta (Packer et al., 2023)
- **Mechanism**: Inspired by traditional operating system virtual memory, MemGPT treats the LLM context window as RAM and uses explicit LLM tool-calling (`core_memory_append`, `archival_memory_insert`) to page memory blocks between context and external storage.
- **Architectural Deficiencies**:
  - Extremely high latency: every conversational turn requires 2 to 4 sequential LLM tool invocations simply to decide memory actions.
  - High inference cost: continuous autonomous tool calling consumes massive token budgets.
  - Relies entirely on the LLM's prompt adherence to manually organize memory, leading to erratic compaction and dropped facts under complex dialogue.

### 3. Zep (Long-Term Memory Engine)
- **Mechanism**: An enterprise memory server utilizing a temporal knowledge graph alongside vector embeddings.
- **Architectural Deficiencies**:
  - Closed-source / proprietary dependencies in advanced features.
  - Lacks biologically grounded exponential Ebbinghaus decay parameterized by semantic categories and logarithmic reinforcement.
  - Does not implement an archival-first transactional storage guarantee across three isolated hardware tiers.

### 4. Memoria (Sarin et al., AIMLSystems 2025)
- **Mechanism**: Extracts atomic `(subject, predicate, object)` triplets from user turns via an LLM call, stores them in ChromaDB with timestamps, updates a rolling session summary, and scores top-20 retrieved triplets using min-max normalized exponential decay:

$$w_i = \\exp(-0.02 \\cdot x_i)$$

Where $x_i \\in [0, 1]$ represents normalized elapsed minutes.
- **Architectural Deficiencies**:
  - Rigid triplet schema: complex attributes, temporal validities, and conditions cannot be cleanly captured in atomic triples.
  - The exponential decay weight $w_i$ is evaluated over an ad-hoc min-max normalization window across only the candidate set, rather than modeling absolute physical elapsed time.
  - Lacks attribute cardinality awareness (`cardinality=one` vs `many`), leading to contradictory facts being retrieved simultaneously.

---

## 5.2 Comprehensive System Comparison Matrix

The following table presents a systematic feature-by-feature comparison between existing memory frameworks and Memoria:

| Feature / Capability | LangChain Buffer | Naive Vector RAG | MemGPT / Letta | Memoria (Sarin 2025) | **Memoria (Proposed Framework)** |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Storage Architecture** | Ephemeral RAM | Flat Vector Store | Core Context + Disk | Vector + Relational | **Tri-Tier (L1 RAM + L2 Vector + L3 SQLite)** |
| **Decay Mechanism** | None | None | None | Min-Max Ad-hoc Decay | **Adaptive Ebbinghaus Decay + Category Weights** |
| **Contradiction Resolution** | None | None | Manual LLM Edits | None | **Automated Lineage Supersession + Cardinality** |
| **Retrieval Engine** | FIFO Window | Dense Vector Only | Tool-based Paging | Cosine + Ad-hoc Weight | **4-Factor Hybrid (Vector + BM25 + Decay + Imp)** |
| **Ephemeral Noise Filter** | None | None | None | None | **LLM Memory Gate + Question Filter** |
| **Atomic Fact Extraction** | Raw Turns | Chunked Turns | Manual Tool Calls | Triplet (S, P, O) | **3rd-Person Assertion + Structured Tuples** |
| **Background Lifecycle** | None | None | None | None | **Async Scheduler + Stale Compaction Sweeps** |
| **Safety Guarantees** | None | None | Overwrite Risk | None | **Archival-First Invariant + Protection Rule** |
| **Persona Synthesis** | None | None | Core Memory Block | None | **Structured Extractor + Context Compression** |
| **PII Sanitization** | None | None | None | None | **Automated Regex & Heuristic Scrubbing** |
| **Multi-Tenant Isolation** | None | Ad-hoc Filters | User Scoped | User Filtered | **Strict Partitioning (user_id & tenant_id)** |
| **Inference Overhead** | 0 Extra Calls | 0 Extra Calls | 2-4 Calls / Turn | 1 Extra Call / Turn | **1 Lightweight Call / Turn (Async Background)** |
"""
    }
    chapters.append(c5)

    # CHAPTER 6
    c6 = {
        "title": "Chapter 6: Proposed System and Its Advantages",
        "content": """# Chapter 6: Proposed System and Its Advantages

## 6.1 Architectural Vision: The AI Memory Operating System
To overcome the structural deficiencies of prior art, this project proposes **Memoria**, an end-to-end Agentic Memory Framework designed as an **AI Memory Operating System (AI-MOS)**. Memoria decouples immediate conversational interaction from long-term memory governance, introducing structured resource management, tiered paging, biological forgetting, and atomic knowledge reconciliation.

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│                      THE MEMORIA PROPOSED ARCHITECTURE                      │
│                                                                             │
│  [User Turn]                                                                │
│       │                                                                     │
│       ▼                                                                     │
│  [Pre-Ingestion Gate] ──► PII Scrubbing ──► Question Filter ──► LLM Gate   │
│       │                                                                     │
│       ▼                                                                     │
│  [Fact Distillation] ──► Atomic Assertion & Categorization                  │
│       │                                                                     │
│       ▼                                                                     │
│  [Reconciliation]   ──► Detects Duplicates ──► Updates Lineage/Supersession │
│       │                                                                     │
│       ▼                                                                     │
│  [Tri-Tier Storage] ──► L1 Working Buffer ──► L2 ChromaDB ──► L3 SQLite     │
│                               ▲                    │              ▲         │
│                               │ (Restore)          │ (Page Out)   │         │
│                               └────────────────────┴──────────────┘         │
│                                                                             │
│  [Hybrid Retrieval] ──► 0.45 Vector + 0.20 BM25 + 0.25 Decay + 0.10 Imp     │
│       │                                                                     │
│       ▼                                                                     │
│  [LLM Response]     ──► Augmented Prompt with Temporal Bracketing           │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6.2 Key Innovations and Architectural Advantages

### 1. Tri-Tiered Storage Hierarchy
Rather than storing all user knowledge in a flat vector index, Memoria establishes three distinct, specialized storage tiers:
- **L1 Working Memory**: Maintains recent dialogue turns in volatile RAM (deque with `maxlen=10`) providing instantaneous reference resolution.
- **L2 Active Vector Store**: Holds high-priority, currently active long-term memories in ChromaDB, optimizing dense retrieval speed.
- **L3 Cold Archive**: Relocates stale, decayed, or superseded memories to persistent SQLite disk storage, eliminating vector bloat while guaranteeing zero permanent information loss.

### 2. Adaptive Ebbinghaus Retention Decay
Memoria implements a mathematically rigorous decay function inspired by cognitive biology:
- Retention decreases as an exponential function of physical elapsed hours: $R(\\Delta t) = \\exp(-\\Delta t / S)$.
- Memory stability $S$ is customized by semantic category: preferences and skills are granted high persistence multipliers ($W = 2.5$ and $2.2$), while conversational notes decay rapidly ($W = 0.5$).
- Logarithmic reinforcement $(1 + \\ln(1 + \\text{count}))$ rewards frequently accessed memories, flattening their forgetting curves.

### 3. Automated Contradiction Resolution via Lineage Tracking
When incoming information contradicts existing knowledge:
- Memoria does not blindly overwrite or duplicate.
- It identifies semantic relationships (`REINFORCES`, `SUPERSEDES`, `DISTINCT`).
- On supersession, the existing memory is flagged as `SUPERSEDED`, tagged with `superseded_by = new_memory_id`, and paged to L3 Cold Archive, while the new memory becomes `ACTIVE`. Both states are preserved in the lineage graph.

### 4. 4-Factor Composite Hybrid RAG
Retrieval interpolates four distinct signals to calculate final candidate rankings:
- **Dense Vector Similarity (45%)**: Captures deep conceptual relevance.
- **Sparse BM25 Lexical Score (20%)**: Prevents semantic drift on exact names, numbers, and entities.
- **Adaptive Retention Decay (25%)**: Prioritizes fresh, reinforced memories.
- **Permanence Importance Score (10%)**: Boosts core life facts.

### 5. Archival-First Transactional Safety Invariant
The memory compactor enforces an **archival-first safety protocol**: active memory slots in L2 ChromaDB are deleted **if and only if** successful persistent write verification is returned by the L3 SQLite database:

$$\\text{ReclaimL2}(m_i) \\iff \\text{WriteL3}(m_i) = \\text{SUCCESS}$$

If an L3 disk write encounters an exception, the L2 record remains untouched, ensuring zero data loss.

### 6. Relational Fact Extraction with Cardinality Rules (V2 Pipeline)
The accompanying V2 benchmark pipeline introduces:
- Structured schema: `(subject, attribute, value, kind, cardinality, valid_from, valid_to)`.
- Cardinality governance: `cardinality=one` enforces immediate temporal supersession of prior attribute values; `cardinality=many` cleanly appends distinct values.
- Reciprocal Rank Fusion ($k=60$) combining BM25, dense embeddings, and raw-turn fallback indexing.
"""
    }
    chapters.append(c6)

    # CHAPTER 7
    c7 = {
        "title": "Chapter 7: Complete System Architecture",
        "content": """# Chapter 7: Complete System Architecture

## 7.1 High-Level Architecture Topology
The Memoria framework operates as an asynchronous, layered service decoupled into five primary architectural planes:
1. **Ingestion & Pre-Processing Plane**: PII scrubbing, question filtering, semantic classification, importance scoring, and LLM memory gating.
2. **Reconciliation & Distillation Plane**: Atomic third-person proposition extraction, duplicate detection, and lineage supersession tracking.
3. **Multi-Tier Storage Plane**: L1 Working Memory FIFO Ring Buffer, L2 Active ChromaDB Vector Store, and L3 Cold SQLite Relational Archive.
4. **Autonomous Lifecycle Maintenance Plane**: Asynchronous Lifecycle Scheduler, adaptive decay evaluation, and transactional archival compaction.
5. **Hybrid Retrieval & Synthesis Plane**: Composite 4-factor ranker, reciprocal rank fusion, persona synthesis, and prompt compression.

```text
═════════════════════════════════════════════════════════════════════════════════
                            MEMORIA ARCHITECTURAL TOPOLOGY
═════════════════════════════════════════════════════════════════════════════════

                                 USER INPUT
                                     │
                                     ▼
                     ┌───────────────────────────────┐
                     │     PII Sanitization Unit     │ (Scrub emails, phones, SSNs)
                     └───────────────┬───────────────┘
                                     │
                                     ▼
                     ┌───────────────────────────────┐
                     │    Question & Noise Filter    │ (Bypasses non-factual queries)
                     └───────────────┬───────────────┘
                                     │
                                     ▼
                     ┌───────────────────────────────┐
                     │    Semantic Classification    │ (Preference, Skill, Goal, Fact)
                     └───────────────┬───────────────┘
                                     │
                                     ▼
                     ┌───────────────────────────────┐
                     │      LLM Memory Gate          │ (Rejects ephemeral small talk)
                     └───────────────┬───────────────┘
                                     │
                                     ▼
                     ┌───────────────────────────────┐
                     │    Fact Distillation Unit     │ (Normalizes to atomic assertions)
                     └───────────────┬───────────────┘
                                     │
                                     ▼
                     ┌───────────────────────────────┐
                     │  Reconciliation & Lineage     │ (SUPERSEDES / REINFORCES / DISTINCT)
                     └───────────────┬───────────────┘
                                     │
         ┌───────────────────────────┴───────────────────────────┐
         │                                                       │
         ▼                                                       ▼
┌─────────────────────────┐                             ┌─────────────────────────┐
│   [L1] Working Memory   │                             │  [L2] Active Vector DB  │
│   In-Memory Ring Buffer │◄──────── [Promote] ─────────┤   ChromaDB (memories)   │
│   (Max 10 Turns)        │                             └───────────┬─────────────┘
└─────────────────────────┘                                         │
                                                                    │ (Sweep & Compact)
                                                                    ▼
                                                        ┌─────────────────────────┐
                                                        │   [L3] Cold Archive     │
                                                        │   SQLite (cold_memories)│
                                                        └───────────┬─────────────┘
                                                                    │
                                                                    │ (Restore on Query)
                                                                    ▼
                                                        ┌─────────────────────────┐
                                                        │   Restoration Engine    │
                                                        └─────────────────────────┘
                                                                    │
                                     ┌──────────────────────────────┘
                                     │
                                     ▼
                     ┌───────────────────────────────┐
                     │  Hybrid Retrieval Engine      │
                     │  ├── Dense Vector   (45%)     │
                     │  ├── Sparse BM25    (20%)     │
                     │  ├── Ebbinghaus R(t)(25%)     │
                     │  └── Importance     (10%)     │
                     └───────────────┬───────────────┘
                                     │
                                     ▼
                     ┌───────────────────────────────┐
                     │ Context Synthesis & Formatter │ (Temporal Bracketing & Compression)
                     └───────────────┬───────────────┘
                                     │
                                     ▼
                     ┌───────────────────────────────┐
                     │      LLM Response Engine      │
                     └───────────────┬───────────────┘
                                     │
                                     ▼
                               USER OUTPUT
═════════════════════════════════════════════════════════════════════════════════
```

---

## 7.2 Inter-Module Data Flow and Sequence

The end-to-end execution flow through Memoria during a user interaction follows a coordinated sequence across components:

```text
Client          FastAPI         Pipeline        ChromaDB        SQLite(L3)       LLM (Gemini)
  │                │                │               │               │                 │
  │──POST /chat───►│                │               │               │                 │
  │                │──process_turn─►│               │               │                 │
  │                │                │──Scrub PII───┐│               │                 │
  │                │                │◄─────────────┘│               │                 │
  │                │                │──Classify────┐│               │                 │
  │                │                │◄─────────────┘│               │                 │
  │                │                │──Memory Gate───────────────────────────────────►│
  │                │                │◄─Approved / Rejected────────────────────────────│
  │                │                │                               │                 │
  │                │                │──Distill Fact──────────────────────────────────►│
  │                │                │◄─Atomic Assertion───────────────────────────────│
  │                │                │                               │                 │
  │                │                │──Query Neighbors─────────────►│                 │
  │                │                │◄─Nearest Candidates───────────│                 │
  │                │                │                               │                 │
  │                │                │──Reconcile Lineage───────────►│                 │
  │                │                │  (If SUPERSEDED: update old)──►│ (Archive Old)  │
  │                │                │                               │                 │
  │                │                │──Store New Fact──────────────►│                 │
  │                │                │                               │                 │
  │                │                │──Hybrid Retrieve Context─────►│                 │
  │                │                │◄─Ranked Candidates────────────│                 │
  │                │                │                                                 │
  │                │                │──Construct Augmented Prompt────────────────────►│
  │                │                │◄─Generated Response─────────────────────────────│
  │                │◄──Return Resp──│                                                 │
  │◄──HTTP 200─────│                │                                                 │
```

---

## 7.3 Detailed Storage Subsystem Contracts

### 1. In-Memory Working Memory Contract (L1)
- **Data Structure**: `collections.deque(maxlen=10)`
- **Access Complexity**: $\\mathcal{O}(1)$ push, $\\mathcal{O}(1)$ peek, $\\mathcal{O}(K)$ retrieval where $K \\le 10$.
- **Thread Safety**: Local process memory guarded by asyncio task boundaries.
- **Persistence**: Volatile; cleared on worker process termination or explicit `/memory/clear` call.

### 2. Active Semantic Vector Database Contract (L2)
- **Engine**: ChromaDB PersistentClient with HNSW indexing.
- **Embedding Dimensionality**: 768 dimensions (`text-embedding-004`).
- **Distance Metric**: Cosine Distance ($D_C = 1 - \\cos(\\theta)$).
- **Metadata Filters**: Mandatory scoped filtering: `{"user_id": user_id, "status": "ACTIVE"}`.

### 3. Cold Relational Archive Contract (L3)
- **Engine**: SQLite 3 database (`memory_os_archive.db`) in Write-Ahead Logging (WAL) mode.
- **Schema**: Table `cold_memories` with structured lineage pointers (`superseded_by`, `original_created_at`, `archived_at`).
- **Transactional Invariant**: `BEGIN TRANSACTION` $\\to$ insert into `cold_memories` $\\to$ `COMMIT` $\\to$ delete from ChromaDB.
"""
    }
    chapters.append(c7)

    return chapters
