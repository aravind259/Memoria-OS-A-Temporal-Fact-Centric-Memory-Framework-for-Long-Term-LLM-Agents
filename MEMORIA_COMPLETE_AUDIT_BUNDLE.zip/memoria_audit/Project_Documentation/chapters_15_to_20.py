"""
Memoria Project Documentation - Chapters 15 through 20
Covers Algorithms & Mathematical Formulations, End-to-End Execution Workflows,
API Endpoints & Contracts, Installation & Configuration, Execution Instructions,
and Testing Methodology & Evaluation Test Cases.
"""

def get_chapters_15_to_20():
    chapters = []

    # CHAPTER 15
    c15 = {
        "title": "Chapter 15: Algorithms and Mathematical Concepts Used",
        "content": """# Chapter 15: Algorithms and Mathematical Concepts Used

Memoria is grounded in rigorous mathematical formulations derived from cognitive science, information retrieval, and vector space theory. This chapter details every mathematical model and algorithm implemented in the system.

---

## 15.1 Adaptive Ebbinghaus Retention Decay Model

Memory retention probability $R(\\Delta t) \\in (0.0, 1.0]$ models the likelihood that a memory trace remains cognitively accessible after elapsed physical time $\\Delta t$:

$$R(\\Delta t) = \\exp\\left( -\\frac{\\Delta t}{\\max(0.1, S_{\\text{adaptive}})} \\right)$$

### 1. Elapsed Time Calculation
$$\\Delta t = \\max\\left(0.0, \\frac{\\tau_{\\text{current}} - \\tau_{\\text{created}}}{3600.0}\\right) \\quad \\text{(elapsed hours)}$$

### 2. Base Stability Formulation
$$S_{\\text{base}} = \\max(0.1, I) \\times 48.0 \\times W_{\\text{category}} \\times M_{\\text{feedback}}$$

Where:
- $I \\in [0.0, 1.0]$ is the semantic importance score.
- $48.0$ hours is the baseline half-life constant.
- $W_{\\text{category}}$ is the domain permanence multiplier:
  - $W_{\\text{preference}} = 2.5$
  - $W_{\\text{skill}} = 2.2$
  - $W_{\\text{health}} = 2.2$
  - $W_{\\text{goal}} = 1.8$
  - $W_{\\text{project}} = 1.5$
  - $W_{\\text{fact}} = 1.0$ (baseline)
  - $W_{\\text{conversation}} = 0.5$ (ephemeral)
- $M_{\\text{feedback}} \\in [0.5, 1.5]$ is an optional user reinforcement factor (default $1.0$).

### 3. Logarithmic Access Reinforcement
Human cognitive rehearsal strengthens synaptic pathways logarithmically. Memoria scales stability via:

$$\\text{Reinforcement}(N) = 1.0 + \\ln(1.0 + \\max(0, N))$$

Where $N$ represents the historical access count. The final adaptive stability $S_{\\text{adaptive}}$ is:

$$S_{\\text{adaptive}} = \\text{round}(S_{\\text{base}} \\times \\text{Reinforcement}(N), 2)$$

---

## 15.2 4-Factor Composite Hybrid Ranking Algorithm

When a query $q$ is issued, candidates $m_i$ are scored using a linear combination of four orthogonal relevance signals:

$$\\text{Score}(m_i, q) = w_v \\cdot V(m_i, q) + w_b \\cdot B(m_i, q) + w_r \\cdot R(\\Delta t_i) + w_i \\cdot I(m_i)$$

Where:
- **Weights Constraint**: $\\sum w = w_v + w_b + w_r + w_i = 0.45 + 0.20 + 0.25 + 0.10 = 1.00$.
- **Dense Vector Similarity** $V(m_i, q)$:
  $$V(m_i, q) = \\frac{1.0}{1.0 + D_C(\\mathbf{e}_q, \\mathbf{e}_{m_i})}$$
  Where $D_C(\\mathbf{u}, \\mathbf{v}) = 1 - \\frac{\\mathbf{u} \\cdot \\mathbf{v}}{\\|\\mathbf{u}\\|_2 \\|\\mathbf{v}\\|_2}$ represents cosine distance.
- **Normalized Sparse BM25** $B(m_i, q)$:
  $$B(m_i, q) = \\frac{\\text{BM25}(m_i, q)}{\\max_{j} \\text{BM25}(m_j, q)}$$
- **Retention Probability** $R(\\Delta t_i)$: Computed via the Adaptive Ebbinghaus decay function.
- **Importance Score** $I(m_i)$: The intrinsic permanence scalar $[0.0, 1.0]$.

---

## 15.3 Reciprocal Rank Fusion (RRF, $k=60$)

In the V2 benchmark pipeline, multi-source candidates from dense ChromaDB facts search and sparse BM25 retrieval are fused using Reciprocal Rank Fusion:

$$\\text{RRF}(d) = \\sum_{m \\in M} \\frac{1}{k + r_m(d)}$$

Where $M$ is the set of retrieval models, $r_m(d) \\in \\{1, 2, \\dots\\}$ is the 1-indexed rank of document $d$ in system $m$, and $k = 60$ is the standard smoothing constant preventing top ranks from dominating disproportionately.
"""
    }
    chapters.append(c15)

    # CHAPTER 16
    c16 = {
        "title": "Chapter 16: Complete End-to-End Execution Workflow",
        "content": """# Chapter 16: Complete End-to-End Execution Workflow

This chapter traces the complete end-to-end execution path of a user interaction through the Memoria framework, from initial HTTP request arrival to final response streaming.

---

## 16.1 Step-by-Step Execution Trace

```text
Step 1: HTTP Request Ingress
  │  Client dispatches HTTP POST /chat with payload:
  │  {"message": "I just adopted a golden retriever named Cooper!", "user_id": "alex"}
  ▼
Step 2: Authentication & Route Handling
  │  FastAPI validates payload against Pydantic schema ChatRequest.
  │  LatencyTracker initializes microsecond timing context.
  ▼
Step 3: Pre-Storage PII Sanitization
  │  PIIScrubber executes regex filters (phone, email, SSN).
  │  No PII detected; sanitized string matches input.
  ▼
Step 4: Question Detection & Filtering
  │  Heuristic parser checks for query punctuation ("?") or question interrogatives.
  │  Input is declarative (not a transient question); proceeds to LLM gate.
  ▼
Step 5: Semantic Classification & Importance Scoring
  │  Classified as category="fact" / "preference".
  │  Permanence score assigned: importance = 0.85 (pet adoption is long-term fact).
  ▼
Step 6: LLM Memory Gate Verification
  │  Memory gate prompt confirms assertion contains durable user personal fact.
  ▼
Step 7: Fact Distillation
  │  Converts 1st-person utterance into canonical 3rd-person assertion:
  │  "User has a golden retriever dog named Cooper."
  ▼
Step 8: Lineage Reconciliation against L2 ChromaDB
  │  Generates text-embedding-004 vector.
  │  Queries top-3 nearest memories for user_id="alex".
  │  LLM reconciliation classifies relationship as DISTINCT (no prior pet conflicts).
  ▼
Step 9: Storage Persistence (L2 Vector & L1 Buffer)
  │  Inserts distilled memory into ChromaDB memories collection with metadata:
  │  {"user_id": "alex", "category": "fact", "importance": 0.85, "status": "ACTIVE"}
  │  Pushes turn to L1 Working Memory ring buffer for immediate conversational context.
  ▼
Step 10: Hybrid Context Retrieval for Response
  │  HybridRetriever evaluates query relevance across active facts.
  │  Retrieves active facts (including the newly added pet fact).
  ▼
Step 11: Prompt Synthesis & LLM Generation
  │  Constructs augmented system prompt:
  │  "You are a personalized assistant. USER FACTS: [User has a golden retriever dog named Cooper.]"
  │  Dispatches to Gemini 3 Flash.
  ▼
Step 12: HTTP Response Egress
  │  Returns HTTP 200 OK with assistant response:
  │  "Congratulations on adopting Cooper! Golden retrievers are wonderful companions..."
```
"""
    }
    chapters.append(c16)

    # CHAPTER 17
    c17 = {
        "title": "Chapter 17: API Endpoints and Their Functionality",
        "content": """# Chapter 17: API Endpoints and Their Functionality

The Memoria framework provides a comprehensive RESTful API exposed via FastAPI. All endpoints support JSON payloads, asynchronous non-blocking processing, and standard HTTP status codes.

---

## 17.1 Endpoint Catalog

### 1. `POST /chat`
- **Purpose**: Primary conversational dialogue interface. Processes user turn, executes memory pipeline, retrieves context, and returns LLM response.
- **Request Body**:
```json
{
  "message": "I moved to Bengaluru yesterday.",
  "user_id": "alex",
  "image_url": null
}
```
- **Response (200 OK)**:
```json
{
  "response": "Welcome to Bengaluru! Let me know if you need any local recommendations.",
  "user_id": "alex",
  "retrieved_memories": [
    {
      "text": "User relocated to Bengaluru.",
      "category": "fact",
      "hybrid_score": 0.92
    }
  ],
  "latency_ms": 482.5
}
```

---

### 2. `POST /memory/add`
- **Purpose**: Direct programmatic ingestion of an atomic memory assertion, bypassing conversational chat.
- **Request Body**:
```json
{
  "text": "User is allergic to penicillin.",
  "user_id": "alex",
  "category": "health",
  "importance": 0.95
}
```
- **Response (200 OK)**:
```json
{
  "status": "success",
  "memory_id": "mem_9f8b3c1a",
  "action": "STORED",
  "tier": "L2_ACTIVE"
}
```

---

### 3. `POST /memory/retrieve`
- **Purpose**: Standalone memory retrieval using the 4-factor composite hybrid ranker.
- **Request Body**:
```json
{
  "query": "What are my programming skills?",
  "user_id": "alex",
  "top_k": 3
}
```
- **Response (200 OK)**:
```json
{
  "query": "What are my programming skills?",
  "results": [
    {
      "id": "mem_1a2b3c4d",
      "text": "User has extensive experience in Python and FastAPI.",
      "category": "skill",
      "hybrid_score": 0.9412,
      "breakdown": {
        "vector_score": 0.88,
        "bm25_score": 1.00,
        "retention": 0.98,
        "importance": 0.85
      }
    }
  ]
}
```

---

### 4. `GET /memory/profile?user_id=alex`
- **Purpose**: Retrieves synthesized persona profile and active facts for the specified user.
- **Response (200 OK)**:
```json
{
  "user_id": "alex",
  "persona": {
    "location": "Bengaluru",
    "skills": ["Python", "FastAPI"],
    "preferences": ["Vegetarian"]
  },
  "total_active_memories": 12
}
```

---

### 5. `GET /memory/stats`
- **Purpose**: System operational metrics, tier counts, and scheduler health.
- **Response (200 OK)**:
```json
{
  "status": "healthy",
  "tiers": {
    "l1_working_memory_turns": 8,
    "l2_active_vector_memories": 45,
    "l3_cold_archive_memories": 18
  },
  "scheduler": {
    "last_sweep_timestamp": "2026-10-31T02:00:00Z",
    "total_stale_archived": 12,
    "total_protected": 33
  }
}
```

---

### 6. `DELETE /memory/clear?user_id=alex`
- **Purpose**: GDPR Right-to-Forget compliance. Permanently deletes all records across L1, L2, and L3.
- **Response (200 OK)**:
```json
{
  "status": "success",
  "message": "All memories cleared for user alex across L1, L2, and L3 tiers."
}
```

---

### 7. `GET /health`
- **Purpose**: Health-check probe for load balancers and container orchestrators.
- **Response (200 OK)**:
```json
{
  "status": "healthy",
  "timestamp": "2026-10-31T02:25:00Z",
  "version": "1.0.0"
}
```
"""
    }
    chapters.append(c17)

    # CHAPTER 18
    c18 = {
        "title": "Chapter 18: Installation and Environment Configuration",
        "content": """# Chapter 18: Installation and Environment Configuration

This chapter provides step-by-step instructions for installing and configuring the Memoria framework in local development or production environments.

---

## 18.1 System Prerequisites
- **Operating System**: Windows 10/11, Ubuntu 20.04+, or macOS 12+
- **Python Runtime**: Python 3.11 or 3.12 (64-bit)
- **API Credentials**: Google Gemini API Key (obtainable via Google AI Studio)
- **Disk Space**: Minimum 2 GB free disk space for ChromaDB and SQLite databases

---

## 18.2 Repository Setup & Virtual Environment

### Windows (PowerShell):
```powershell
# Clone the repository
git clone <repository_url> memoria
cd memoria

# Create Python virtual environment
python -m venv .venv

# Activate virtual environment
.venv\\Scripts\\Activate.ps1

# Upgrade pip and install dependencies
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### Linux / macOS:
```bash
# Clone the repository
git clone <repository_url> memoria
cd memoria

# Create Python virtual environment
python3 -m venv .venv

# Activate virtual environment
source .venv/bin/activate

# Upgrade pip and install dependencies
pip install --upgrade pip
pip install -r requirements.txt
```

---

## 18.3 Environment Configuration (`.env`)
Create a `.env` file in the project root directory with the following variables:

```ini
# Google Gemini API Credential (Required)
GEMINI_API_KEY="AIzaSyYourActualAPIKeyHere"

# Server Configuration
HOST="127.0.0.1"
PORT=8000
DEBUG=false

# Memory Storage Paths
CHROMA_PERSIST_DIRECTORY="chroma_db"
SQLITE_DB_PATH="memory_os_archive.db"
FACTS_DB_PATH="facts.db"
CACHE_DB_PATH="llm_cache.db"

# Decay & Retention Constants
DECAY_HALF_LIFE_HOURS=48.0
STALE_RETENTION_THRESHOLD=0.15
IMPORTANT_PROTECTION_THRESHOLD=0.65

# Scheduler Settings
SCHEDULER_INTERVAL_SECONDS=60
```
"""
    }
    chapters.append(c18)

    # CHAPTER 19
    c19 = {
        "title": "Chapter 19: Step-by-Step Execution Instructions",
        "content": """# Chapter 19: Step-by-Step Execution Instructions

This chapter outlines standard execution commands for running the application, launching the test suite, and executing benchmarks.

---

## 19.1 Launching the FastAPI Server
To start the live asynchronous server:

```powershell
# Windows
.venv\\Scripts\\python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

Once running, access:
- **Interactive OpenAPI Documentation**: `http://127.0.0.1:8000/docs`
- **Alternative ReDoc Documentation**: `http://127.0.0.1:8000/redoc`
- **Health Probe**: `http://127.0.0.1:8000/health`

---

## 19.2 Executing the Automated Verification Suite
To run the full regression and unit test suite across all 9 memory modules:

```powershell
.venv\\Scripts\\python tests/run_evaluation.py
```

Expected output:
```text
============================================================
              MEMORIA EVALUATION REPORT
============================================================
Evaluator: Tier Retrieval               | Passed: 1/1 | 100.0%
Evaluator: Decay Engine                 | Passed: 1/1 | 100.0%
Evaluator: Restoration Engine           | Passed: 1/1 | 100.0%
Evaluator: Scheduler Engine             | Passed: 1/1 | 100.0%
Evaluator: Bengaluru Relocation         | Passed: 1/1 | 100.0%
Evaluator: Conversation Context         | Passed: 1/1 | 100.0%
Evaluator: Chennai Reconciliation       | Passed: 1/1 | 100.0%
Evaluator: Classification & Gate        | Passed: 1/1 | 100.0%
Evaluator: E2E Chat API                 | Passed: 1/1 | 100.0%
============================================================
Total Pass Rate: 100.0% (9/9 suites passed)
============================================================
```

---

## 19.3 Running LongMemEval Benchmark Systems
To run the LongMemEval benchmark harness across memory architectures:

```powershell
# Run V2 Pipeline on benchmark sample
.venv\\Scripts\\python bench/run.py --system v2 --limit 30

# Run V1 Pipeline on benchmark sample
.venv\\Scripts\\python bench/run.py --system v1 --limit 30

# Run Memoria Baseline (Sarin et al. 2025)
.venv\\Scripts\\python bench/run.py --system memoria --limit 30

# Run Full Context Baseline
.venv\\Scripts\\python bench/run.py --system full_context --limit 30

# Execute LLM Judge Evaluation
.venv\\Scripts\\python bench/judge.py bench/results/v2.jsonl
```
"""
    }
    chapters.append(c19)

    # CHAPTER 20
    c20 = {
        "title": "Chapter 20: Testing Methodology and Test Cases",
        "content": """# Chapter 20: Testing Methodology and Test Cases

Memoria implements a comprehensive, multi-layered testing methodology comprising isolated unit tests, state machine validation, integration tests, and simulated adversarial conversational scenarios.

---

## 20.1 Test Architecture & Suites

The verification suite (`tests/run_evaluation.py`) coordinates nine specialized evaluators:

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│                       NINE EVALUATION TEST SUITES                           │
│                                                                             │
│  [Suite 1] Tier Retrieval Evaluator       (L1, L2, L3 search & promotion)   │
│  [Suite 2] Decay Engine Evaluator         (Ebbinghaus decay & stability)    │
│  [Suite 3] Restoration Evaluator          (Cold archive reactivation)       │
│  [Suite 4] Scheduler Engine Evaluator     (7 lifecycle & safety tests)      │
│  [Suite 5] Bengaluru Relocation           (Temporal contradiction resolution│
│  [Suite 6] Conversation Context           (Ring buffer anaphora resolution) │
│  [Suite 7] Chennai Reconciliation         (Duplicate detection & access)    │
│  [Suite 8] Classification & Gate          (Small talk & query filtering)    │
│  [Suite 9] End-to-End Chat API            (Full HTTP integration)           │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 20.2 Detailed Test Case Specifications

### 1. Bengaluru Relocation (Contradiction Resolution)
- **Objective**: Verify that evolutionary factual assertions supersede outdated facts without duplicate coexistence.
- **Scenario**:
  - Turn 1: User states *"I live in Hyderabad."* System indexes memory as `ACTIVE`.
  - Turn 2: User states *"I relocated to Bengaluru last week."*
- **Assertions**:
  - Reconciliation classifies Turn 2 as `SUPERSEDES`.
  - Hyderabad memory transitions to `status = 'SUPERSEDED'`, `superseded_by = <bengaluru_id>`.
  - Bengaluru memory stored as `status = 'ACTIVE'`.
  - Hybrid retrieval for *"Where do I live?"* returns Bengaluru exclusively (100% accuracy).

### 2. Chennai Reconciliation (Duplicate Rehearsal)
- **Objective**: Verify that identical or confirming statements reinforce existing memories rather than creating duplicate vector records.
- **Scenario**:
  - Turn 1: *"I love South Indian filter coffee in Chennai."*
  - Turn 2: *"Filter coffee in Chennai is my absolute favorite."*
- **Assertions**:
  - Reconciliation classifies Turn 2 as `REINFORCES`.
  - Existing memory access count increments from 0 to 1.
  - Stability $S$ increases via logarithmic reinforcement.
  - Exactly one active record exists in ChromaDB (no duplicate pollution).

### 3. Lifecycle Scheduler & Important-Memory Protection
- **Objective**: Verify that background sweeps page out stale memories while preserving critical items.
- **Assertions**:
  - Stale memory ($R < 0.15, I < 0.60$) is written to L3 SQLite and deleted from L2 ChromaDB.
  - Protected memory ($I \\ge 0.65$ or access count $\\ge 2$) remains active in L2 despite elapsed decay.
  - Archival-first safety invariant prevents L2 deletion if L3 write fails.

### 4. Classification & Memory Gate
- **Objective**: Verify filtering of non-durable conversational noise.
- **Test Utterances**:
  - *"What time is it in London?"* $\\to$ Filtered (Question).
  - *"Thanks, that was very helpful!"* $\\to$ Rejected by LLM Memory Gate (Small talk).
  - *"I am learning Rust programming."* $\\to$ Approved by Gate, distilled, and indexed.
"""
    }
    chapters.append(c20)

    return chapters
