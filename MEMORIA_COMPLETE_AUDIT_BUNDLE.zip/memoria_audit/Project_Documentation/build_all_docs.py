"""
Master Documentation Builder for Memoria
Generates all three deliverables:
  1. Project_Documentation/DOCUMENTATION.md
  2. Project_Documentation/Memoria_Documentation.docx
  3. Project_Documentation/Memoria_Documentation.pdf
"""

import os
import sys

DOCS_DIR = os.path.dirname(os.path.abspath(__file__))
if DOCS_DIR not in sys.path:
    sys.path.insert(0, DOCS_DIR)

from generate_doc_text import generate_master_markdown, get_all_chapters, get_glossary
from build_docx import build_docx_report
from build_pdf import build_pdf_report

def main():
    print("=" * 70)
    print("   MEMORIA DOCUMENTATION GENERATION PIPELINE")
    print("=" * 70)

    # 1. Generate Markdown File
    md_path = os.path.join(DOCS_DIR, "DOCUMENTATION.md")
    print(f"\n[1/3] Generating Master Markdown: {md_path}...")
    md_content = generate_master_markdown()
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(md_content)
    md_size = os.path.getsize(md_path)
    print(f"      -> Created DOCUMENTATION.md ({md_size:,} bytes, {len(md_content.splitlines()):,} lines)")

    # 2. Generate DOCX File
    docx_path = os.path.join(DOCS_DIR, "Memoria_Documentation.docx")
    print(f"\n[2/3] Generating Professional DOCX: {docx_path}...")
    build_docx_report(docx_path)
    docx_size = os.path.getsize(docx_path)
    print(f"      -> Created Memoria_Documentation.docx ({docx_size:,} bytes)")

    # 3. Generate PDF File
    pdf_path = os.path.join(DOCS_DIR, "Memoria_Documentation.pdf")
    print(f"\n[3/3] Generating Publication-Quality PDF: {pdf_path}...")
    build_pdf_report(pdf_path)
    pdf_size = os.path.getsize(pdf_path)
    print(f"      -> Created Memoria_Documentation.pdf ({pdf_size:,} bytes)")

    print("\n" + "=" * 70)
    print("   ALL DOCUMENTATION DELIVERABLES SUCCESSFULLY GENERATED!")
    print("=" * 70)
    print(f"  - Markdown Document : {md_path} ({md_size:,} bytes)")
    print(f"  - Word Document     : {docx_path} ({docx_size:,} bytes)")
    print(f"  - PDF Document      : {pdf_path} ({pdf_size:,} bytes)")
    print(f"  - Total Chapters    : {len(get_all_chapters())} Chapters")
    print(f"  - Glossary Entries  : {len(get_glossary())} Defined Terms")
    print("=" * 70)

if __name__ == "__main__":
    main()
