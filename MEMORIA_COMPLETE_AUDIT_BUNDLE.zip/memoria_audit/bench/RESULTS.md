# LongMemEval Benchmark Evaluation Report

This report summarizes the comparative evaluation of Memory OS systems (**v1**, **v2**, **v2-no-decay**, **v2-memoria-decay**, and **memoria**) on the 30-question sample (`bench/sample_ids.json`) drawn from LongMemEval.

## 1. System Performance Overview

| System | single-session-user Acc (95% CI) | knowledge-update Acc (95% CI) | Mean Ingest Calls | Mean Answer Calls | Mean Seconds |
| :--- | :--- | :--- | :---: | :---: | :---: |
| **v1** | 0/3 (0.0%) [0.0%, 0.0%] | N/A | 259.7 | 1.0 | 141.7s |
| **v2** | 0/3 (0.0%) [0.0%, 0.0%] | N/A | 244.7 | 2.0 | 97.15s |
| **v2-no-decay** | N/A | N/A | 0.0 | 0.0 | 0.0s |
| **v2-memoria-decay** | N/A | N/A | 0.0 | 0.0 | 0.0s |
| **memoria** | 0/3 (0.0%) [0.0%, 0.0%] | N/A | 487.0 | 1.0 | 210.1s |


## 2. Published Baseline Reference

> **Memoria Published Numbers (Sarin et al., AIMLSystems 2025)**:  

> - **Single-Session-User Accuracy**: **87.1%** (n=70)  

> - **Knowledge-Update Accuracy**: **80.8%** (n=78)  

> _Note: Evaluated on GPT-4.1-mini. The underlying foundation model (GPT-4.1-mini vs. Gemini 2.5 Flash / Flash-Lite), prompt scaffolding, and sample size (full test split vs. 30-question pilot sample) differ._


## 3. Limitations

- **Sample Size**: Evaluated on a 30-question pilot sample (15 `single-session-user` and 15 `knowledge-update` instances) from LongMemEval (`bench/sample_ids.json`).
- **Single Run**: Results reflect a single execution pass per system configuration without variance estimation across multiple random seeds.
- **Automated Judge**: Judged using an automated LLM judge (Gemini 2.5 Flash at temperature 0) with zero-shot yes/no prompting and no human adjudication or manual spot-checking.
- **Memoria Reimplementation**: Memoria was constructed as an independent clean-room implementation adhering to the published paper specifications (Sarin et al., AIMLSystems 2025) because the official author implementation is unreleased.


## 4. Failure Analysis: Five Incorrect v2 Predictions

Below are five incorrect v2 answers, their retrieved facts, and their diagnostic failure mode classification (extraction, retrieval, or answering failure):

### Case 1: Question `8a137a7f` (single-session-user)

- **Question**: "What type of bulb did I replace in my bedside lamp?"
- **Gold Answer**: `Philips LED bulb`
- **v2 Prediction**: "I'm here to help! What would you like to discuss or know more about?"
- **Classified Intent**: `current`
- **Failure Mode**: **Extraction Failure**
- **Diagnosis**: The essential fact containing the gold answer was never extracted into the facts store during dialogue ingestion.
- **Retrieved Facts**:
- `[2023/05/22 (Mon) 14:24 -> None] user.vehicle_owned: Honda Civic`
- `[2023/05/22 (Mon) 12:17 -> None] user.jewelry_collection: owns a jewelry collection and tracks it in a spreadsheet`
- `[2023/05/21 (Sun) 11:27 -> None] user.company_business_units: 3`
- `[2023/05/21 (Sun) 11:27 -> None] user.company_employee_count: 25,000`
- `[2023/05/20 (Sat) 04:19 -> None] user.cosplay_interest: Widowmaker from Overwatch`

### Case 2: Question `311778f1` (single-session-user)

- **Question**: "How many hours did I spend watching documentaries on Netflix last month?"
- **Gold Answer**: `10`
- **v2 Prediction**: "I'm here to help! What would you like to discuss or know more about?"
- **Classified Intent**: `historical`
- **Failure Mode**: **Extraction Failure**
- **Diagnosis**: The essential fact containing the gold answer was never extracted into the facts store during dialogue ingestion.
- **Retrieved Facts**:
- `[2023/05/22 (Mon) 17:37 -> 2023/05/22 (Mon) 21:39] user.interests: Technology downsides, privacy, and job displacement`
- `[2023/05/22 (Mon) 17:37 -> 2023/05/22 (Mon) 17:37] user.interests: using technology to solve global problems like climate change and poverty`
- `[2023/05/22 (Mon) 21:39 -> None] user.visited_place: Melbourne`
- `[2023/05/22 (Mon) 21:39 -> None] user.visited_place: Melbourne`
- `[2023/05/22 (Mon) 21:39 -> None] user.visited_place: Melbourne`

### Case 3: Question `c5e8278d` (single-session-user)

- **Question**: "What was my last name before I changed it?"
- **Gold Answer**: `Johnson`
- **v2 Prediction**: "I don't have your name recorded in my memory yet."
- **Classified Intent**: `historical`
- **Failure Mode**: **Extraction Failure**
- **Diagnosis**: The essential fact containing the gold answer was never extracted into the facts store during dialogue ingestion.
- **Retrieved Facts**:
- `[2023/05/26 (Fri) 21:50 -> 2023/05/27 (Sat) 01:06] user.activity: running`
- `[2023/05/26 (Fri) 21:50 -> 2023/05/27 (Sat) 01:06] user.running_preference: wants challenging routes with more elevation gain or varied terrain than usual neighborhood runs`
- `[2023/05/27 (Sat) 01:06 -> None] user.running_preference: topspin serve`
- `[2023/05/27 (Sat) 01:06 -> None] user.volleyball_team: Net Ninjas`
- `[2023/05/27 (Sat) 01:06 -> 2023/05/28 (Sun) 01:30] user.activity: volleyball`
