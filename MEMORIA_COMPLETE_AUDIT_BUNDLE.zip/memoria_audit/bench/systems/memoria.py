"""
Memoria (Sarin et al., AIMLSystems 2025) Reimplementation for LongMemEval Benchmark.

PAPER SPECIFICATION GAPS AND IMPLEMENTATION CHOICES:
1. Triplet Extraction Prompt & Schema:
   The paper specifies extracting (subject, predicate, object) triplets from the USER message
   only using one LLM call, but does not provide the exact prompt template.
   CHOICE: We prompt Gemini with a strict JSON array schema requiring objects with keys
   "subject", "predicate", and "object", filtering out empty / non-informative turns.

2. Triplet Text Representation for Dense Embeddings:
   The paper does not detail how (subject, predicate, object) is serialized for vector embedding.
   CHOICE: Serialized as f"{subject} {predicate} {object}" and embedded using the shared
   sentence-transformers encoder (all-MiniLM-L6-v2) to compute cosine similarity in Chroma.

3. Session Identification & Boundary Tracking:
   The paper assumes distinct user sessions with a rolling summary per session, but does not
   specify how session boundaries are demarcated in offline benchmark streams.
   CHOICE: In LongMemEval, each session has a session_date. We key sessions by f"{user_id}_{now}"
   (or track the active session). Each turn within the session updates that session's rolling summary.

4. Rolling Session Summary Update Prompt:
   The paper states a rolling summary is updated with 1 LLM call per turn using user & assistant
   messages, but leaves the exact prompt undefined.
   CHOICE: We provide the previous session summary and the latest (user, assistant) turn to Gemini,
   instructing it to generate a concise, factual updated session summary (1-2 paragraphs max).

5. Degenerate Min-Max Age Normalization:
   The paper defines w_i = exp(-0.02 * x_i) where x is age in minutes min-max normalized to [0, 1]
   across the top-20 retrieved triplets. If all 20 triplets share the same timestamp (min == max),
   division by zero would occur.
   CHOICE: If max_age == min_age, set x_i = 0.0 for all retrieved triplets, yielding uniform base weights.

6. Empty Triplet Handling:
   If a user has 0 extracted triplets or fewer than 20 triplets available:
   CHOICE: We retrieve all available triplets up to 20. If 0 triplets exist, we note that in the prompt
   and let the LLM rely on the rolling session summary.

7. Prompt Formatting for Weighted Triplets & Answering:
   The paper does not provide the exact prompt layout combining weighted triplets and session summary.
   CHOICE: Triplets are formatted as "- [Weight: {w_i:.4f}] ({subject}, {predicate}, {object})",
   combined with the session summary and question in a structured system prompt.
"""

import os
import sys
import re
import json
import math
import uuid
import sqlite3
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

import chromadb
from app.core import clock
from app.embeddings.encoder import get_embedding
from app.llm.gemini import ask_gemini

MEMORIA_DB_PATH = os.path.join(ROOT_DIR, "memoria.db")

# Chroma collection setup for memoria_triplets
chroma_client = chromadb.PersistentClient(path="memory_db")
memoria_collection = chroma_client.get_or_create_collection(
    name="memoria_triplets",
    metadata={"hnsw:space": "cosine"}
)


def _init_sqlite():
    with sqlite3.connect(MEMORIA_DB_PATH, timeout=30.0) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS memoria_triplets (
                id TEXT PRIMARY KEY,
                user_id TEXT,
                subject TEXT,
                predicate TEXT,
                object TEXT,
                timestamp TEXT,
                created_at TEXT
            )
        """)
        conn.commit()


_init_sqlite()


def _parse_datetime(dt_val: Any) -> datetime:
    """Robust timestamp parser for ISO strings or datetime objects."""
    if isinstance(dt_val, datetime):
        return dt_val
    if not dt_val:
        return clock.get_now()
    s = str(dt_val).strip().replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(s)
    except Exception:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d", "%Y/%m/%d"):
        try:
            return datetime.strptime(s, fmt)
        except Exception:
            continue
    return clock.get_now()


def extract_triplets(user_msg: str) -> List[Dict[str, str]]:
    """
    Extracts (subject, predicate, object) triplets from the USER message only with ONE LLM call.
    """
    if not user_msg or not user_msg.strip():
        return []

    prompt = f"""You are a knowledge graph triplet extraction engine based on the Memoria architecture.
Extract all factual knowledge triplets from the USER message below.
Each triplet must be a (subject, predicate, object) representing facts, user preferences, traits, relationships, or actions.
Do NOT invent information. If the user message contains no new facts or triplets (e.g. simple greetings, questions with no statements), return an empty JSON array [].

USER MESSAGE:
"{user_msg}"

Respond ONLY with a JSON array of objects:
[
  {{"subject": "user", "predicate": "likes", "object": "science fiction"}},
  {{"subject": "user's car", "predicate": "is", "object": "blue sedan"}}
]"""

    response = ask_gemini(prompt, temperature=0.0)
    cleaned = response.strip()

    # Strip markdown fences if present
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
        cleaned = cleaned.strip()

    try:
        data = json.loads(cleaned)
        if isinstance(data, list):
            valid_triplets = []
            for item in data:
                if isinstance(item, dict) and "subject" in item and "predicate" in item and "object" in item:
                    sub = str(item["subject"]).strip()
                    pred = str(item["predicate"]).strip()
                    obj = str(item["object"]).strip()
                    if sub and pred and obj:
                        valid_triplets.append({"subject": sub, "predicate": pred, "object": obj})
            return valid_triplets
    except Exception:
        pass

    return []


def update_session_summary(
    previous_summary: str,
    user_msg: str,
    assistant_msg: str
) -> str:
    """
    Updates the rolling session summary from user and assistant messages with ONE LLM call.
    """
    prompt = f"""You are a rolling conversation summarizer for a conversational memory system.
Update the current session summary to incorporate the latest user and assistant turn.
Keep the summary factual, concise, and focused on key information, topics, and outcomes established in this session.

PREVIOUS SESSION SUMMARY:
{previous_summary if previous_summary else "No prior summary for this session."}

LATEST TURN:
User: {user_msg or "[None]"}
Assistant: {assistant_msg or "[None]"}

Provide ONLY the updated session summary in 1-2 paragraphs:"""

    response = ask_gemini(prompt, temperature=0.0)
    return response.strip()


class MemoriaSystem:
    """
    Memoria system adapter (Sarin et al., AIMLSystems 2025):
    - Ingest:
      1. Extract (subject, predicate, object) triplets from USER message only (1 LLM call).
      2. Store triplets in SQLite and Chroma (collection: memoria_triplets) with user_id and timestamp=now.
      3. Update rolling session summary from user and assistant messages (1 LLM call).
    - Answer:
      1. Top 20 triplets by cosine similarity (filtered by user_id).
      2. Weight w_i = exp(-0.02 * x_i), where x_i is age in minutes min-max normalized to [0,1],
         then normalized to sum to 1.
      3. Provide weighted triplets + current session summary in prompt to generate answer.
    """
    name = "memoria"

    def __init__(self):
        self.session_summaries: Dict[str, str] = {}
        self.last_session_key: Dict[str, str] = {}
        self.current_user_id: Optional[str] = None

    def reset(self):
        """Reset transient in-memory state."""
        self.session_summaries = {}
        self.last_session_key = {}
        self.current_user_id = None

    def ingest(self, user_id: str, user_msg: str, assistant_msg: str, now: Any):
        """
        Ingest one conversation turn:
        - clock.set_now(now)
        - Extract triplets from user_msg only -> SQLite + Chroma
        - Update rolling session summary -> self.session_summaries
        """
        clock.set_now(now)
        now_str = str(now)
        session_key = f"{user_id}_{now_str}"

        self.last_session_key[user_id] = session_key
        self.current_user_id = user_id

        # 1. Triplet Extraction (from user message only, 1 LLM call)
        if user_msg and user_msg.strip():
            triplets = extract_triplets(user_msg.strip())
            if triplets:
                # Save to SQLite
                with sqlite3.connect(MEMORIA_DB_PATH, timeout=30.0) as conn:
                    for t in triplets:
                        tid = str(uuid.uuid4())
                        conn.execute("""
                            INSERT INTO memoria_triplets (id, user_id, subject, predicate, object, timestamp, created_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                        """, (tid, user_id, t["subject"], t["predicate"], t["object"], now_str, clock.get_now().isoformat()))

                        # Save to Chroma
                        doc_text = f"{t['subject']} {t['predicate']} {t['object']}"
                        emb = get_embedding(doc_text)
                        memoria_collection.add(
                            ids=[tid],
                            embeddings=[emb],
                            documents=[doc_text],
                            metadatas=[{
                                "user_id": user_id,
                                "timestamp": now_str,
                                "subject": t["subject"],
                                "predicate": t["predicate"],
                                "object": t["object"]
                            }]
                        )

        # 2. Update rolling session summary (from user & assistant messages, 1 LLM call)
        prev_summary = self.session_summaries.get(session_key, "")
        updated_summary = update_session_summary(prev_summary, user_msg or "", assistant_msg or "")
        self.session_summaries[session_key] = updated_summary

    def answer(self, user_id: str, question: str, now: Any) -> str:
        """
        Answer question using Memoria retrieval and decay weighting:
        - Top 20 triplets by cosine similarity from Chroma (filtered by user_id).
        - Decay weight w_i = exp(-0.02 * x_i) where x_i is age in minutes normalized [0, 1].
        - Normalize weights to sum to 1.
        - Build prompt with weighted triplets + current session summary -> Gemini.
        """
        clock.set_now(now)
        now_dt = _parse_datetime(now)

        # 1. Retrieve top 20 triplets by cosine similarity from Chroma
        retrieved_triplets: List[Dict[str, Any]] = []
        try:
            q_emb = get_embedding(question)
            results = memoria_collection.query(
                query_embeddings=[q_emb],
                n_results=20,
                where={"user_id": user_id}
            )

            if results and results.get("ids") and results["ids"] and results["ids"][0]:
                ids = results["ids"][0]
                metadatas = results["metadatas"][0] if results.get("metadatas") else []
                distances = results["distances"][0] if results.get("distances") else []

                for idx, tid in enumerate(ids):
                    meta = metadatas[idx] if idx < len(metadatas) else {}
                    dist = distances[idx] if idx < len(distances) else 0.0
                    sub = meta.get("subject", "")
                    pred = meta.get("predicate", "")
                    obj = meta.get("object", "")
                    ts = meta.get("timestamp", str(now))

                    trip_dt = _parse_datetime(ts)
                    age_minutes = max(0.0, (now_dt - trip_dt).total_seconds() / 60.0)

                    retrieved_triplets.append({
                        "id": tid,
                        "subject": sub,
                        "predicate": pred,
                        "object": obj,
                        "timestamp": ts,
                        "age_minutes": age_minutes,
                        "distance": dist
                    })
        except Exception as e:
            print(f"[Memoria] Retrieval warning: {e}")

        # 2. Calculate normalized weights w_i = exp(-0.02 * x_i)
        if retrieved_triplets:
            ages = [t["age_minutes"] for t in retrieved_triplets]
            min_age = min(ages)
            max_age = max(ages)
            age_range = max_age - min_age

            raw_weights = []
            for t in retrieved_triplets:
                if age_range > 0:
                    x_i = (t["age_minutes"] - min_age) / age_range
                else:
                    x_i = 0.0
                t["x_norm"] = x_i
                w_i = math.exp(-0.02 * x_i)
                raw_weights.append(w_i)
                t["raw_weight"] = w_i

            total_weight = sum(raw_weights)
            for idx, t in enumerate(retrieved_triplets):
                t["weight"] = (raw_weights[idx] / total_weight) if total_weight > 0 else (1.0 / len(retrieved_triplets))

            # Format triplets block
            triplet_lines = [
                f"- [Weight: {t['weight']:.4f}] ({t['subject']}, {t['predicate']}, {t['object']}) [Timestamp: {t['timestamp']}]"
                for t in retrieved_triplets
            ]
            triplets_block = "\n".join(triplet_lines)
        else:
            triplets_block = "No memory triplets retrieved for user."

        # 3. Retrieve current session's summary
        current_session = self.last_session_key.get(user_id)
        current_summary = self.session_summaries.get(current_session, "") if current_session else ""
        if not current_summary:
            current_summary = "No session summary recorded."

        # 4. Construct prompt with weighted triplets and session summary
        prompt = f"""SYSTEM:
You are an intelligent assistant equipped with the Memoria long-term memory system.
Below are relevant knowledge triplets extracted from the user's past messages, weighted by relevance and temporal recency (weights sum to 1.0), along with the current conversation session's summary.

MEMORY TRIPLETS:
{triplets_block}

CURRENT SESSION SUMMARY:
{current_summary}

USER QUESTION:
{question}

INSTRUCTIONS:
- Answer the user's question directly, accurately, and concisely based on the MEMORY TRIPLETS and CURRENT SESSION SUMMARY.
- Pay attention to higher-weighted triplets and more recent timestamps when facts conflict.
- If the answer cannot be determined from memory, state that clearly and concisely without hallucinating.
"""

        response = ask_gemini(prompt)
        return response


def get_system():
    return MemoriaSystem()
