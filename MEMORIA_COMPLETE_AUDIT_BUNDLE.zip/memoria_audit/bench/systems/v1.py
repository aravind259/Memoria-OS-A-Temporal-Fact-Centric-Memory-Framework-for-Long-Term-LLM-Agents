import os
import sys
from typing import Any, Optional

# Ensure root directory is on PYTHONPATH
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from app.core import clock
from app.llm.gemini import ask_gemini
from app.core.container import memory_manager as default_memory_manager


class V1System:
    """
    Adapter around the existing MemoryManager for LongMemEval benchmarking.
    - ingest(user_id, user_msg, assistant_msg, now):
        calls clock.set_now(now) and stores the turn.
    - answer(user_id, question, now) -> str:
        calls clock.set_now(now), retrieves memories, builds the prompt the app normally uses, and asks Gemini.
    """
    name = "v1"

    def __init__(self, manager=None):
        self.manager = manager or default_memory_manager
        self.current_user_id: Optional[str] = None

    def reset(self):
        """Resets working memory state between benchmark instances."""
        if self.manager and self.manager.working_memory:
            self.manager.working_memory.clear()
        self.current_user_id = None

    def ingest(self, user_id: str, user_msg: str, assistant_msg: str, now: Any):
        """
        Calls clock.set_now(now) and then stores the turn into the storage and working memory tiers.
        """
        if self.current_user_id != user_id:
            self.reset()
            self.current_user_id = user_id

        clock.set_now(now)

        if not user_msg and not assistant_msg:
            return

        # Store turn in memory storage pipeline
        res = self.manager.storage.store(
            user_message=user_msg or "",
            ai_response=assistant_msg or "",
            user_id=user_id,
            tenant_id="default_tenant"
        )

        # Add turn to short-term working memory
        if self.manager.working_memory:
            category = res.get("category") if isinstance(res, dict) else "Conversation"
            importance = res.get("importance", 0.5) if isinstance(res, dict) else 0.5
            self.manager.working_memory.add_turn(
                user_message=user_msg or "",
                ai_response=assistant_msg or "",
                category=category,
                importance=importance
            )

    def answer(self, user_id: str, question: str, now: Any) -> str:
        """
        Calls clock.set_now(now), retrieves memories, builds the prompt the app normally uses, and asks Gemini.
        """
        clock.set_now(now)

        # 1. Fetch short-term working memory context
        short_term_context = []
        if self.manager.working_memory:
            short_term_context = self.manager.working_memory.get_short_term_context()

        # 2. Retrieve long-term memories
        memories = self.manager.retriever.retrieve(question, user_id=user_id)

        # 3. Retrieve relevant persona context
        relevant_persona = ""
        if hasattr(self.manager, "persona_engine") and self.manager.persona_engine:
            try:
                relevant_persona = self.manager.persona_engine.get_relevant_persona(query=question, user_id=user_id)
            except Exception as e:
                print(f"[V1System] Persona engine warning: {e}")

        # 4. Build standard application prompt
        prompt = self.manager.prompt_builder.build(
            memories=memories,
            user_message=question,
            persona_summary=relevant_persona,
            visual_summary="",
            short_term_context=short_term_context
        )

        # 5. Query Gemini API (wrapped with SQLite cache and metrics)
        response = ask_gemini(prompt)
        return response


# Factory function for benchmark runner
def get_system():
    return V1System()
