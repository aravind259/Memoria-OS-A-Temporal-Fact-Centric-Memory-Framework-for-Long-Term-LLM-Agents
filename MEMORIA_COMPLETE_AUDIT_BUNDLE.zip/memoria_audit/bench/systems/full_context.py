import os
import sys
from typing import Any, Optional, List, Dict

# Ensure project root is on PYTHONPATH
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from app.core import clock
from app.llm.gemini import ask_gemini


class FullContextSystem:
    """
    Full Context Baseline for LongMemEval:
    Puts the entire haystack dialogue history across all sessions into a single prompt context,
    followed by the test question.
    """
    name = "full_context"

    def __init__(self):
        self.turns_by_user: Dict[str, List[Dict[str, str]]] = {}
        self.current_user_id: Optional[str] = None

    def reset(self):
        self.turns_by_user.clear()
        self.current_user_id = None

    def ingest(self, user_id: str, user_msg: str, assistant_msg: str, now: Any):
        if self.current_user_id != user_id:
            self.current_user_id = user_id

        if user_id not in self.turns_by_user:
            self.turns_by_user[user_id] = []

        clock.set_now(now)
        self.turns_by_user[user_id].append({
            "timestamp": str(now),
            "user": user_msg or "",
            "assistant": assistant_msg or ""
        })

    def answer(self, user_id: str, question: str, now: Any) -> str:
        clock.set_now(now)
        history_turns = self.turns_by_user.get(user_id, [])

        history_lines = []
        for t in history_turns:
            ts = t.get("timestamp", "")
            u = t.get("user", "")
            a = t.get("assistant", "")
            history_lines.append(f"[{ts}] User: {u}")
            if a:
                history_lines.append(f"[{ts}] Assistant: {a}")

        history_text = "\n".join(history_lines)

        prompt = f"""SYSTEM:
You are a precise, helpful AI assistant. Answer the user's question directly, accurately, and concisely based on the preceding conversation history.

CONVERSATION HISTORY:
{history_text}

AS OF DATE:
{now}

USER QUESTION:
{question}

INSTRUCTIONS:
- Answer the user's question directly using the conversation history.
- Be concise and provide the exact answer (e.g. brand, number, name, or fact requested).
- If the answer changed over time, provide the most recent information as of the date.
"""

        response = ask_gemini(prompt)
        return response


def get_system():
    return FullContextSystem()
