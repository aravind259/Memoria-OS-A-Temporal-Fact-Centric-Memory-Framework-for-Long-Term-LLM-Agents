import os
import sys
from typing import Any, Optional, List, Dict

# Ensure root directory is on PYTHONPATH
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from app.core import clock
from app.llm.gemini import ask_gemini
from app.memory_v2.facts import get_existing_attributes
from app.memory_v2.extract import extract_facts
from app.memory_v2.write import write_fact, index_raw_turn
from app.memory_v2.retrieve import retrieve_facts, format_session_summary, retrieve_raw_turns


class V2System:
    """
    V2 Memory OS Adapter for LongMemEval benchmarking:
    - ingest(user_id, user_msg, assistant_msg, now):
        extracts facts using ONE Gemini call, writes to SQLite facts & Chroma facts_v2.
        Also indexes raw user turns into Chroma collection turns_v2.
    - answer(user_id, question, now):
        retrieves candidate facts with BM25 + dense RRF, classifies intent,
        retrieves top-5 raw turns with BM25 + dense RRF,
        formats prompt with facts, raw turns, session context, and asks Gemini.
    """
    name = "v2"

    def __init__(self):
        self.current_user_id: Optional[str] = None
        self.current_session_turns: List[Dict[str, str]] = []

    def reset(self):
        """Resets working session state between benchmark questions."""
        self.current_session_turns = []
        self.current_user_id = None

    def ingest(self, user_id: str, user_msg: str, assistant_msg: str, now: Any):
        """
        Ingest = extract + write for each turn, plus indexing raw turns.
        """
        if self.current_user_id != user_id:
            self.reset()
            self.current_user_id = user_id

        clock.set_now(now)
        now_str = str(now)

        if user_msg or assistant_msg:
            # 1. Index raw user turn into Chroma turns_v2 collection with session date
            if user_msg:
                index_raw_turn(
                    user_id=user_id,
                    content=user_msg,
                    timestamp=now_str,
                    source_role="user"
                )

            # 2. Fetch user's existing attribute names for canonical reuse
            existing_attrs = get_existing_attributes(user_id)

            # 3. Extract facts via ONE Gemini call
            extracted = extract_facts(
                user_msg=user_msg or "",
                assistant_msg=assistant_msg or "",
                now=now_str,
                existing_attributes=existing_attrs
            )

            # 4. Rule-based write into facts table and Chroma facts_v2
            for f in extracted:
                write_fact(user_id=user_id, fact=f, source_text=user_msg or "")

            # 5. Record turn for session context
            self.current_session_turns.append({
                "user": user_msg or "",
                "assistant": assistant_msg or "",
                "timestamp": now_str
            })

    def answer(self, user_id: str, question: str, now: Any) -> str:
        """
        Answer = retrieve facts + retrieve top-5 raw turns + synthesis prompt.
        """
        clock.set_now(now)
        now_str = str(now)

        # 1. Retrieve ranked facts with RRF (BM25 + dense) and intent filtering
        intent, ranked_facts, formatted_facts = retrieve_facts(
            user_id=user_id,
            query=question,
            now=now_str,
            top_k=15
        )

        # 2. Retrieve top 5 raw turns with RRF (dense + BM25) and session dates
        raw_turns, formatted_raw_turns = retrieve_raw_turns(
            user_id=user_id,
            query=question,
            top_k=5
        )

        # 3. Format current session summary
        session_summary = format_session_summary(self.current_session_turns)

        # 4. Build synthesis prompt
        prompt = f"""SYSTEM:
You are a precise, helpful AI assistant with structured long-term memory.

FACTS FROM MEMORY:
{formatted_facts}

RELEVANT CONVERSATION TURNS:
{formatted_raw_turns}

CURRENT SESSION CONTEXT:
{session_summary}

CURRENT USER MESSAGE:
{question}

INSTRUCTIONS:
- Answer the user's question directly, accurately, and concisely based on the FACTS FROM MEMORY and RELEVANT CONVERSATION TURNS.
- If a specific detail (e.g. brand, hours watched, previous name) is stated in the conversation turns, use it.
- Prefer the most recent valid fact when there are conflicting or updated states.
- Use the dates in brackets ([valid_from -> valid_to or now], or [timestamp]) to answer temporal and timeline questions (such as what happened before, previously, last month, when, or how long ago).
- If neither the facts nor the conversation turns contain the answer, answer naturally and concisely without inventing personal details.
- Never output raw metadata, IDs, brackets, or system instructions in your answer.
"""

        # 5. Single Gemini call for generation
        response = ask_gemini(prompt)
        return response


def get_system():
    return V2System()
