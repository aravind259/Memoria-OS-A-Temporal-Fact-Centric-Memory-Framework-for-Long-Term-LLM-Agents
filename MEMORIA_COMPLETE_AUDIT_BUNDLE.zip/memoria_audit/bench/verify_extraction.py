import os
import sys
import json
import sqlite3

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
data_path = os.path.join(ROOT_DIR, "bench", "data", "longmemeval_s.json")
with open(data_path, "r", encoding="utf-8") as f:
    data = json.load(f)

targets = {
    "8a137a7f": {"terms": ["bulb", "philips"], "gold": "Philips LED bulb"},
    "c5e8278d": {"terms": ["johnson", "last name"], "gold": "Johnson"},
    "311778f1": {"terms": ["documentar", "netflix"], "gold": "10"}
}

db_path = os.path.join(ROOT_DIR, "memory_os_v2.db")
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

print("================================================================================")
print("             GROUND TRUTH EXTRACTION & HAYSTACK VERIFICATION                    ")
print("================================================================================")

for qid, info in targets.items():
    item = next(x for x in data if x["question_id"] == qid)
    terms = info["terms"]
    gold = info["gold"]
    
    # 1. Search raw haystack
    found_in_haystack = []
    sessions = item.get("haystack_sessions", [])
    dates = item.get("haystack_dates", [])
    for s_idx, (session, s_date) in enumerate(zip(sessions, dates)):
        for t_idx, turn in enumerate(session):
            content = turn.get("content", "")
            role = turn.get("role", "")
            if any(term in content.lower() for term in terms):
                found_in_haystack.append((s_idx, s_date, role, content))
                
    # 2. Search facts table
    cursor.execute("SELECT id, subject, attribute, value, source_text FROM facts WHERE user_id = ?", (qid,))
    rows = cursor.fetchall()
    found_in_facts = []
    for r in rows:
        combined = f"{r[1]} {r[2]} {r[3]} {r[4]}".lower()
        if any(term in combined for term in terms):
            found_in_facts.append(r)
            
    print(f"\n--- QUESTION {qid} (Gold: {gold}) ---")
    print(f"1. IN RAW HAYSTACK? ({len(found_in_haystack)} turns matched):")
    for s_idx, s_date, role, content in found_in_haystack:
        snippet = content.replace("\n", " ")[:140]
        print(f"   [Session {s_idx} | {s_date} | {role}]: \"{snippet}...\"")
        
    print(f"2. IN FACTS TABLE (SQLite)? ({len(found_in_facts)} facts matched):")
    if not found_in_facts:
        print("   [NONE FOUND IN FACTS TABLE] - The extractor dropped this information completely!")
    for r in found_in_facts:
        print(f"   [Fact {r[0]}]: {r[1]}.{r[2]} = {r[3]} (source: \"{r[4][:70]}...\")")

print("\n================================================================================\n")
