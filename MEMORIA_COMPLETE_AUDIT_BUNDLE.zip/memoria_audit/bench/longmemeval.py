import os
import sys
import json
import random
import time
import argparse
from typing import List, Dict, Any, Optional, Tuple

# Ensure root directory is on PYTHONPATH
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from app.core import metrics
from app.core import clock

DATA_DIR = os.path.join(ROOT_DIR, "bench", "data")
RESULTS_DIR = os.path.join(ROOT_DIR, "bench", "results")
SAMPLE_IDS_PATH = os.path.join(ROOT_DIR, "bench", "sample_ids.json")
DEFAULT_DATA_PATH = os.path.join(DATA_DIR, "longmemeval_s.json")


def download_dataset(dest_path: Optional[str] = None) -> str:
    """
    Downloads longmemeval_s from Hugging Face dataset xiaowu0162/longmemeval into bench/data/.
    """
    dest_path = dest_path or DEFAULT_DATA_PATH
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)

    if not os.path.exists(dest_path):
        alt_path = os.path.join(DATA_DIR, "longmemeval_s")
        if os.path.exists(alt_path):
            return alt_path

        from huggingface_hub import hf_hub_download
        print("[longmemeval] Downloading xiaowu0162/longmemeval (longmemeval_s)...")
        cached_file = hf_hub_download(
            repo_id="xiaowu0162/longmemeval",
            filename="longmemeval_s",
            repo_type="dataset"
        )
        import shutil
        shutil.copyfile(cached_file, dest_path)
        print(f"[longmemeval] Downloaded to {dest_path}")

    return dest_path


def load_dataset(data_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Loads dataset and confirms field names.
    """
    path = data_path or DEFAULT_DATA_PATH
    if not os.path.exists(path):
        alt_path = os.path.join(DATA_DIR, "longmemeval_s")
        if os.path.exists(alt_path):
            path = alt_path
        else:
            path = download_dataset(path)

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    return data


def print_item_keys(item: Dict[str, Any]):
    """
    Prints the keys of one item to confirm expected field names:
    question_id, question_type, question, answer, question_date, haystack_dates, haystack_sessions.
    """
    keys = list(item.keys())
    print("\n------------------------------------------------------------")
    print(f"Item Keys ({len(keys)} keys): {keys}")
    expected_keys = [
        "question_id", "question_type", "question", "answer",
        "question_date", "haystack_dates", "haystack_sessions"
    ]
    for ek in expected_keys:
        present = "OK" if ek in item else "MISSING"
        print(f"  [{present}] {ek}")
    print("------------------------------------------------------------\n")


def sample(
    n_per_type: int = 15,
    types: Tuple[str, ...] = ("single-session-user", "knowledge-update"),
    seed: int = 0,
    data: Optional[List[Dict[str, Any]]] = None
) -> List[Dict[str, Any]]:
    """
    Returns a fixed, seeded sample and saves the chosen question_ids to bench/sample_ids.json.
    If bench/sample_ids.json already exists, loads the exact items for those question_ids.
    """
    if data is None:
        data = load_dataset()

    if os.path.exists(SAMPLE_IDS_PATH):
        try:
            with open(SAMPLE_IDS_PATH, "r", encoding="utf-8") as f:
                saved_ids = json.load(f)
            id_to_item = {item["question_id"]: item for item in data}
            sampled = [id_to_item[qid] for qid in saved_ids if qid in id_to_item]
            if len(sampled) == len(saved_ids):
                print(f"[longmemeval] Loaded {len(sampled)} items from existing {SAMPLE_IDS_PATH}")
                return sampled
        except Exception as e:
            print(f"[longmemeval] Warning reading {SAMPLE_IDS_PATH}: {e}")

    rng = random.Random(seed)
    sampled: List[Dict[str, Any]] = []

    for qtype in types:
        matching = [item for item in data if item.get("question_type") == qtype]
        chosen = rng.sample(matching, min(n_per_type, len(matching)))
        sampled.extend(chosen)

    chosen_ids = [item["question_id"] for item in sampled]
    os.makedirs(os.path.dirname(SAMPLE_IDS_PATH), exist_ok=True)
    with open(SAMPLE_IDS_PATH, "w", encoding="utf-8") as f:
        json.dump(chosen_ids, f, indent=2)

    print(f"[longmemeval] Sampled {len(sampled)} items across types {types}. Saved IDs to {SAMPLE_IDS_PATH}")
    return sampled


def run_system(
    system: Any,
    items: List[Dict[str, Any]],
    system_name: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Runs a memory system on benchmark items:
      - system is an object with:
          ingest(user_id, user_msg, assistant_msg, now)
          answer(user_id, question, now) -> str
      - For each item:
          user_id = question_id
          For each session and its date:
            walk turns in user/assistant pairs and call ingest with now = that session's date
          Then call answer(question) with now = question_date
          Reset metrics before each item and save per-item metrics
      - Supports resuming from previously completed questions in bench/results/<system_name>.jsonl
    """
    name = system_name or getattr(system, "name", None) or getattr(system, "__name__", None) or system.__class__.__name__
    os.makedirs(RESULTS_DIR, exist_ok=True)
    output_path = os.path.join(RESULTS_DIR, f"{name}.jsonl")

    completed_qids = set()
    results = []

    if os.path.exists(output_path):
        with open(output_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        rec = json.loads(line)
                        qid = rec.get("question_id")
                        if qid:
                            completed_qids.add(qid)
                            results.append(rec)
                    except Exception:
                        pass
        if completed_qids:
            print(f"[longmemeval] Found {len(completed_qids)} completed questions in {output_path}. Resuming remaining items...", flush=True)

    with open(output_path, "a", encoding="utf-8") as out_f:
        for idx, item in enumerate(items, 1):
            qid = item["question_id"]
            qtype = item.get("question_type", "")
            question = item.get("question", "")
            gold_answer = item.get("answer", "")
            q_date = item.get("question_date", "")

            if qid in completed_qids:
                print(f"[{idx}/{len(items)}] Skipping question {qid} (already completed)", flush=True)
                continue

            sessions = item.get("haystack_sessions", [])
            dates = item.get("haystack_dates", [])

            # Reset metrics before each item
            metrics.reset()
            item_start_time = time.time()
            print(f"[{idx}/{len(items)}] Starting question {qid} ({qtype}) with {len(sessions)} sessions...", flush=True)

            # Ingest all historical sessions
            for s_idx, (session, session_date) in enumerate(zip(sessions, dates), 1):
                if s_idx % 15 == 0 or s_idx == len(sessions):
                    print(f"  [{qid}] Processed {s_idx}/{len(sessions)} sessions...", flush=True)
                i = 0
                while i < len(session):
                    curr = session[i]
                    role = curr.get("role", "")
                    content = curr.get("content", "")

                    if role == "user":
                        user_msg = content
                        assistant_msg = ""
                        if i + 1 < len(session) and session[i + 1].get("role") == "assistant":
                            assistant_msg = session[i + 1].get("content", "")
                            i += 2
                        else:
                            i += 1

                        try:
                            system.ingest(qid, user_msg, assistant_msg, session_date)
                        except TypeError:
                            system.ingest(user_id=qid, user_msg=user_msg, assistant_msg=assistant_msg, now=session_date)
                    else:
                        i += 1

            # Query system for answer as of question_date
            try:
                prediction = system.answer(qid, question, q_date)
            except TypeError:
                try:
                    prediction = system.answer(user_id=qid, question=question, now=q_date)
                except TypeError:
                    prediction = system.answer(question, now=q_date)

            item_elapsed = round(time.time() - item_start_time, 4)
            snap = metrics.snapshot()
            llm_calls = snap.get("llm_calls", snap.get("misses", 0))
            seconds = snap.get("seconds", snap.get("total_seconds", item_elapsed))

            record = {
                "question_id": qid,
                "type": qtype,
                "question": question,
                "gold answer": gold_answer,
                "gold_answer": gold_answer,
                "prediction": prediction,
                "LLM calls": llm_calls,
                "llm_calls": llm_calls,
                "seconds": seconds,
                "metrics": snap
            }

            out_f.write(json.dumps(record) + "\n")
            out_f.flush()
            results.append(record)
            print(f"[{idx}/{len(items)}] ID: {qid} | Type: {qtype} | Calls: {llm_calls} | Time: {seconds}s", flush=True)

    print(f"\n[longmemeval] Saved {len(results)} results to {output_path}", flush=True)
    return results


def main():
    parser = argparse.ArgumentParser(description="LongMemEval Benchmark Suite")
    parser.add_argument("--dry-run", action="store_true", help="Print 30 sampled ids and turn counts")
    parser.add_argument("--seed", type=int, default=0, help="Random seed for sampling")
    parser.add_argument("--n-per-type", type=int, default=15, help="Number of items per category")
    args = parser.parse_args()

    data = load_dataset()
    if data:
        print_item_keys(data[0])

    sampled_items = sample(
        n_per_type=args.n_per_type,
        types=("single-session-user", "knowledge-update"),
        seed=args.seed,
        data=data
    )

    if args.dry_run:
        print("\n============================================================")
        print("          LONGMEMEVAL DRY-RUN: 30 SAMPLED ITEMS             ")
        print("============================================================")
        for idx, item in enumerate(sampled_items, 1):
            qid = item["question_id"]
            qtype = item.get("question_type", "")
            sessions = item.get("haystack_sessions", [])
            total_turns = sum(len(s) for s in sessions)
            print(f"{idx:2d}. {qid:<15} | Type: {qtype:<22} | Turns: {total_turns} across {len(sessions)} sessions")
        print("============================================================\n")


if __name__ == "__main__":
    main()
