import os
import sys
import json
import sqlite3
import re
from typing import List, Dict, Any, Optional, Tuple

# Ensure project root is on PYTHONPATH
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from bench.judge import score, compute_bootstrap_ci, judge_prediction
from app.memory_v2.retrieve import retrieve_facts
from app.memory_v2.facts import get_connection

RESULTS_DIR = os.path.join(ROOT_DIR, "bench", "results")
REPORT_PATH = os.path.join(ROOT_DIR, "bench", "RESULTS.md")
FACTS_DB_PATH = os.path.join(ROOT_DIR, "memory_os_v2.db")


SYSTEM_SPECS = [
    {"key": "v1", "file": "v1.jsonl", "display": "v1", "answer_calls_default": 1},
    {"key": "v2", "file": "v2.jsonl", "display": "v2", "answer_calls_default": 2},
    {"key": "v2_decay_none", "file": "v2_decay_none.jsonl", "display": "v2-no-decay", "answer_calls_default": 2},
    {"key": "v2_decay_memoria", "file": "v2_decay_memoria.jsonl", "display": "v2-memoria-decay", "answer_calls_default": 2},
    {"key": "memoria", "file": "memoria.jsonl", "display": "memoria", "answer_calls_default": 1},
]


def load_jsonl(path: str) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        return []
    records = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    records.append(json.loads(line))
                except Exception:
                    pass
    return records


def analyze_system(spec: Dict[str, Any]) -> Dict[str, Any]:
    file_path = os.path.join(RESULTS_DIR, spec["file"])
    records = load_jsonl(file_path)
    if not records:
        return {
            "display": spec["display"],
            "count": 0,
            "single_session_acc": "N/A",
            "knowledge_update_acc": "N/A",
            "mean_ingest_calls": 0.0,
            "mean_answer_calls": 0.0,
            "mean_seconds": 0.0,
            "judged_records": []
        }

    # Run judge scoring
    summary = score(file_path)
    judged_records = summary.get("records", [])

    # Group accuracy by question_type
    per_type = summary.get("per_type", {})
    ss_stats = per_type.get("single-session-user", {"correct": 0, "total": 0, "ci_95": (0.0, 0.0)})
    ku_stats = per_type.get("knowledge-update", {"correct": 0, "total": 0, "ci_95": (0.0, 0.0)})

    def format_acc(stats: Dict[str, Any]) -> str:
        tot = stats.get("total", 0)
        c = stats.get("correct", 0)
        if tot == 0:
            return "N/A"
        pct = (c / tot) * 100.0
        ci = stats.get("ci_95", (0.0, 0.0))
        return f"{c}/{tot} ({pct:.1f}%) [{ci[0]*100:.1f}%, {ci[1]*100:.1f}%]"

    single_session_str = format_acc(ss_stats)
    knowledge_update_str = format_acc(ku_stats)

    # Compute mean LLM calls and seconds
    ingest_calls_list = []
    answer_calls_list = []
    seconds_list = []

    for r in records:
        total_calls = r.get("LLM calls", r.get("llm_calls", 0))
        sec = r.get("seconds", 0.0)
        seconds_list.append(sec)

        if "ingest_calls" in r and "answer_calls" in r:
            ingest_calls_list.append(r["ingest_calls"])
            answer_calls_list.append(r["answer_calls"])
        else:
            ans_default = spec["answer_calls_default"]
            ans_c = min(total_calls, ans_default)
            ing_c = max(0, total_calls - ans_c)
            ingest_calls_list.append(ing_c)
            answer_calls_list.append(ans_c)

    mean_ingest = sum(ingest_calls_list) / len(ingest_calls_list) if ingest_calls_list else 0.0
    mean_answer = sum(answer_calls_list) / len(answer_calls_list) if answer_calls_list else 0.0
    mean_sec = sum(seconds_list) / len(seconds_list) if seconds_list else 0.0

    return {
        "display": spec["display"],
        "count": len(records),
        "single_session_acc": single_session_str,
        "knowledge_update_acc": knowledge_update_str,
        "mean_ingest_calls": round(mean_ingest, 1),
        "mean_answer_calls": round(mean_answer, 1),
        "mean_seconds": round(mean_sec, 2),
        "judged_records": judged_records
    }


def get_stored_user_facts(user_id: str) -> List[Dict[str, Any]]:
    if not os.path.exists(FACTS_DB_PATH):
        return []
    try:
        conn = get_connection(FACTS_DB_PATH)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, subject, attribute, value, kind, valid_from, valid_to, status, source_text FROM facts WHERE user_id = ?",
            (user_id,)
        )
        rows = cursor.fetchall()
        conn.close()
        return [
            {
                "id": r[0], "subject": r[1], "attribute": r[2], "value": r[3],
                "kind": r[4], "valid_from": r[5], "valid_to": r[6], "status": r[7], "source_text": r[8]
            }
            for r in rows
        ]
    except Exception as e:
        print(f"[report] Error reading facts for {user_id}: {e}")
        return []


def analyze_v2_failures(v2_judged_records: List[Dict[str, Any]], top_n: int = 5) -> List[Dict[str, Any]]:
    failures = []
    for rec in v2_judged_records:
        if rec.get("is_correct") is False:
            failures.append(rec)

    failure_reports = []

    for item in failures[:top_n]:
        qid = item.get("question_id", "")
        question = item.get("question", "")
        gold = item.get("gold answer") or item.get("gold_answer", "")
        pred = item.get("prediction", "")
        qtype = item.get("type") or item.get("question_type", "")
        now_date = item.get("question_date", "")

        # 1. Retrieve facts for this question using retrieve_facts
        intent = "unknown"
        top_facts = []
        formatted_facts = "None retrieved."
        try:
            intent, top_facts, formatted_facts = retrieve_facts(query=question, user_id=qid, now=now_date)
        except Exception as e:
            formatted_facts = f"Error retrieving facts: {e}"

        # 2. Check all stored facts in SQLite
        all_stored = get_stored_user_facts(qid)

        # 3. Label failure: extraction, retrieval, or answering
        gold_keywords = [w.lower() for w in re.findall(r"\w+", gold) if len(w) > 2 and w.lower() not in {"the", "and", "was", "for", "with", "that"}]

        # Check if gold keywords exist in all stored facts
        stored_matches = []
        for f in all_stored:
            text = f"{f['subject']} {f['attribute']} {f['value']} {f['source_text']}".lower()
            if any(k in text for k in gold_keywords):
                stored_matches.append(f)

        # Check if gold keywords exist in top retrieved facts
        retrieved_matches = []
        for f in top_facts:
            text = f"{f.get('subject', '')} {f.get('attribute', '')} {f.get('value', '')} {f.get('source_text', '')}".lower()
            if any(k in text for k in gold_keywords):
                retrieved_matches.append(f)

        if not stored_matches:
            failure_type = "Extraction Failure"
            diagnosis = "The essential fact containing the gold answer was never extracted into the facts store during dialogue ingestion."
        elif not retrieved_matches:
            failure_type = "Retrieval Failure"
            diagnosis = f"The relevant fact was extracted into the store ({len(stored_matches)} matches found in SQLite), but was ranked out of the top-15 retrieved context by BM25 + dense RRF."
        else:
            failure_type = "Answering Failure"
            diagnosis = "The relevant fact was successfully retrieved into the context prompt, but the LLM failed to synthesize or output the exact gold answer."

        # Format retrieved facts snippet for markdown
        fact_lines = []
        if top_facts:
            for f in top_facts[:5]:
                valid_str = f"[{f.get('valid_from', '?')} -> {f.get('valid_to', 'now')}]"
                fact_lines.append(f"- `{valid_str} {f.get('subject')}.{f.get('attribute')}: {f.get('value')}`")
        else:
            fact_lines.append("- _No facts retrieved._")

        failure_reports.append({
            "qid": qid,
            "type": qtype,
            "question": question,
            "gold": gold,
            "prediction": pred,
            "failure_type": failure_type,
            "diagnosis": diagnosis,
            "retrieved_facts": "\n".join(fact_lines),
            "intent": intent
        })

    # If fewer than top_n failures exist, synthesize placeholder analysis or note available count
    return failure_reports


def generate_report(output_path: str = REPORT_PATH) -> str:
    print(f"\n[report] Generating evaluation report at {output_path}...")
    system_analyses = [analyze_system(spec) for spec in SYSTEM_SPECS]

    # Find v2 judged records
    v2_analysis = next((s for s in system_analyses if s["display"] == "v2"), None)
    v2_records = v2_analysis["judged_records"] if v2_analysis else []
    v2_failures = analyze_v2_failures(v2_records, top_n=5)

    md = []
    md.append("# LongMemEval Benchmark Evaluation Report\n")
    md.append("This report summarizes the comparative evaluation of Memory OS systems (**v1**, **v2**, **v2-no-decay**, **v2-memoria-decay**, and **memoria**) on the 30-question sample (`bench/sample_ids.json`) drawn from LongMemEval.\n")

    # 1. Main Results Table
    md.append("## 1. System Performance Overview\n")
    md.append("| System | single-session-user Acc (95% CI) | knowledge-update Acc (95% CI) | Mean Ingest Calls | Mean Answer Calls | Mean Seconds |")
    md.append("| :--- | :--- | :--- | :---: | :---: | :---: |")

    for s in system_analyses:
        md.append(
            f"| **{s['display']}** | {s['single_session_acc']} | {s['knowledge_update_acc']} | {s['mean_ingest_calls']} | {s['mean_answer_calls']} | {s['mean_seconds']}s |"
        )
    md.append("\n")

    # 2. Reference Baseline
    md.append("## 2. Published Baseline Reference\n")
    md.append("> **Memoria Published Numbers (Sarin et al., AIMLSystems 2025)**:  \n")
    md.append("> - **Single-Session-User Accuracy**: **87.1%** (n=70)  \n")
    md.append("> - **Knowledge-Update Accuracy**: **80.8%** (n=78)  \n")
    md.append("> _Note: Evaluated on GPT-4.1-mini. The underlying foundation model (GPT-4.1-mini vs. Gemini 2.5 Flash / Flash-Lite), prompt scaffolding, and sample size (full test split vs. 30-question pilot sample) differ._\n\n")

    # 3. Limitations
    md.append("## 3. Limitations\n")
    md.append("- **Sample Size**: Evaluated on a 30-question pilot sample (15 `single-session-user` and 15 `knowledge-update` instances) from LongMemEval (`bench/sample_ids.json`).")
    md.append("- **Single Run**: Results reflect a single execution pass per system configuration without variance estimation across multiple random seeds.")
    md.append("- **Automated Judge**: Judged using an automated LLM judge (Gemini 2.5 Flash at temperature 0) with zero-shot yes/no prompting and no human adjudication or manual spot-checking.")
    md.append("- **Memoria Reimplementation**: Memoria was constructed as an independent clean-room implementation adhering to the published paper specifications (Sarin et al., AIMLSystems 2025) because the official author implementation is unreleased.\n\n")

    # 4. Failure Analysis
    md.append("## 4. Failure Analysis: Five Incorrect v2 Predictions\n")
    md.append("Below are five incorrect v2 answers, their retrieved facts, and their diagnostic failure mode classification (extraction, retrieval, or answering failure):\n")

    if not v2_failures:
        md.append("_No failed v2 predictions recorded yet or evaluation is still in progress._\n")
    else:
        for idx, f in enumerate(v2_failures, 1):
            md.append(f"### Case {idx}: Question `{f['qid']}` ({f['type']})\n")
            md.append(f"- **Question**: \"{f['question']}\"")
            md.append(f"- **Gold Answer**: `{f['gold']}`")
            md.append(f"- **v2 Prediction**: \"{f['prediction']}\"")
            md.append(f"- **Classified Intent**: `{f['intent']}`")
            md.append(f"- **Failure Mode**: **{f['failure_type']}**")
            md.append(f"- **Diagnosis**: {f['diagnosis']}")
            md.append("- **Retrieved Facts**:")
            md.append(f"{f['retrieved_facts']}\n")

    content = "\n".join(md)
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"[report] Successfully wrote {len(content)} characters to {output_path}")
    return content


if __name__ == "__main__":
    generate_report()
