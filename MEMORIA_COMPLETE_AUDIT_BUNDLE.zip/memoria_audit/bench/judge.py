import os
import sys
import json
import random
from typing import Dict, Any, List, Optional, Tuple

# Ensure root directory is on PYTHONPATH
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from app.llm.gemini import ask_gemini

JUDGE_MODEL = "gemini-3-flash-preview"
JUDGE_TEMPERATURE = 0.0


def judge_prediction(
    question: str,
    gold_answer: str,
    prediction: str,
    model_name: str = JUDGE_MODEL
) -> bool:
    """
    Evaluates whether the model prediction correctly answers the question
    given the gold reference answer, following the LongMemEval paper's LLM judge approach.
    Uses a fixed model, temperature 0.0, and SQLite caching.
    """
    prompt = f"""You are an evaluation assistant. Given a question, a reference gold answer, and a model prediction, determine whether the model prediction correctly answers the question according to the reference gold answer.

Question: {question}
Reference Answer: {gold_answer}
Model Prediction: {prediction}

Respond with EXACTLY "yes" if the prediction correctly answers the question, or "no" if it does not. Do not include any other text."""

    response = ask_gemini(prompt, model_name=model_name, temperature=JUDGE_TEMPERATURE)
    clean_resp = response.strip().lower()

    # Determine yes / no
    first_word = clean_resp.split()[0].strip(".,!?:;\"'") if clean_resp.split() else ""
    return first_word == "yes" or clean_resp.startswith("yes")


def compute_bootstrap_ci(
    binary_scores: List[int],
    n_resamples: int = 1000,
    confidence_level: float = 0.95,
    seed: int = 42
) -> Tuple[float, float]:
    """
    Computes a percentile bootstrap confidence interval for the mean accuracy.
    """
    n = len(binary_scores)
    if n == 0:
        return 0.0, 0.0

    rng = random.Random(seed)
    boot_means = []
    for _ in range(n_resamples):
        sample = [rng.choice(binary_scores) for _ in range(n)]
        boot_means.append(sum(sample) / n)

    boot_means.sort()
    alpha = (1.0 - confidence_level) / 2.0
    lower_idx = int(alpha * n_resamples)
    upper_idx = int((1.0 - alpha) * n_resamples)
    upper_idx = min(upper_idx, n_resamples - 1)

    return round(boot_means[lower_idx], 4), round(boot_means[upper_idx], 4)


def score(results_file: str) -> Dict[str, Any]:
    """
    Scores predictions in results_file using the LongMemEval LLM judge.
    Prints:
      - accuracy per question_type
      - count correct out of total
      - 95% bootstrap confidence interval (1000 resamples)
    """
    if not os.path.exists(results_file):
        raise FileNotFoundError(f"Results file not found: {results_file}")

    records: List[Dict[str, Any]] = []
    with open(results_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))

    if not records:
        print("[Judge] No records found to score.")
        return {"total": 0, "correct": 0, "accuracy": 0.0}

    print(f"\n[Judge] Evaluating {len(records)} predictions using LongMemEval judge...")
    type_stats: Dict[str, Dict[str, int]] = {}
    binary_scores: List[int] = []
    judged_records: List[Dict[str, Any]] = []

    for idx, rec in enumerate(records, 1):
        q = rec.get("question", "")
        gold = rec.get("gold answer") or rec.get("gold_answer", "")
        pred = rec.get("prediction", "")
        qtype = rec.get("type") or rec.get("question_type", "unknown")

        is_correct = judge_prediction(question=q, gold_answer=gold, prediction=pred)
        score_val = 1 if is_correct else 0
        binary_scores.append(score_val)

        if qtype not in type_stats:
            type_stats[qtype] = {"correct": 0, "total": 0, "scores": []}
        type_stats[qtype]["total"] += 1
        type_stats[qtype]["scores"].append(score_val)
        if is_correct:
            type_stats[qtype]["correct"] += 1

        rec_copy = dict(rec)
        rec_copy["is_correct"] = is_correct
        judged_records.append(rec_copy)

        status_tag = "CORRECT" if is_correct else "INCORRECT"
        print(f"  [{idx:2d}/{len(records)}] {rec.get('question_id', '')} ({qtype}): {status_tag}")

    total = len(binary_scores)
    total_correct = sum(binary_scores)
    overall_acc = total_correct / total if total > 0 else 0.0
    ci_lower, ci_upper = compute_bootstrap_ci(binary_scores, n_resamples=1000)

    # Print summary report
    print("\n============================================================")
    print("                LONGMEMEVAL JUDGE EVALUATION                ")
    print("============================================================")
    print(f"{'Question Type':<28} | {'Correct / Total':<16} | {'Accuracy':<10} | {'95% CI':<15}")
    print("-" * 75)
    for qtype, stats in type_stats.items():
        c = stats["correct"]
        t = stats["total"]
        acc = (c / t * 100.0) if t > 0 else 0.0
        t_ci = compute_bootstrap_ci(stats["scores"], n_resamples=1000)
        stats["ci_95"] = t_ci
        ci_str = f"[{t_ci[0]*100:.1f}%, {t_ci[1]*100:.1f}%]"
        print(f"{qtype:<28} | {f'{c}/{t}':<16} | {acc:6.2f}%   | {ci_str:<15}")
    print("-" * 75)
    print(f"{'Overall Count Correct':<28} | {f'{total_correct}/{total}':<16} | {overall_acc * 100:6.2f}%   | [{ci_lower*100:.1f}%, {ci_upper*100:.1f}%]")
    print("============================================================\n")

    summary = {
        "total": total,
        "correct": total_correct,
        "accuracy": round(overall_acc, 4),
        "ci_95": (ci_lower, ci_upper),
        "per_type": {
            qtype: {
                "correct": s["correct"],
                "total": s["total"],
                "accuracy": round(s["correct"] / s["total"], 4) if s["total"] > 0 else 0.0,
                "ci_95": s.get("ci_95", (0.0, 0.0))
            }
            for qtype, s in type_stats.items()
        },
        "records": judged_records
    }
    return summary


if __name__ == "__main__":
    results_dir = os.path.join(ROOT_DIR, "bench", "results")
    if len(sys.argv) > 1 and sys.argv[1] not in ("--all", "-a"):
        score(sys.argv[1])
    else:
        # Score every results file in bench/results/
        if os.path.exists(results_dir):
            files = [f for f in os.listdir(results_dir) if f.endswith(".jsonl")]
            if not files:
                print(f"[Judge] No .jsonl files found in {results_dir}")
            else:
                files.sort()
                all_summaries = {}
                for fname in files:
                    fpath = os.path.join(results_dir, fname)
                    print(f"\n{'='*70}\n[Judge] Scoring {fname}...\n{'='*70}")
                    res = score(fpath)
                    all_summaries[fname] = res

                # Print comparative overview
                print("\n" + "=" * 70)
                print("               ALL SYSTEMS EVALUATION OVERVIEW                ")
                print("=" * 70)
                print(f"{'Results File':<28} | {'Correct / Total':<16} | {'Accuracy':<10} | {'95% CI':<15}")
                print("-" * 75)
                for fname, s in all_summaries.items():
                    tot = s["total"]
                    cor = s["correct"]
                    acc = s["accuracy"] * 100.0
                    ci = s.get("ci_95", (0.0, 0.0))
                    ci_str = f"[{ci[0]*100:.1f}%, {ci[1]*100:.1f}%]"
                    print(f"{fname:<28} | {f'{cor}/{tot}':<16} | {acc:6.2f}%   | {ci_str:<15}")
                print("=" * 75 + "\n")
        else:
            print(f"[Judge] Results directory not found: {results_dir}")
