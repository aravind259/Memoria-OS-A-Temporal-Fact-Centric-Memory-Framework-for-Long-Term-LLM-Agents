import os
import sys
import argparse
import importlib
import time
from typing import Optional

# Ensure root directory is on PYTHONPATH
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from bench.longmemeval import sample, run_system, RESULTS_DIR
from bench.judge import score


def load_system(system_name: str):
    """
    Dynamically loads the system adapter from bench/systems/<system_name>.py
    """
    module_name = f"bench.systems.{system_name}"
    try:
        mod = importlib.import_module(module_name)
    except ModuleNotFoundError as e:
        raise ValueError(f"System '{system_name}' not found at {module_name}: {e}")

    if hasattr(mod, "get_system"):
        return mod.get_system()
    elif hasattr(mod, f"{system_name.capitalize()}System"):
        cls = getattr(mod, f"{system_name.capitalize()}System")
        return cls()
    elif hasattr(mod, "V1System"):
        return mod.V1System()
    elif hasattr(mod, "System"):
        return mod.System()
    else:
        raise AttributeError(f"No system class found in {module_name}")


def main():
    parser = argparse.ArgumentParser(description="Run LongMemEval benchmark on memory systems")
    parser.add_argument("--system", type=str, default="v1", help="Name of system adapter in bench/systems/")
    parser.add_argument("--limit", type=int, default=None, help="Limit number of evaluation questions")
    parser.add_argument("--n-per-type", type=int, default=15, help="Number of items to sample per type")
    parser.add_argument("--seed", type=int, default=0, help="Random seed for sampling")
    parser.add_argument("--decay-mode", type=str, default=None, help="Ablation decay mode: none, memoria, or default")
    parser.add_argument("--output-name", type=str, default=None, help="Custom output name in bench/results/<name>.jsonl")
    parser.add_argument("--no-judge", action="store_true", help="Skip running the LLM judge after benchmark")
    args = parser.parse_args()

    effective_decay = args.decay_mode or os.environ.get("DECAY_MODE")
    if effective_decay:
        os.environ["DECAY_MODE"] = effective_decay

    output_name = args.output_name
    if not output_name:
        if effective_decay and effective_decay.lower() != "default":
            output_name = f"{args.system}_decay_{effective_decay.lower()}"
        else:
            output_name = args.system

    print(f"\n============================================================", flush=True)
    print(f"       BENCHMARK RUNNER: System='{args.system}', Output='{output_name}', Limit={args.limit} ", flush=True)
    if effective_decay:
        print(f"       Decay Mode Ablation: '{effective_decay}'", flush=True)
    print(f"============================================================\n", flush=True)

    # 1. Load system adapter
    system = load_system(args.system)
    print(f"[Run] Loaded system: {system.__class__.__name__} (name='{getattr(system, 'name', args.system)}')", flush=True)

    # 2. Sample items
    items = sample(n_per_type=args.n_per_type, seed=args.seed)
    if args.limit:
        items = items[:args.limit]
        print(f"[Run] Limited evaluation to {len(items)} items", flush=True)

    # 3. Run benchmark
    total_run_start = time.time()
    results = run_system(system, items, system_name=output_name)
    total_run_elapsed = round(time.time() - total_run_start, 2)

    # 4. Compute and report per-question statistics
    total_calls = sum(r.get("LLM calls", 0) for r in results)
    total_seconds = sum(r.get("seconds", 0.0) for r in results)
    num_questions = len(results)

    avg_calls_per_q = total_calls / num_questions if num_questions > 0 else 0
    avg_sec_per_q = total_seconds / num_questions if num_questions > 0 else 0

    proj_30_calls = avg_calls_per_q * 30
    proj_30_sec = avg_sec_per_q * 30
    proj_30_hours = proj_30_sec / 3600.0

    print("\n------------------------------------------------------------")
    print("                 BENCHMARK PERFORMANCE SUMMARY              ")
    print("------------------------------------------------------------")
    print(f"Questions evaluated        : {num_questions}")
    print(f"Total LLM calls made       : {total_calls} (avg {avg_calls_per_q:.1f} per question)")
    print(f"Total time recorded        : {total_seconds:.2f}s (wall clock: {total_run_elapsed:.2f}s)")
    print(f"Average time per question  : {avg_sec_per_q:.2f}s")
    print("-" * 60)
    print(f"Projected for 30 questions : {proj_30_calls:.0f} LLM calls | {proj_30_sec:.1f}s ({proj_30_hours:.2f} hours)")
    if proj_30_hours > 2.0:
        print(f"WARNING: Projected full run exceeds 2 hours ({proj_30_hours:.2f}h > 2.0h)!")
    print("------------------------------------------------------------\n")

    # 5. Judge predictions
    if not args.no_judge:
        results_file = os.path.join(RESULTS_DIR, f"{output_name}.jsonl")
        print(f"[Run] Scoring results from {results_file}...")
        score(results_file)


if __name__ == "__main__":
    main()
