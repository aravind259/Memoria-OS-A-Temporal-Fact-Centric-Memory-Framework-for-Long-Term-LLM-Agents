import os
import sys
import unittest
from datetime import datetime

# Ensure root directory is on PYTHONPATH
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from app.core import clock
from app.memory_v2.facts import (
    init_db,
    get_connection,
    get_existing_attributes,
    get_active_facts,
    get_all_facts
)
from app.memory_v2.extract import extract_facts
from app.memory_v2.write import write_fact

TEST_DB_PATH = os.path.join(ROOT_DIR, "test_facts_v2.db")


def reset_test_db():
    if os.path.exists(TEST_DB_PATH):
        try:
            os.remove(TEST_DB_PATH)
        except Exception:
            pass
    init_db(TEST_DB_PATH)


def ingest_turn(user_id: str, user_msg: str, assistant_msg: str, now: str):
    """Helper to simulate one conversation turn ingestion."""
    clock.set_now(now)
    existing_attrs = get_existing_attributes(user_id, db_path=TEST_DB_PATH)
    extracted = extract_facts(
        user_msg=user_msg,
        assistant_msg=assistant_msg,
        now=now,
        existing_attributes=existing_attrs
    )
    results = []
    for f in extracted:
        res = write_fact(user_id=user_id, fact=f, source_text=user_msg, db_path=TEST_DB_PATH)
        results.append(res)
    return extracted, results


class TestV2Facts(unittest.TestCase):

    def setUp(self):
        reset_test_db()

    def tearDown(self):
        reset_test_db()

    def test_case_a_sister_location_does_not_overwrite_user(self):
        """
        Case a: "I live in Bengaluru" then "My sister lives in Mumbai"
        Assertion: the user's home_city is still Bengaluru.
        """
        user_id = "test_user_a"
        now = "2026-10-30T12:00:00"

        # Turn 1: "I live in Bengaluru"
        ingest_turn(user_id, "I live in Bengaluru", "", now)

        active_1 = get_active_facts(user_id, db_path=TEST_DB_PATH)
        self.assertEqual(len(active_1), 1)
        self.assertEqual(active_1[0]["subject"], "user")
        self.assertEqual(active_1[0]["attribute"], "home_city")
        self.assertEqual(active_1[0]["value"], "Bengaluru")
        self.assertEqual(active_1[0]["status"], "active")

        # Turn 2: "My sister lives in Mumbai"
        ingest_turn(user_id, "My sister lives in Mumbai", "", now)

        active_2 = get_active_facts(user_id, db_path=TEST_DB_PATH)
        all_facts = get_all_facts(user_id, db_path=TEST_DB_PATH)

        # 1. User's home_city is STILL Bengaluru and active
        user_facts = [f for f in active_2 if f["subject"] == "user" and f["attribute"] == "home_city"]
        self.assertEqual(len(user_facts), 1, "User must still have exactly one active home_city fact")
        self.assertEqual(user_facts[0]["value"], "Bengaluru", f"Expected Bengaluru, got {user_facts[0]['value']}")
        self.assertEqual(user_facts[0]["status"], "active")

        # 2. Sister's location is recorded for sister, not user
        sister_facts = [f for f in active_2 if "sister" in f["subject"]]
        self.assertEqual(len(sister_facts), 1)
        self.assertEqual(sister_facts[0]["value"], "Mumbai")
        self.assertEqual(sister_facts[0]["status"], "active")

        # No facts were superseded
        self.assertTrue(all(f["status"] == "active" for f in all_facts))
        print("\n[Test A Passed] User home_city remains Bengaluru; sister recorded in Mumbai.")

    def test_case_b_visit_event_does_not_overwrite_home_city(self):
        """
        Case b: "I live in Bengaluru" then "I visited Chennai last week for a wedding"
        Assertion: home_city is still Bengaluru, and there is one event.
        """
        user_id = "test_user_b"
        now = "2026-10-30T12:00:00"

        # Turn 1: "I live in Bengaluru"
        ingest_turn(user_id, "I live in Bengaluru", "", now)

        # Turn 2: "I visited Chennai last week for a wedding"
        ingest_turn(user_id, "I visited Chennai last week for a wedding", "", now)

        active_facts = get_active_facts(user_id, db_path=TEST_DB_PATH)
        all_facts = get_all_facts(user_id, db_path=TEST_DB_PATH)

        # 1. User home_city is still Bengaluru and active
        home_facts = [f for f in active_facts if f["subject"] == "user" and f["attribute"] == "home_city"]
        self.assertEqual(len(home_facts), 1)
        self.assertEqual(home_facts[0]["value"], "Bengaluru")
        self.assertEqual(home_facts[0]["status"], "active")

        # 2. There is one event fact
        event_facts = [f for f in active_facts if f["kind"] == "event"]
        self.assertEqual(len(event_facts), 1, f"Expected 1 event fact, found {len(event_facts)}")
        self.assertIn("Chennai", event_facts[0]["value"])

        # Nothing should be superseded
        self.assertTrue(all(f["status"] == "active" for f in all_facts))
        print("\n[Test B Passed] Home city remains Bengaluru; 1 event recorded.")

    def test_case_c_relocation_supersedes_home_city(self):
        """
        Case c: "I live in Bengaluru" then "I moved to Pune last month, any good cafes?"
        Assertion: Bengaluru is superseded, Pune is active, and valid_from is about one month before now.
        """
        user_id = "test_user_c"
        now_dt = datetime(2026, 10, 30, 12, 0, 0)
        now_str = now_dt.isoformat()

        # Turn 1: "I live in Bengaluru"
        ingest_turn(user_id, "I live in Bengaluru", "", now_str)

        # Turn 2: "I moved to Pune last month, any good cafes?"
        ingest_turn(user_id, "I moved to Pune last month, any good cafes?", "", now_str)

        all_facts = get_all_facts(user_id, db_path=TEST_DB_PATH)
        active_facts = get_active_facts(user_id, db_path=TEST_DB_PATH)

        # 1. Exactly one active home_city fact with value Pune
        active_home = [f for f in active_facts if f["subject"] == "user" and f["attribute"] == "home_city"]
        self.assertEqual(len(active_home), 1)
        self.assertEqual(active_home[0]["value"], "Pune")
        self.assertEqual(active_home[0]["status"], "active")

        # 2. Bengaluru fact is superseded
        bengaluru_facts = [f for f in all_facts if f["value"] == "Bengaluru"]
        self.assertEqual(len(bengaluru_facts), 1)
        self.assertEqual(bengaluru_facts[0]["status"], "superseded")
        self.assertIsNotNone(bengaluru_facts[0]["valid_to"])

        # 3. Bengaluru valid_to matches Pune valid_from
        self.assertEqual(bengaluru_facts[0]["valid_to"], active_home[0]["valid_from"])

        # 4. valid_from is about one month before now (approx 25 to 35 days prior)
        pune_valid_from = active_home[0]["valid_from"]
        try:
            vf_dt = datetime.fromisoformat(pune_valid_from.replace("Z", ""))
        except Exception:
            vf_dt = datetime.strptime(pune_valid_from[:10], "%Y-%m-%d")

        diff_days = (now_dt - vf_dt).days
        self.assertTrue(
            25 <= diff_days <= 35,
            f"Expected ~30 days prior, got diff of {diff_days} days (valid_from={pune_valid_from})"
        )

        print(f"\n[Test C Passed] Bengaluru superseded; Pune active; valid_from is {diff_days} days before now.")


if __name__ == "__main__":
    unittest.main()
