"""
Regression Test Evaluator for Location Updates, Category-Aware Intent Relevance Filtering & Identity Scoping.
Tests the exact 8-step user conversation sequence and explicit retrieval category mapping.
"""

from typing import Dict, Any
from app.core.container import memory_manager, working_memory
from app.memory.chroma import clear_all_memories, get_all_memories
from app.memory.archive_storage import ColdArchiveStorage
from app.memory.retriever import MemoryRetriever

EVAL_USER_ID = "eval_user_bengaluru_8turn_test"


def evaluate_bengaluru_regression() -> Dict[str, Any]:
    test_logs = []

    # Clean isolated memory database before test run
    clear_all_memories()
    ColdArchiveStorage().clear_all()
    working_memory.clear()

    passed_count = 0
    total_tests = 9

    # -------------------------------------------------------------------------
    # Turn 1: User says "my name is Aravind"
    # -------------------------------------------------------------------------
    t1_res = memory_manager.chat(message="my name is Aravind", user_id=EVAL_USER_ID)
    t1_stored = t1_res.get("stored", False)
    t1_ok = t1_stored
    if t1_ok:
        passed_count += 1
    test_logs.append({
        "name": "E2E Step 1: 'my name is Aravind' Ingestion",
        "status": "PASS" if t1_ok else "FAIL",
        "details": f"Stored={t1_stored}, Category={t1_res.get('category')}"
    })

    # -------------------------------------------------------------------------
    # Turn 2: User says "I live in Hyderabad"
    # -------------------------------------------------------------------------
    t2_res = memory_manager.chat(message="I live in Hyderabad", user_id=EVAL_USER_ID)
    t2_stored = t2_res.get("stored", False)
    t2_ok = t2_stored
    if t2_ok:
        passed_count += 1
    test_logs.append({
        "name": "E2E Step 2: 'I live in Hyderabad' Ingestion",
        "status": "PASS" if t2_ok else "FAIL",
        "details": f"Stored={t2_stored}, Category={t2_res.get('category')}"
    })

    # -------------------------------------------------------------------------
    # Turn 3: User says "I moved to Bengaluru last week"
    # -------------------------------------------------------------------------
    t3_res = memory_manager.chat(message="I moved to Bengaluru last week", user_id=EVAL_USER_ID)
    t3_stored = t3_res.get("stored", False)

    all_db = get_all_memories(include_superseded=True, user_id=EVAL_USER_ID)
    active_db = get_all_memories(include_superseded=False, user_id=EVAL_USER_ID)

    bengaluru_active = any("bengaluru" in m.get("document", "").lower() and m.get("metadata", {}).get("status") == "active" for m in active_db)
    hyderabad_superseded = any("hyderabad" in m.get("document", "").lower() and m.get("metadata", {}).get("status") == "superseded" for m in all_db)

    t3_ok = (t3_stored and bengaluru_active and hyderabad_superseded)
    if t3_ok:
        passed_count += 1
    test_logs.append({
        "name": "E2E Step 3: 'I moved to Bengaluru last week' Lineage Reconciliation",
        "status": "PASS" if t3_ok else "FAIL",
        "details": f"Stored={t3_stored}, BengaluruActive={bengaluru_active}, HyderabadSuperseded={hyderabad_superseded}"
    })

    # -------------------------------------------------------------------------
    # Turn 4: User asks "Where do I live now?"
    # -------------------------------------------------------------------------
    t4_res = memory_manager.chat(message="Where do I live now?", user_id=EVAL_USER_ID)
    t4_resp = t4_res.get("response", "")
    t4_used = t4_res.get("memories_used", [])

    has_bengaluru_resp = ("bengaluru" in t4_resp.lower())
    no_lacks_access = ("don't have access" not in t4_resp.lower() and "lack access" not in t4_resp.lower())

    t4_ok = (len(t4_used) > 0 and has_bengaluru_resp and no_lacks_access)
    if t4_ok:
        passed_count += 1
    test_logs.append({
        "name": "E2E Step 4: 'Where do I live now?' Retrieval & LLM Answer",
        "status": "PASS" if t4_ok else "FAIL",
        "details": f"Memories retrieved: {len(t4_used)}, Response: '{t4_resp}'"
    })

    # -------------------------------------------------------------------------
    # Turn 5: User asks "What is my name?"
    # -------------------------------------------------------------------------
    t5_res = memory_manager.chat(message="What is my name?", user_id=EVAL_USER_ID)
    t5_resp = t5_res.get("response", "")
    t5_used = t5_res.get("memories_used", [])

    # Ensure location memory was NOT substituted for name query
    used_has_no_location = not any("bengaluru" in m.get("document", "").lower() for m in t5_used)
    has_aravind = ("aravind" in t5_resp.lower())

    t5_ok = (has_aravind and used_has_no_location)
    if t5_ok:
        passed_count += 1
    test_logs.append({
        "name": "E2E Step 5: 'What is my name?' Category-Aware Retrieval",
        "status": "PASS" if t5_ok else "FAIL",
        "details": f"Memories retrieved: {len(t5_used)}, Location Excluded={used_has_no_location}, Response: '{t5_resp}'"
    })

    # -------------------------------------------------------------------------
    # Turn 6: User asks "What programming languages do I use?"
    # -------------------------------------------------------------------------
    t6_res = memory_manager.chat(message="What programming languages do I use?", user_id=EVAL_USER_ID)
    t6_used = t6_res.get("memories_used", [])
    t6_resp = t6_res.get("response", "")

    # Neither name nor location memory should be substituted for a programming language query
    no_name_or_loc_substituted = not any("bengaluru" in m.get("document", "").lower() or "aravind" in m.get("document", "").lower() for m in t6_used)

    t6_ok = no_name_or_loc_substituted
    if t6_ok:
        passed_count += 1
    test_logs.append({
        "name": "E2E Step 6: Preference Query (No Name/Location Substitution)",
        "status": "PASS" if t6_ok else "FAIL",
        "details": f"Memories used: {len(t6_used)}, Name/Loc Excluded={no_name_or_loc_substituted}"
    })

    # -------------------------------------------------------------------------
    # Turn 7: User asks "What is the capital of India?" (General Knowledge)
    # -------------------------------------------------------------------------
    t7_res = memory_manager.chat(message="What is the capital of India?", user_id=EVAL_USER_ID)
    t7_used = t7_res.get("memories_used", [])
    t7_resp = t7_res.get("response", "")

    t7_ok = (len(t7_used) == 0 and ("new delhi" in t7_resp.lower() or "delhi" in t7_resp.lower()))
    if t7_ok:
        passed_count += 1
    test_logs.append({
        "name": "E2E Step 7: General Knowledge Query 'What is the capital of India?'",
        "status": "PASS" if t7_ok else "FAIL",
        "details": f"Memories used: {len(t7_used)} (exp: 0), Response: '{t7_resp[:50]}...'"
    })

    # -------------------------------------------------------------------------
    # Turn 8: User asks "What languages are spoken in Bengaluru?" (General Knowledge)
    # -------------------------------------------------------------------------
    t8_res = memory_manager.chat(message="What languages are spoken in Bengaluru?", user_id=EVAL_USER_ID)
    t8_used = t8_res.get("memories_used", [])
    t8_resp = t8_res.get("response", "")

    t8_ok = (len(t8_used) == 0 and ("kannada" in t8_resp.lower() or "english" in t8_resp.lower()) and "you live" not in t8_resp.lower())
    if t8_ok:
        passed_count += 1
    test_logs.append({
        "name": "E2E Step 8: General Knowledge Query 'What languages are spoken in Bengaluru?'",
        "status": "PASS" if t8_ok else "FAIL",
        "details": f"Memories used: {len(t8_used)} (exp: 0), Response: '{t8_resp[:60]}...'"
    })

    # -------------------------------------------------------------------------
    # Step 9: Explicit Category Retrieval Mapping Audit
    # -------------------------------------------------------------------------
    retriever = MemoryRetriever(working_memory=working_memory)

    queries_to_audit = [
        ("Where do I live now?", "PERSONAL_LOCATION", ["Fact"]),
        ("What is my name?", "PERSONAL_NAME", ["Fact"]),
        ("What is the capital of India?", "GENERAL_KNOWLEDGE", [])
    ]

    audit_passed = True
    print("\n--- EXPLICIT RETRIEVAL CATEGORY MAPPING LOG ---")
    for q, expected_intent, expected_cats in queries_to_audit:
        mems = retriever.retrieve(q, user_id=EVAL_USER_ID)
        used_cats = [m.get("metadata", {}).get("category") for m in mems]
        print(f"Query: '{q}' | Intent: {expected_intent} | Retrieved Count: {len(mems)} | Categories: {used_cats}")
        if expected_cats:
            if not any(c in used_cats for c in expected_cats):
                audit_passed = False

    if audit_passed:
        passed_count += 1

    test_logs.append({
        "name": "Step 9: Explicit Retrieval Category Mapping Audit",
        "status": "PASS" if audit_passed else "FAIL",
        "details": f"Category mapping audit passed: {audit_passed}"
    })

    bengaluru_accuracy = (passed_count / total_tests * 100.0)

    return {
        "bengaluru_regression_accuracy": bengaluru_accuracy,
        "test_logs": test_logs
    }


if __name__ == "__main__":
    import json
    res = evaluate_bengaluru_regression()
    print("\n" + "="*60)
    print("BENGALURU REGRESSION TEST SUITE RESULTS")
    print("="*60)
    for log in res["test_logs"]:
        print(f"[{log['status']}] {log['name']}: {log['details']}")
    print("-" * 60)
    print(f"BENGALURU ACCURACY: {res['bengaluru_regression_accuracy']:.1f}%")
    print("="*60)

