"""
Evaluator 6: Background Memory Lifecycle Scheduler Verification
Tests:
  1. Stale memory detection
  2. Active & high-importance memory preservation
  3. L2 -> L3 archival transaction
  4. Restoration & L1 promotion
  5. Important-memory protection
  6. Repeated scheduler execution
  7. Failure recovery (resilience against errors)
"""

from typing import Dict, Any
from datetime import datetime, timedelta
from app.memory.scheduler import MemoryLifecycleScheduler
from app.memory.archive_storage import ColdArchiveStorage
from app.memory.working_memory import WorkingMemory
from app.memory.chroma import clear_all_memories, save_memory, get_all_memories
from app.embeddings.encoder import get_embedding

EVAL_USER_ID = "eval_user_scheduler_test"


def evaluate_lifecycle_scheduler() -> Dict[str, Any]:
    test_logs = []

    # Clean test state
    clear_all_memories()
    archive = ColdArchiveStorage()
    archive.clear_all()
    wm = WorkingMemory()

    scheduler = MemoryLifecycleScheduler(
        enabled=True,
        interval_seconds=1.0,
        decay_threshold=0.15,
        important_threshold=0.65,
        archive_storage=archive,
        working_memory=wm
    )

    passed_count = 0
    total_tests = 7

    # -------------------------------------------------------------------------
    # Test 1: Stale Memory Detection
    # -------------------------------------------------------------------------
    past_iso = (datetime.utcnow() - timedelta(hours=200)).isoformat()
    stale_id = save_memory(
        memory="User temporarily mentioned a random weather note from 2020.",
        embedding=get_embedding("random weather note"),
        category="Conversation",
        importance=0.1,
        user_id=EVAL_USER_ID,
        created_at=past_iso
    )
    res1 = scheduler.run_lifecycle_cycle(user_id=EVAL_USER_ID)
    stale_ok = (res1.get("stale_detected_count", 0) >= 1 or res1.get("paged_out_count", 0) >= 1)
    if stale_ok:
        passed_count += 1

    test_logs.append({
        "name": "Scheduler: Stale Memory Detection",
        "status": "PASS" if stale_ok else "FAIL",
        "details": f"Stale detected count: {res1.get('stale_detected_count')}"
    })

    # -------------------------------------------------------------------------
    # Test 2: Active Memory Preservation
    # -------------------------------------------------------------------------
    active_id = save_memory(
        memory="User prefers dark mode themes for code editors.",
        embedding=get_embedding("dark mode themes"),
        category="Preference",
        importance=0.8,
        user_id=EVAL_USER_ID
    )
    res2 = scheduler.run_lifecycle_cycle(user_id=EVAL_USER_ID)
    active_mems = get_all_memories(include_superseded=False, user_id=EVAL_USER_ID)
    active_ok = any(m.get("id") == active_id for m in active_mems)
    if active_ok:
        passed_count += 1

    test_logs.append({
        "name": "Scheduler: Active Memory Preservation",
        "status": "PASS" if active_ok else "FAIL",
        "details": f"Active memory preserved in L2: {active_ok}"
    })

    # -------------------------------------------------------------------------
    # Test 3: L2 -> L3 Archival Transaction
    # -------------------------------------------------------------------------
    superseded_old_id = save_memory(
        memory="User lives in Seattle, Washington.",
        embedding=get_embedding("Seattle Washington"),
        category="Fact",
        importance=0.8,
        status="superseded",
        user_id=EVAL_USER_ID
    )
    res3 = scheduler.run_lifecycle_cycle(user_id=EVAL_USER_ID)
    archived_list = archive.get_archived_memories(user_id=EVAL_USER_ID)
    archival_ok = any(m.get("id") == superseded_old_id for m in archived_list)
    if archival_ok:
        passed_count += 1

    test_logs.append({
        "name": "Scheduler: L2 -> L3 Archival Transaction",
        "status": "PASS" if archival_ok else "FAIL",
        "details": f"Superseded memory archived to SQLite L3: {archival_ok}"
    })

    # -------------------------------------------------------------------------
    # Test 4: Cold Memory Restoration & L1 Promotion
    # -------------------------------------------------------------------------
    cold_id = "scheduler-cold-test-777"
    archive.archive_memory({
        "id": cold_id,
        "document": "User holds a key patent in AI memory retention engines.",
        "metadata": {
            "id": cold_id,
            "category": "Goal",
            "importance": 0.95,
            "user_id": EVAL_USER_ID,
            "status": "active"
        }
    })
    restored = scheduler.restore_cold_memory(cold_id, promote_l1=True)
    l1_hits = wm.search_l1("patent", user_id=EVAL_USER_ID)
    restoration_ok = (restored is not None and len(l1_hits) > 0)
    if restoration_ok:
        passed_count += 1

    test_logs.append({
        "name": "Scheduler: Cold Memory Restoration & L1 Promotion",
        "status": "PASS" if restoration_ok else "FAIL",
        "details": f"Restored from L3: {restored is not None}, L1 Hit: {len(l1_hits) > 0}"
    })

    # -------------------------------------------------------------------------
    # Test 5: Important-Memory Protection Rule
    # -------------------------------------------------------------------------
    imp_id = save_memory(
        memory="User's primary long-term goal is publishing a paper on AI memory retention.",
        embedding=get_embedding("publishing paper AI memory"),
        category="Goal",
        importance=0.95,
        user_id=EVAL_USER_ID
    )
    res5 = scheduler.run_lifecycle_cycle(user_id=EVAL_USER_ID)
    imp_preserved = (res5.get("preserved_important_count", 0) >= 1)
    if imp_preserved:
        passed_count += 1

    test_logs.append({
        "name": "Scheduler: Important-Memory Protection Rule",
        "status": "PASS" if imp_preserved else "FAIL",
        "details": f"Important memories preserved: {res5.get('preserved_important_count')}"
    })

    # -------------------------------------------------------------------------
    # Test 6: Repeated Scheduler Execution Stability
    # -------------------------------------------------------------------------
    for _ in range(3):
        scheduler.run_lifecycle_cycle(user_id=EVAL_USER_ID)
    repeated_ok = (scheduler.cycle_count >= 5)
    if repeated_ok:
        passed_count += 1

    test_logs.append({
        "name": "Scheduler: Repeated Execution Stability",
        "status": "PASS" if repeated_ok else "FAIL",
        "details": f"Executed {scheduler.cycle_count} cycles continuously without error"
    })

    # -------------------------------------------------------------------------
    # Test 7: Failure Recovery & Resilience
    # -------------------------------------------------------------------------
    # Simulate execution against non-existent/invalid user ID safely
    res7 = scheduler.run_lifecycle_cycle(user_id="non_existent_empty_user")
    recovery_ok = (res7.get("status") == "SUCCESS")
    if recovery_ok:
        passed_count += 1

    test_logs.append({
        "name": "Scheduler: Failure Recovery & Resilience",
        "status": "PASS" if recovery_ok else "FAIL",
        "details": f"Graceful handling status: {res7.get('status')}"
    })

    scheduler_acc = (passed_count / total_tests * 100.0)

    return {
        "scheduler_accuracy": scheduler_acc,
        "test_logs": test_logs
    }
