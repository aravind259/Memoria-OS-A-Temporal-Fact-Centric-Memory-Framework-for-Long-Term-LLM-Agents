"""
Evaluator 2: Comparative Retrieval Performance (Vector-Only vs BM25-Only vs Hybrid RAG)
Computes mathematically sound Hit Rate@1, Recall@5, Precision@5, MRR, and Relevance Accuracy.
"""

from typing import Dict, Any, List
from app.memory.retriever import MemoryRetriever
from app.memory.bm25 import BM25Retriever
from app.memory.ranker import MemoryRanker
from app.memory.chroma import save_memory, clear_all_memories, search_memory, get_all_memories
from app.embeddings.encoder import get_embedding
from app.memory.working_memory import WorkingMemory
from tests.dataset import (
    BENCHMARK_SEED_CORPUS,
    RETRIEVAL_BENCHMARK_DATASET_10,
    RELEVANCE_TEST_CASES
)

EVAL_USER_ID = "eval_user_retrieval_comp_test"


def _is_doc_relevant(retrieved_doc: str, relevant_docs: List[str]) -> bool:
    """Checks if a retrieved document matches any of the ground-truth relevant strings."""
    if not retrieved_doc or not relevant_docs:
        return False
    ret_lower = retrieved_doc.lower().strip()
    for rel in relevant_docs:
        rel_lower = rel.lower().strip()
        if rel_lower in ret_lower or ret_lower in rel_lower:
            return True
    return False


def evaluate_mode(mode: str) -> Dict[str, float]:
    """
    Evaluates a specific retrieval mode ('vector', 'bm25', or 'hybrid')
    over the 10-query benchmark dataset and calculates exact metrics.
    """
    # Clean and seed corpus
    clear_all_memories()
    wm = WorkingMemory()
    retriever = MemoryRetriever(working_memory=wm)
    bm25_retriever = BM25Retriever()

    for item in BENCHMARK_SEED_CORPUS:
        emb = get_embedding(item["doc"])
        save_memory(
            memory=item["doc"],
            embedding=emb,
            category=item["category"],
            importance=item["importance"],
            status=item["status"],
            user_id=EVAL_USER_ID,
            memory_id=item["id"]
        )

    hit_rates_1 = []
    recalls_5 = []
    precisions_5 = []
    mrr_scores = []
    relevance_outcomes = []

    for bench in RETRIEVAL_BENCHMARK_DATASET_10:
        query = bench["query"]
        relevant_docs = bench.get("relevant_docs", [])
        is_positive_query = len(relevant_docs) > 0

        # Execute retrieval according to mode
        retrieved_items = []

        if mode == "vector":
            emb = get_embedding(query)
            # Vector-only search from ChromaDB active memories
            raw_v = search_memory(embedding=emb, n_results=5, include_superseded=False, user_id=EVAL_USER_ID)
            retrieved_items = [m.get("document", "") for m in raw_v]

        elif mode == "bm25":
            # BM25-only lexical search across active memories
            active_mems = get_all_memories(include_superseded=False, user_id=EVAL_USER_ID)
            scored_mems = bm25_retriever.score_documents(query=query, documents=active_mems)
            # Filter non-zero scores & sort
            scored_mems = [m for m in scored_mems if m.get("bm25_score", 0.0) > 0.0]
            scored_mems.sort(key=lambda x: x.get("bm25_score", 0.0), reverse=True)
            retrieved_items = [m.get("document", "") for m in scored_mems[:5]]

        elif mode == "hybrid":
            # Full OS Hybrid RAG retrieval (Vector + BM25 + Decay + Relevance Threshold)
            raw_h = retriever.retrieve(message=query, user_id=EVAL_USER_ID)
            retrieved_items = [m.get("document", "") for m in raw_h[:5]]

        # Evaluate metrics
        if is_positive_query:
            # 1. Hit Rate @ 1
            if len(retrieved_items) > 0 and _is_doc_relevant(retrieved_items[0], relevant_docs):
                hit_rates_1.append(1.0)
            else:
                hit_rates_1.append(0.0)

            # 2. Recall @ 5: |Retrieved @ 5 intersect Relevant| / |Relevant|
            hits_count = sum(1 for doc in retrieved_items if _is_doc_relevant(doc, relevant_docs))
            rec_val = min(1.0, hits_count / len(relevant_docs))
            recalls_5.append(rec_val)

            # 3. Precision @ 5: |Retrieved @ 5 intersect Relevant| / |Retrieved @ 5|
            if len(retrieved_items) > 0:
                prec_val = hits_count / len(retrieved_items)
            else:
                prec_val = 0.0
            precisions_5.append(prec_val)

            # 4. MRR: Reciprocal rank of FIRST relevant item found
            first_rank_reciprocal = 0.0
            for idx, doc in enumerate(retrieved_items):
                if _is_doc_relevant(doc, relevant_docs):
                    first_rank_reciprocal = 1.0 / (idx + 1)
                    break
            mrr_scores.append(first_rank_reciprocal)

            # 5. Relevance Accuracy (positive query): PASS if at least 1 relevant item retrieved
            relevance_outcomes.append(1.0 if hits_count > 0 else 0.0)

        else:
            # Negative Control Query (irrelevant/GK): Relevance Accuracy PASS if 0 irrelevant docs returned
            relevance_outcomes.append(1.0 if len(retrieved_items) == 0 else 0.0)

    # Compute averages
    hr1_avg = (sum(hit_rates_1) / len(hit_rates_1) * 100.0) if hit_rates_1 else 0.0
    rec5_avg = (sum(recalls_5) / len(recalls_5) * 100.0) if recalls_5 else 0.0
    prec5_avg = (sum(precisions_5) / len(precisions_5) * 100.0) if precisions_5 else 0.0
    mrr_avg = (sum(mrr_scores) / len(mrr_scores)) if mrr_scores else 0.0
    rel_acc_avg = (sum(relevance_outcomes) / len(relevance_outcomes) * 100.0) if relevance_outcomes else 0.0

    return {
        "hit_rate_1": hr1_avg,
        "recall_5": rec5_avg,
        "precision_5": prec5_avg,
        "mrr": round(mrr_avg, 2),
        "relevance_accuracy": rel_acc_avg
    }


def evaluate_retrieval_performance() -> Dict[str, Any]:
    test_logs = []

    # Run comparative evaluation across Vector, BM25, and Hybrid modes
    vector_metrics = evaluate_mode("vector")
    bm25_metrics = evaluate_mode("bm25")
    hybrid_metrics = evaluate_mode("hybrid")

    # Add test log entries
    test_logs.append({
        "name": "Vector-Only Retrieval Benchmark",
        "status": "PASS",
        "details": f"HR@1={vector_metrics['hit_rate_1']:.0f}%, Rec@5={vector_metrics['recall_5']:.0f}%, Prec@5={vector_metrics['precision_5']:.0f}%, MRR={vector_metrics['mrr']:.2f}"
    })
    test_logs.append({
        "name": "BM25-Only Retrieval Benchmark",
        "status": "PASS",
        "details": f"HR@1={bm25_metrics['hit_rate_1']:.0f}%, Rec@5={bm25_metrics['recall_5']:.0f}%, Prec@5={bm25_metrics['precision_5']:.0f}%, MRR={bm25_metrics['mrr']:.2f}"
    })
    test_logs.append({
        "name": "Hybrid RAG Retrieval Benchmark",
        "status": "PASS",
        "details": f"HR@1={hybrid_metrics['hit_rate_1']:.0f}%, Rec@5={hybrid_metrics['recall_5']:.0f}%, Prec@5={hybrid_metrics['precision_5']:.0f}%, MRR={hybrid_metrics['mrr']:.2f}"
    })

    # Individual component tests
    bm25_algo = BM25Retriever()
    test_docs = [
        {"id": "1", "document": "User prefers dark mode UI.", "metadata": {}},
        {"id": "2", "document": "User works with Python and Rust.", "metadata": {}}
    ]
    bm25_scored = bm25_algo.score_documents("Python programming", test_docs)
    bm25_passed = (bm25_scored[1].get("bm25_score", 0.0) > bm25_scored[0].get("bm25_score", 0.0))
    test_logs.append({
        "name": "Sparse BM25 Lexical Retrieval Scoring",
        "status": "PASS" if bm25_passed else "FAIL",
        "details": f"BM25 match score: {bm25_scored[1].get('bm25_score', 0.0):.2f}"
    })


    return {
        "vector_metrics": vector_metrics,
        "bm25_metrics": bm25_metrics,
        "hybrid_metrics": hybrid_metrics,
        "recall_at_5": hybrid_metrics["recall_5"],
        "precision_at_5": hybrid_metrics["precision_5"],
        "relevance_accuracy": hybrid_metrics["relevance_accuracy"],
        "test_logs": test_logs
    }
