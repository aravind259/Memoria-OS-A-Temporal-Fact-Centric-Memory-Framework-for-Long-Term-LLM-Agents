"""
Unit & Regression Tests for Semantic Memory Classification & Health Category Handling.
Tests:
  1. "I have anxiety." -> Health (or Fact)
  2. "I have diabetes." -> Health
  3. "User has anxiety issues." -> Health
  4. "I want to overcome anxiety." -> Goal
  5. "I want to join Microsoft." -> Goal
  6. "I prefer meditation." -> Preference
  7. "I live in Hyderabad." -> Fact
  8. Safe migration / reclassification of existing memories without record deletion
"""

import sys
import os
from typing import Dict, Any

# Ensure workspace root is in sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from app.memory.classifier import MemoryClassifier
from app.core.container import memory_manager, working_memory
from app.memory.chroma import clear_all_memories, get_all_memories, save_memory
from app.memory.archive_storage import ColdArchiveStorage
from app.memory.reclassify import reclassify_existing_memories
from app.embeddings.encoder import get_embedding


def evaluate_memory_classification() -> Dict[str, Any]:
    classifier = MemoryClassifier()
    test_logs = []
    passed_count = 0
    total_tests = 8

    # -------------------------------------------------------------------------
    # Test 1: "I have anxiety." -> Health
    # -------------------------------------------------------------------------
    cat1 = classifier.classify("I have anxiety.")
    ok1 = (cat1 in ["Health", "Fact"])
    if ok1:
        passed_count += 1
    test_logs.append({
        "name": "Classification: 'I have anxiety.' -> Health",
        "status": "PASS" if ok1 else "FAIL",
        "details": f"Got category='{cat1}' (acceptable: 'Health' or 'Fact')"
    })

    # -------------------------------------------------------------------------
    # Test 2: "I have diabetes." -> Health
    # -------------------------------------------------------------------------
    cat2 = classifier.classify("I have diabetes.")
    ok2 = (cat2 in ["Health", "Fact"])
    if ok2:
        passed_count += 1
    test_logs.append({
        "name": "Classification: 'I have diabetes.' -> Health",
        "status": "PASS" if ok2 else "FAIL",
        "details": f"Got category='{cat2}'"
    })

    # -------------------------------------------------------------------------
    # Test 3: "User has anxiety issues." -> Health (The Reported Issue)
    # -------------------------------------------------------------------------
    cat3 = classifier.classify("User has anxiety issues.")
    ok3 = (cat3 in ["Health", "Fact"] and cat3 != "Goal")
    if ok3:
        passed_count += 1
    test_logs.append({
        "name": "Classification: 'User has anxiety issues.' -> Health (not Goal)",
        "status": "PASS" if ok3 else "FAIL",
        "details": f"Got category='{cat3}'"
    })

    # -------------------------------------------------------------------------
    # Test 4: "I want to overcome anxiety." -> Goal (Aspiration / Intention)
    # -------------------------------------------------------------------------
    cat4 = classifier.classify("I want to overcome anxiety.")
    ok4 = (cat4 == "Goal")
    if ok4:
        passed_count += 1
    test_logs.append({
        "name": "Classification: 'I want to overcome anxiety.' -> Goal",
        "status": "PASS" if ok4 else "FAIL",
        "details": f"Got category='{cat4}' (exp: 'Goal')"
    })

    # -------------------------------------------------------------------------
    # Test 5: "I want to join Microsoft." -> Goal
    # -------------------------------------------------------------------------
    cat5 = classifier.classify("I want to join Microsoft.")
    ok5 = (cat5 == "Goal")
    if ok5:
        passed_count += 1
    test_logs.append({
        "name": "Classification: 'I want to join Microsoft.' -> Goal",
        "status": "PASS" if ok5 else "FAIL",
        "details": f"Got category='{cat5}' (exp: 'Goal')"
    })

    # -------------------------------------------------------------------------
    # Test 6: "I prefer meditation." -> Preference
    # -------------------------------------------------------------------------
    cat6 = classifier.classify("I prefer meditation.")
    ok6 = (cat6 == "Preference")
    if ok6:
        passed_count += 1
    test_logs.append({
        "name": "Classification: 'I prefer meditation.' -> Preference",
        "status": "PASS" if ok6 else "FAIL",
        "details": f"Got category='{cat6}' (exp: 'Preference')"
    })

    # -------------------------------------------------------------------------
    # Test 7: "I live in Hyderabad." -> Fact
    # -------------------------------------------------------------------------
    cat7 = classifier.classify("I live in Hyderabad.")
    ok7 = (cat7 == "Fact")
    if ok7:
        passed_count += 1
    test_logs.append({
        "name": "Classification: 'I live in Hyderabad.' -> Fact",
        "status": "PASS" if ok7 else "FAIL",
        "details": f"Got category='{cat7}' (exp: 'Fact')"
    })

    # -------------------------------------------------------------------------
    # Test 8: Safe Reclassification Migration without Deleting Memories
    # -------------------------------------------------------------------------
    test_user = "eval_user_migration_test"
    # Seed a misclassified memory directly
    m_id = save_memory(
        memory="User has chronic anxiety and insomnia.",
        embedding=get_embedding("User has chronic anxiety and insomnia."),
        category="Goal",  # deliberately misclassified
        importance=0.9,
        user_id=test_user
    )

    migration_res = reclassify_existing_memories(dry_run=False)
    mems = get_all_memories(include_superseded=True, user_id=test_user)
    target = next((m for m in mems if m["id"] == m_id), None)

    reclassified_ok = (
        target is not None and
        target.get("metadata", {}).get("category") == "Health" and
        target.get("document") == "User has chronic anxiety and insomnia."
    )
    if reclassified_ok:
        passed_count += 1
    test_logs.append({
        "name": "Safe Migration: Reclassifies without deleting memory",
        "status": "PASS" if reclassified_ok else "FAIL",
        "details": f"Memory preserved: {target is not None}, Category updated to: {target.get('metadata', {}).get('category') if target else None}"
    })

    # Cleanup test user memory
    from app.memory.chroma import delete_memory
    delete_memory(m_id)

    accuracy = (passed_count / total_tests * 100.0)
    return {
        "classification_accuracy": accuracy,
        "test_logs": test_logs
    }


if __name__ == "__main__":
    res = evaluate_memory_classification()
    print("\n" + "=" * 60)
    print("MEMORY CLASSIFICATION TEST RESULTS")
    print("=" * 60)
    for log in res["test_logs"]:
        print(f"[{log['status']}] {log['name']}: {log['details']}")
    print("-" * 60)
    print(f"ACCURACY: {res['classification_accuracy']:.1f}%")
    print("=" * 60)
