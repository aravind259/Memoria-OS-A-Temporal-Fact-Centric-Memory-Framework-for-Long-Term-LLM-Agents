"""
Regression Test Evaluator for Short-Term Conversation Context & Follow-Up References.
Tests reference resolution ("for Telangana", "capital for ?", "what were we talking about?") vs long-term memory.
"""

from typing import Dict, Any
from app.core.container import memory_manager, working_memory
from app.memory.chroma import clear_all_memories
from app.memory.archive_storage import ColdArchiveStorage

EVAL_USER_ID = "eval_user_context_test"


def evaluate_conversation_context() -> Dict[str, Any]:
    test_logs = []

    # Clean memory & working buffer for test isolation
    clear_all_memories()
    ColdArchiveStorage().clear_all()
    working_memory.clear()

    passed_count = 0
    total_tests = 6

    # -------------------------------------------------------------------------
    # TEST 1: Conversational context reference resolution (Telangana -> capital for ?)
    # -------------------------------------------------------------------------
    t1_r1 = memory_manager.chat(message="Tell me about Telangana.", user_id=EVAL_USER_ID)
    t1_r2 = memory_manager.chat(message="capital for ?", user_id=EVAL_USER_ID)
    t1_resp = t1_r2.get("response", "").lower()

    t1_ok = ("hyderabad" in t1_resp)
    if t1_ok:
        passed_count += 1
    test_logs.append({
        "name": "TEST 1: Telangana Context Follow-up 'capital for ?'",
        "status": "PASS" if t1_ok else "FAIL",
        "details": f"Response: '{t1_r2.get('response')}'"
    })

    # Clear between tests
    working_memory.clear()

    # -------------------------------------------------------------------------
    # TEST 2: Conversational context reference resolution (Karnataka -> capital for ?)
    # -------------------------------------------------------------------------
    t2_r1 = memory_manager.chat(message="Tell me about Karnataka.", user_id=EVAL_USER_ID)
    t2_r2 = memory_manager.chat(message="capital for ?", user_id=EVAL_USER_ID)
    t2_resp = t2_r2.get("response", "").lower()

    t2_ok = ("bengaluru" in t2_resp or "bangalore" in t2_resp)
    if t2_ok:
        passed_count += 1
    test_logs.append({
        "name": "TEST 2: Karnataka Context Follow-up 'capital for ?'",
        "status": "PASS" if t2_ok else "FAIL",
        "details": f"Response: '{t2_r2.get('response')}'"
    })

    # Clear between tests
    working_memory.clear()

    # -------------------------------------------------------------------------
    # TEST 3: Long-term memory relocation persistence
    # -------------------------------------------------------------------------
    t3_r1 = memory_manager.chat(message="I moved to Bengaluru last week.", user_id=EVAL_USER_ID)
    t3_r2 = memory_manager.chat(message="Where do I live now?", user_id=EVAL_USER_ID)
    t3_resp = t3_r2.get("response", "").lower()

    t3_ok = ("bengaluru" in t3_resp or "bangalore" in t3_resp)
    if t3_ok:
        passed_count += 1
    test_logs.append({
        "name": "TEST 3: Long-Term Relocation Memory 'Where do I live now?'",
        "status": "PASS" if t3_ok else "FAIL",
        "details": f"Response: '{t3_r2.get('response')}'"
    })

    # Clear working memory buffer for general knowledge tests
    working_memory.clear()

    # -------------------------------------------------------------------------
    # TEST 4: General Knowledge (What is the capital of India?)
    # -------------------------------------------------------------------------
    t4_r = memory_manager.chat(message="What is the capital of India?", user_id=EVAL_USER_ID)
    t4_resp = t4_r.get("response", "").lower()
    t4_mems = t4_r.get("memories_used", [])

    t4_ok = (len(t4_mems) == 0 and ("new delhi" in t4_resp or "delhi" in t4_resp))
    if t4_ok:
        passed_count += 1
    test_logs.append({
        "name": "TEST 4: General Knowledge 'What is the capital of India?'",
        "status": "PASS" if t4_ok else "FAIL",
        "details": f"Memories used: {len(t4_mems)} (exp: 0), Response: '{t4_r.get('response')[:50]}...'"
    })

    # -------------------------------------------------------------------------
    # TEST 5: General Knowledge (What languages are spoken in Bengaluru?)
    # -------------------------------------------------------------------------
    t5_r = memory_manager.chat(message="What languages are spoken in Bengaluru?", user_id=EVAL_USER_ID)
    t5_resp = t5_r.get("response", "").lower()
    t5_mems = t5_r.get("memories_used", [])

    t5_ok = ("kannada" in t5_resp or "english" in t5_resp) and ("you live" not in t5_resp)
    if t5_ok:
        passed_count += 1
    test_logs.append({
        "name": "TEST 5: General Knowledge 'What languages are spoken in Bengaluru?'",
        "status": "PASS" if t5_ok else "FAIL",
        "details": f"Response: '{t5_r.get('response')[:60]}...'"
    })

    # -------------------------------------------------------------------------
    # TEST 6: Meta Conversation Query (What were we talking about?)
    # -------------------------------------------------------------------------
    working_memory.clear()
    t6_r1 = memory_manager.chat(message="Tell me about Telangana.", user_id=EVAL_USER_ID)
    t6_r2 = memory_manager.chat(message="What were we talking about?", user_id=EVAL_USER_ID)
    t6_resp = t6_r2.get("response", "").lower()

    t6_ok = ("telangana" in t6_resp or "talking about" in t6_resp or "discussing" in t6_resp)
    if t6_ok:
        passed_count += 1
    test_logs.append({
        "name": "TEST 6: Conversation Context Summary 'What were we talking about?'",
        "status": "PASS" if t6_ok else "FAIL",
        "details": f"Response: '{t6_r2.get('response')}'"
    })

    accuracy = (passed_count / total_tests * 100.0)

    return {
        "context_accuracy": accuracy,
        "test_logs": test_logs
    }


if __name__ == "__main__":
    res = evaluate_conversation_context()
    print("\n" + "="*60)
    print("CONVERSATION CONTEXT REGRESSION TEST RESULTS")
    print("="*60)
    for log in res["test_logs"]:
        print(f"[{log['status']}] {log['name']}: {log['details']}")
    print("-" * 60)
    print(f"CONTEXT ACCURACY: {res['context_accuracy']:.1f}%")
    print("="*60)
