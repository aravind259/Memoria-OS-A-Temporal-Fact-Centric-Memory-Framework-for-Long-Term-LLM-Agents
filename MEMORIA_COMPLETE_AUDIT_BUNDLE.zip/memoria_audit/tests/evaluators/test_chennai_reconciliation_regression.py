"""
Regression Test Evaluator for Location Reconciliation and Dynamic Quick-Action Suggestions.
Validates:
1. Hyderabad -> Chennai updates the active location and supersedes Hyderabad.
2. Historical record of Hyderabad is retained in storage.
3. 'Where do I live now?' returns Chennai and retrieves active memory.
4. 'Where did I live before?' returns Hyderabad via historical retrieval.
5. 'What is my name?' still returns Aravind, preserving unrelated facts.
6. Repeating Chennai does not create another active duplicate.
7. Dynamic quick-action suggestions reflect active persona (Chennai) and do not suggest outdated locations as current.
"""

import sys
import os
from typing import Dict, Any

# Ensure workspace root is in sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from app.core.container import memory_manager, working_memory, persona_engine
from app.memory.chroma import clear_all_memories, get_all_memories
from app.memory.archive_storage import ColdArchiveStorage

EVAL_USER_ID = "eval_user_chennai_regression"


def evaluate_chennai_reconciliation_regression() -> Dict[str, Any]:
    test_logs = []
    passed_count = 0
    total_tests = 7

    # Clean isolated memory database before test run
    clear_all_memories()
    ColdArchiveStorage().clear_all()
    working_memory.clear()

    # -------------------------------------------------------------------------
    # Setup Turn 1: User says "my name is Aravind"
    # -------------------------------------------------------------------------
    t1_res = memory_manager.chat(message="my name is Aravind", user_id=EVAL_USER_ID)
    t1_stored = t1_res.get("stored", False)

    # -------------------------------------------------------------------------
    # Setup Turn 2: User says "I live in Hyderabad"
    # -------------------------------------------------------------------------
    t2_res = memory_manager.chat(message="I live in Hyderabad", user_id=EVAL_USER_ID)
    t2_stored = t2_res.get("stored", False)

    # -------------------------------------------------------------------------
    # Test 1: Turn 3 - "I recently moved to Chennai" updates active location
    # and marks previous location (Hyderabad) as superseded.
    # -------------------------------------------------------------------------
    t3_res = memory_manager.chat(message="I recently moved to Chennai", user_id=EVAL_USER_ID)
    t3_stored = t3_res.get("stored", False)

    all_db = get_all_memories(include_superseded=True, user_id=EVAL_USER_ID)
    active_db = get_all_memories(include_superseded=False, user_id=EVAL_USER_ID)

    chennai_active = any("chennai" in m.get("document", "").lower() and m.get("metadata", {}).get("status") == "active" for m in active_db)
    hyderabad_superseded = any("hyderabad" in m.get("document", "").lower() and m.get("metadata", {}).get("status") == "superseded" for m in all_db)
    no_active_hyderabad = not any("hyderabad" in m.get("document", "").lower() for m in active_db)
    
    # Verify superseded_by linkage
    hyd_mems = [m for m in all_db if "hyderabad" in m.get("document", "").lower()]
    hyd_has_superseded_by = any(m.get("metadata", {}).get("superseded_by") for m in hyd_mems)

    t1_ok = (t3_stored and chennai_active and hyderabad_superseded and no_active_hyderabad and hyd_has_superseded_by)
    if t1_ok:
        passed_count += 1
    test_logs.append({
        "name": "Regression 1: Hyderabad -> Chennai Lineage & Superseded Status",
        "status": "PASS" if t1_ok else "FAIL",
        "details": f"ChennaiActive={chennai_active}, HyderabadSuperseded={hyderabad_superseded}, HydSupersededByLinked={hyd_has_superseded_by}"
    })

    # -------------------------------------------------------------------------
    # Test 2: "Where do I live now?" returns Chennai
    # -------------------------------------------------------------------------
    t4_res = memory_manager.chat(message="Where do I live now?", user_id=EVAL_USER_ID)
    t4_resp = t4_res.get("response", "")
    t4_used = t4_res.get("memories_used", [])

    has_chennai_now = "chennai" in t4_resp.lower()
    no_hyderabad_in_now_used = not any("hyderabad" in m.get("document", "").lower() for m in t4_used)

    t2_ok = (has_chennai_now and len(t4_used) > 0 and no_hyderabad_in_now_used)
    if t2_ok:
        passed_count += 1
    test_logs.append({
        "name": "Regression 2: 'Where do I live now?' Returns Active Chennai",
        "status": "PASS" if t2_ok else "FAIL",
        "details": f"Memories used: {len(t4_used)}, HasChennai={has_chennai_now}, HydExcluded={no_hyderabad_in_now_used}, Response: '{t4_resp}'"
    })

    # -------------------------------------------------------------------------
    # Test 3: "Where did I live before?" returns Hyderabad (Historical Retrieval)
    # -------------------------------------------------------------------------
    t5_res = memory_manager.chat(message="Where did I live before?", user_id=EVAL_USER_ID)
    t5_resp = t5_res.get("response", "")
    t5_used = t5_res.get("memories_used", [])

    has_hyderabad_past = "hyderabad" in t5_resp.lower()
    has_historical_used = any("hyderabad" in m.get("document", "").lower() for m in t5_used)

    t3_ok = (has_hyderabad_past and has_historical_used)
    if t3_ok:
        passed_count += 1
    test_logs.append({
        "name": "Regression 3: 'Where did I live before?' Retrieves Historical Hyderabad",
        "status": "PASS" if t3_ok else "FAIL",
        "details": f"Memories used: {len(t5_used)}, HasHyderabad={has_hyderabad_past}, Response: '{t5_resp}'"
    })

    # -------------------------------------------------------------------------
    # Test 4: "What is my name?" still returns Aravind (Unrelated Fact Preservation)
    # -------------------------------------------------------------------------
    t6_res = memory_manager.chat(message="What is my name?", user_id=EVAL_USER_ID)
    t6_resp = t6_res.get("response", "")
    t6_used = t6_res.get("memories_used", [])

    has_aravind = "aravind" in t6_resp.lower()
    used_has_name = any("aravind" in m.get("document", "").lower() for m in t6_used)

    t4_ok = (has_aravind and used_has_name)
    if t4_ok:
        passed_count += 1
    test_logs.append({
        "name": "Regression 4: 'What is my name?' Preserves Unrelated Name Fact",
        "status": "PASS" if t4_ok else "FAIL",
        "details": f"Memories used: {len(t6_used)}, HasAravind={has_aravind}, Response: '{t6_resp}'"
    })

    # -------------------------------------------------------------------------
    # Test 5: Repeating the Chennai fact does not create another active duplicate
    # -------------------------------------------------------------------------
    t7_res = memory_manager.chat(message="I recently moved to Chennai", user_id=EVAL_USER_ID)
    active_mems_post = get_all_memories(include_superseded=False, user_id=EVAL_USER_ID)
    active_chennai_count = sum(1 for m in active_mems_post if "chennai" in m.get("document", "").lower() and m.get("metadata", {}).get("status") == "active")

    t5_ok = (active_chennai_count == 1 and t7_res.get("storage_status") in ("REINFORCES", "REINFORCED", "DUPLICATE", "REDUNDANT"))
    if t5_ok:
        passed_count += 1
    test_logs.append({
        "name": "Regression 5: Repeated Chennai Fact Prevents Active Duplicate",
        "status": "PASS" if t5_ok else "FAIL",
        "details": f"StorageStatus={t7_res.get('storage_status')}, ActiveChennaiCount={active_chennai_count} (exp: 1)"
    })

    # -------------------------------------------------------------------------
    # Test 6: Dynamic Quick-Action Suggestions Reflect Active Persona (Chennai)
    # and Do Not Suggest Old Location (Hyderabad) as Current
    # -------------------------------------------------------------------------
    suggestions = persona_engine.generate_quick_action_suggestions(user_id=EVAL_USER_ID)
    suggestion_texts = [s.get("text", "") for s in suggestions]
    suggestion_labels = [s.get("label", "") for s in suggestions]
    combined_suggestions = " ".join(suggestion_texts + suggestion_labels).lower()

    # Active location (Chennai) should be suggested
    suggests_active_chennai = "chennai" in combined_suggestions
    # Historical question should be suggested if past location exists
    suggests_historical_question = any("before" in text.lower() or "previously" in text.lower() for text in suggestion_texts)
    # Old location (Hyderabad) must NOT be suggested as current location (e.g., no "Where do I live in Hyderabad" or "Things to do in Hyderabad")
    no_old_location_as_current = not any(
        "live in hyderabad" in text.lower() or "current location: hyderabad" in text.lower()
        for text in suggestion_texts
    )

    t6_ok = (suggests_active_chennai and suggests_historical_question and no_old_location_as_current and len(suggestions) > 0)
    if t6_ok:
        passed_count += 1
    test_logs.append({
        "name": "Regression 6: Quick Actions Suggest Active Chennai, Not Old Location",
        "status": "PASS" if t6_ok else "FAIL",
        "details": f"Count={len(suggestions)}, SuggestsChennai={suggests_active_chennai}, HistoricalOption={suggests_historical_question}, NoHydCurrent={no_old_location_as_current}"
    })

    # -------------------------------------------------------------------------
    # Test 7: Fallback to General Quick Actions When No User Persona Exists
    # -------------------------------------------------------------------------
    fallback_suggestions = persona_engine.generate_quick_action_suggestions(user_id="empty_fresh_user_test")
    has_fallback = len(fallback_suggestions) >= 3
    t7_ok = has_fallback
    if t7_ok:
        passed_count += 1
    test_logs.append({
        "name": "Regression 7: Quick Actions Fallback to General Suggestions for Fresh Users",
        "status": "PASS" if t7_ok else "FAIL",
        "details": f"Fallback suggestions count={len(fallback_suggestions)}"
    })

    chennai_accuracy = (passed_count / total_tests * 100.0)

    return {
        "chennai_reconciliation_accuracy": chennai_accuracy,
        "test_logs": test_logs
    }


if __name__ == "__main__":
    res = evaluate_chennai_reconciliation_regression()
    print("\n" + "=" * 60)
    print("CHENNAI RECONCILIATION REGRESSION TEST RESULTS")
    print("=" * 60)
    for log in res["test_logs"]:
        print(f"[{log['status']}] {log['name']}: {log['details']}")
    print("-" * 60)
    print(f"ACCURACY: {res['chennai_reconciliation_accuracy']:.1f}%")
    print("=" * 60)
