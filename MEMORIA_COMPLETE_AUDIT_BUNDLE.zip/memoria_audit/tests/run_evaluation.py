"""
Master Evaluation Runner for Memory OS
Executes all evaluators (including location update regression tests),
logs PASS/FAIL for individual test cases, and prints the formatted evaluation report & retrieval comparison table.
"""

import sys
import os

# Ensure workspace root is in python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.evaluators.test_ingestion_rejection import evaluate_ingestion_and_rejection
from tests.evaluators.test_retrieval_performance import evaluate_retrieval_performance
from tests.evaluators.test_tiers_decay import evaluate_tiers_and_decay
from tests.evaluators.test_persona_compression import evaluate_persona_and_compression
from tests.evaluators.test_e2e_chat import evaluate_e2e_chat
from tests.evaluators.test_lifecycle_scheduler import evaluate_lifecycle_scheduler
from tests.evaluators.test_bengaluru_regression import evaluate_bengaluru_regression
from tests.evaluators.test_conversation_context import evaluate_conversation_context
from tests.evaluators.test_chennai_reconciliation_regression import evaluate_chennai_reconciliation_regression
from tests.evaluators.test_memory_classification import evaluate_memory_classification


def run_full_evaluation():
    print("\nStarting Memory OS Automated Evaluation Suite...\n")
    all_logs = []

    # 1. Ingestion & Rejection Evaluator
    ingest_res = evaluate_ingestion_and_rejection()
    all_logs.extend(ingest_res.get("test_logs", []))

    # 2. Retrieval Performance Evaluator (Vector vs BM25 vs Hybrid)
    retrieval_res = evaluate_retrieval_performance()
    all_logs.extend(retrieval_res.get("test_logs", []))

    # 3. Multi-Tier Hierarchy, Ebbinghaus Decay & Archival Evaluator
    tier_decay_res = evaluate_tiers_and_decay()
    all_logs.extend(tier_decay_res.get("test_logs", []))

    # 4. Persona Synthesis & Compression Evaluator
    persona_comp_res = evaluate_persona_and_compression()
    all_logs.extend(persona_comp_res.get("test_logs", []))

    # 5. End-to-End Chat Evaluator
    e2e_res = evaluate_e2e_chat()
    all_logs.extend(e2e_res.get("test_logs", []))

    # 6. Background Memory Lifecycle Scheduler Evaluator
    scheduler_res = evaluate_lifecycle_scheduler()
    all_logs.extend(scheduler_res.get("test_logs", []))

    # 7. Bengaluru Relocation & Intent Gating Regression Evaluator
    bengaluru_res = evaluate_bengaluru_regression()
    all_logs.extend(bengaluru_res.get("test_logs", []))

    # 8. Conversational Context & Reference Resolution Evaluator
    context_res = evaluate_conversation_context()
    all_logs.extend(context_res.get("test_logs", []))

    # 9. Chennai Location Reconciliation & Quick Actions Evaluator
    chennai_res = evaluate_chennai_reconciliation_regression()
    all_logs.extend(chennai_res.get("test_logs", []))

    # 10. Memory Semantic Classification & Health Category Evaluator
    classif_res = evaluate_memory_classification()
    all_logs.extend(classif_res.get("test_logs", []))

    # -------------------------------------------------------------------------
    # Log Individual Test Case PASS / FAIL Results
    # -------------------------------------------------------------------------
    print("------------------------------------------------------------------------")
    print("                      INDIVIDUAL TEST CASE RESULTS                      ")
    print("------------------------------------------------------------------------")
    for log in all_logs:
        status = log["status"]
        name = log["name"]
        details = log["details"]
        tag = f"[{status}]"
        print(f"{tag:<8} {name:<50} | {details}")

    # -------------------------------------------------------------------------
    # Print Comparative Retrieval Table (Vector vs BM25 vs Hybrid)
    # -------------------------------------------------------------------------
    vec = retrieval_res["vector_metrics"]
    bm25 = retrieval_res["bm25_metrics"]
    hyb = retrieval_res["hybrid_metrics"]

    print("\n--------------------------------------------------")
    print("      RETRIEVAL COMPARISON BENCHMARK TABLE        ")
    print("--------------------------------------------------")
    print(f"{'Metric':<22} {'Vector':<10} {'BM25':<10} {'Hybrid':<10}")
    print("-" * 50)
    print(f"{'Hit Rate@1':<22} {vec['hit_rate_1']:.0f}%{'':<6} {bm25['hit_rate_1']:.0f}%{'':<6} {hyb['hit_rate_1']:.0f}%")
    print(f"{'Recall@5':<22} {vec['recall_5']:.0f}%{'':<6} {bm25['recall_5']:.0f}%{'':<6} {hyb['recall_5']:.0f}%")
    print(f"{'Precision@5':<22} {vec['precision_5']:.0f}%{'':<6} {bm25['precision_5']:.0f}%{'':<6} {hyb['precision_5']:.0f}%")
    print(f"{'MRR':<22} {vec['mrr']:.2f}{'':<6} {bm25['mrr']:.2f}{'':<6} {hyb['mrr']:.2f}")
    print(f"{'Relevance Accuracy':<22} {vec['relevance_accuracy']:.0f}%{'':<6} {bm25['relevance_accuracy']:.0f}%{'':<6} {hyb['relevance_accuracy']:.0f}%")
    print("--------------------------------------------------")

    # -------------------------------------------------------------------------
    # Print Master Metrics Summary Banner
    # -------------------------------------------------------------------------
    ingestion_acc = ingest_res["ingestion_accuracy"]
    rejection_acc = ingest_res["rejection_accuracy"]
    duplicate_acc = ingest_res["duplicate_accuracy"]
    update_acc = ingest_res["update_accuracy"]

    recall_5 = hyb["recall_5"]
    precision_5 = hyb["precision_5"]
    relevance_acc = hyb["relevance_accuracy"]

    tier_acc = tier_decay_res["tier_retrieval_accuracy"]
    decay_acc = tier_decay_res["decay_accuracy"]
    restoration_acc = tier_decay_res["restoration_accuracy"]

    compression_eff = persona_comp_res["compression_effectiveness"]

    print("\n========================================")
    print("       MEMORY OS EVALUATION")
    print("========================================")
    print(f"Memory Ingestion Accuracy : {ingestion_acc:.0f}%")
    print(f"Memory Rejection Accuracy : {rejection_acc:.0f}%")
    print(f"Duplicate Accuracy        : {duplicate_acc:.0f}%")
    print(f"Update Accuracy            : {update_acc:.0f}%")
    print(f"Retrieval Recall@5         : {recall_5:.0f}%")
    print(f"Retrieval Precision@5      : {precision_5:.0f}%")
    print(f"Relevance Accuracy         : {relevance_acc:.0f}%")
    print(f"Tier Retrieval Accuracy   : {tier_acc:.0f}%")
    print(f"Decay Accuracy             : {decay_acc:.0f}%")
    print(f"Restoration Accuracy       : {restoration_acc:.0f}%")
    print(f"Compression Effectiveness : {compression_eff:.0f}%")
    print(f"Lifecycle Scheduler Acc   : {scheduler_res['scheduler_accuracy']:.0f}%")
    print(f"Bengaluru Regression Acc  : {bengaluru_res['bengaluru_regression_accuracy']:.0f}%")
    print(f"Conversation Context Acc  : {context_res['context_accuracy']:.0f}%")
    print(f"Chennai Reconciliation Acc: {chennai_res['chennai_reconciliation_accuracy']:.0f}%")
    print(f"Classification Accuracy   : {classif_res['classification_accuracy']:.0f}%")
    print("========================================\n")
    from app.core import metrics
    print(f"Metrics Snapshot: {metrics.snapshot()}")


if __name__ == "__main__":
    run_full_evaluation()
