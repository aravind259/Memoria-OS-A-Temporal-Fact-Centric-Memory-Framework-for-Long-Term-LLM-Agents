# PATENT SPECIFICATION DOCUMENT

**TITLE OF INVENTION:**
SYSTEM AND METHOD FOR ADAPTIVE MULTI-TIERED CONVERSATIONAL MEMORY WITH DYNAMIC EBBINGHAUS DECAY, AUTOMATED CONTRADICTION RESOLUTION, AND HYBRID RAG RETRIEVAL

---

## ABSTRACT

An intelligent artificial intelligence memory operating system architecture for conversational agents comprising a dynamic multi-tiered memory pipeline. The system receives natural language user utterances, classifies semantic category and temporal permanence, filters ephemeral conversational noise via a Large Language Model (LLM) memory gate, extracts atomic factual assertions, and reconciles incoming knowledge against existing vector representations. Incoming facts that update or contradict prior knowledge trigger atomic lineage versioning (`superseded` vs `active` states). A dynamic hybrid retrieval engine ranks active memories by synthesizing dense vector embedding similarity, sparse BM25 lexical scores, semantic importance, and an adapted Ebbinghaus memory retention decay function $R(\Delta t) = \exp\left(-\frac{\Delta t}{S \cdot (1 + \ln(1 + \text{AccessCount}))}\right)$. Ranked memories and working memory context are dynamically constructed into augmented language model prompts, eliminating catastrophic forgetting and context drift in open-domain conversational AI.

---

## TECHNICAL FIELD

This invention relates generally to conversational artificial intelligence, Natural Language Processing (NLP), and retrieval-augmented generation (RAG) architectures, and more particularly to systems and computer-implemented methods for managing persistent, dynamic, decay-weighted, and self-reconciling long-term memory structures for Large Language Models (LLMs).

---

## BACKGROUND AND PRIOR ART

Standard Large Language Model (LLM) conversational agents are inherently stateless across distinct sessions. While fixed context windows allow agents to track immediate dialogue turns, long-term memory across days, weeks, or months requires external vector retrieval systems.

Existing retrieval solutions suffer from key technical deficiencies:
1. **Goldfish Memory & Static Vectors**: Classical vector databases store fixed embeddings without temporal decay. Information from a year ago is weighted identically to information acquired five minutes ago, failing to model human memory decay.
2. **Memory Overwrite vs Duplicate Rejection Dilemma**: Existing systems either blindly overwrite previous memories or discard incoming similar statements as duplicates, failing to detect factual evolution (e.g. user changing locations or job roles).
3. **Keyword-Vector Mismatch (Vector Drift)**: Pure dense vector search frequently fails on exact keyword, alphanumeric, or named-entity matches due to high-dimensional semantic smoothing.
4. **Context Pollution**: Storing small talk, one-off instructions, or ephemeral questions degrades retrieval accuracy over time.

---

## DETAILED DESCRIPTION OF INNOVATIONS & MATHEMATICAL FORMALISM

```mermaid
flowchart TD
    A[User Utterance] --> B[Memory Classifier]
    A --> C[Importance Evaluator]
    B --> D{Storage Threshold}
    C --> D
    D -- Pass --> E[LLM Memory Gate]
    D -- Fail --> Z[Discard / Ephemeral Memory]
    E -- Approved --> F[Atomic Fact Extractor]
    E -- Rejected --> Z
    F --> G[Embedding Encoder & Vector DB]
    G --> H{Memory Reconciler}
    H -- SUPERSEDES --> I[Mark Old Memory SUPERSEDED & Insert New ACTIVE]
    H -- REINFORCES --> J[Increment Access / Stability Count]
    H -- DISTINCT --> K[Insert New ACTIVE Memory]
    
    L[User Query] --> M[Hybrid Retrieval Engine]
    M --> N[Dense Vector Similarity]
    M --> O[Sparse BM25 Lexical Score]
    M --> P[Ebbinghaus Retention Decay R_t]
    N & O & P --> Q[Composite Score Reranker]
    Q --> R[Dynamic Prompt Builder]
    R --> S[LLM Generation]
```

### 1. Dynamic Ebbinghaus Memory Retention Decay Engine

The memory retention probability $R(\Delta t)$ of a stored memory item $m_i$ at current time $t$ given creation timestamp $t_0$ is defined by:

$$\Delta t = \frac{t - t_0}{3600} \quad \text{(hours)}$$

$$\text{Stability } S = \max(0.1, \text{Importance Score}) \times 24.0$$

$$R(\Delta t) = \exp\left( -\frac{\Delta t}{S \cdot (1 + \ln(1 + \text{AccessCount}))} \right)$$

### 2. Composite Patent Reranking Formula

When a user query $q$ is issued, candidate memories are retrieved and scored using the composite patent ranking function:

$$\text{Score}(m_i, q) = \left(\frac{1}{1 + \text{Dist}(m_i, q)} \cdot 0.45\right) + \left(\frac{\text{BM25}(m_i, q)}{\max \text{BM25}} \cdot 0.20\right) + \left(R(\Delta t) \cdot 0.25\right) + (\text{Importance}_i \cdot 0.10)$$

---

## FORMAL PATENT CLAIMS

### Claim 1 (Independent Method Claim)
A computer-implemented method for maintaining persistent long-term memory across multi-session conversational AI interactions, the method comprising:
1. Receiving a natural language message from a user in a conversational session;
2. Evaluating a semantic category and a temporal permanence score for the received message;
3. Passing the message through a Large Language Model (LLM) memory gating prompt configured to filter ephemeral conversation turns while identifying durable user facts;
4. Extracting an atomic, third-person factual statement from the approved message;
5. Querying a vector storage system using an embedding of the atomic factual statement to identify nearest candidate existing memories;
6. Reconciling the atomic factual statement against identified candidate memories by determining a semantic relationship selected from the group consisting of: `SUPERSEDES`, `REINFORCES`, `CONTRADICTS`, and `DISTINCT`;
7. Upon determining a `SUPERSEDES` relationship, updating a metadata status of a matched existing memory to `SUPERSEDED` and persisting the atomic factual statement as an `ACTIVE` memory linked via lineage metadata; and
8. Constructing an augmented prompt for an LLM response generation by retrieving active memories ranked using a composite score combining vector embedding similarity, lexical BM25 similarity, semantic importance, and an Ebbinghaus time-decay retention function.

### Claim 2 (Dependent Claim)
The method of claim 1, wherein the Ebbinghaus time-decay retention function calculates memory retention $R(\Delta t)$ as an exponential decay function of elapsed time scaled by a memory stability score and logarithmic access count reinforcement.

### Claim 3 (Dependent Claim)
The method of claim 1, wherein reconciling the atomic factual statement comprises submitting candidate existing memory text and new memory text to an LLM reconciliation prompt yielding a structured JSON decision.

### Claim 4 (Dependent Claim)
The method of claim 1, wherein retrieving active memories comprises applying a status filter restricting vector collection queries to memories having status equal to `ACTIVE`.

### Claim 5 (Independent System Claim)
A system comprising a processor and a memory storing computer-executable instructions that, when executed by the processor, perform the steps of Claim 1 through Claim 4.
