"""
Deterministic Benchmark Datasets for Memory OS Evaluation Suite
"""

# 1. Ingestion Test Cases: Messages that MUST be accepted and stored as persistent long-term memories
INGESTION_TEST_CASES = [
    {
        "input": "I am a Senior Software Architect based in Seattle.",
        "expected_category": "Fact",
        "should_store": True,
        "description": "User professional role and location fact"
    },
    {
        "input": "My favorite programming languages are Python, Rust, and TypeScript.",
        "expected_category": "Preference",
        "should_store": True,
        "description": "User technical preferences"
    },
    {
        "input": "I am building a multi-agent AI memory system project using FastAPI and ChromaDB.",
        "expected_category": "Project",
        "should_store": True,
        "description": "User project specification"
    },
    {
        "input": "My primary goal for 2026 is to publish a patent on AI memory retention.",
        "expected_category": "Goal",
        "should_store": True,
        "description": "User long-term goal"
    },
    {
        "input": "I am highly skilled in distributed systems design and vector retrieval optimization.",
        "expected_category": "Skill",
        "should_store": True,
        "description": "User technical skills"
    }
]

# 2. Rejection Test Cases: Ephemeral chit-chat, questions, or low-importance statements that MUST be rejected
REJECTION_TEST_CASES = [
    {
        "input": "Hello! How are you doing today?",
        "should_store": False,
        "description": "Casual greeting chit-chat"
    },
    {
        "input": "What programming languages do I like?",
        "should_store": False,
        "description": "User query asking for stored memory"
    },
    {
        "input": "Where is the nearest coffee shop?",
        "should_store": False,
        "description": "Ephemeral question"
    },
    {
        "input": "Okay cool, thanks for letting me know!",
        "should_store": False,
        "description": "Conversational acknowledgment"
    },
    {
        "input": "What is the capital of France?",
        "should_store": False,
        "description": "General knowledge question"
    }
]

# 3. Duplicate Detection & Reinforcement Test Cases
DUPLICATE_TEST_CASES = [
    {
        "initial": "I prefer dark mode in code editors.",
        "repeat": "I prefer dark mode in code editors.",
        "expected_status": "REINFORCED",
        "description": "Exact duplicate preference reinforcement"
    }
]

# 4. Memory Reconciliation & Lineage Update Test Cases
RECONCILIATION_TEST_CASES = [
    {
        "initial": "I live in Seattle, Washington.",
        "update": "I recently moved and now live in San Francisco, California.",
        "expected_status": "SUPERSEDES",
        "query": "Where do I live?",
        "expected_active_contain": "San Francisco",
        "description": "Factual location evolution and lineage versioning"
    }
]

# 5. Master Seed Corpus for Comprehensive Retrieval Benchmarking
BENCHMARK_SEED_CORPUS = [
    {
        "id": "mem-fact-001",
        "doc": "User's full name is Aravi and user lives in San Francisco, California.",
        "category": "Fact",
        "importance": 0.9,
        "status": "active"
    },
    {
        "id": "mem-fact-002",
        "doc": "User previously lived in Seattle, Washington.",
        "category": "Fact",
        "importance": 0.7,
        "status": "superseded"
    },
    {
        "id": "mem-pref-001",
        "doc": "User prefers dark mode themes and mechanical keyboards with tactile switches.",
        "category": "Preference",
        "importance": 0.8,
        "status": "active"
    },
    {
        "id": "mem-pref-002",
        "doc": "User prefers Python, Rust, and TypeScript for software development.",
        "category": "Preference",
        "importance": 0.85,
        "status": "active"
    },
    {
        "id": "mem-goal-001",
        "doc": "User's primary career goal for 2026 is to publish a patent on AI memory retention systems.",
        "category": "Goal",
        "importance": 0.95,
        "status": "active"
    },
    {
        "id": "mem-skill-001",
        "doc": "User is skilled in distributed systems design, vector retrieval optimization, and FastAPI.",
        "category": "Skill",
        "importance": 0.9,
        "status": "active"
    },
    {
        "id": "mem-proj-001",
        "doc": "User is currently building Memory OS, a multi-tiered conversational AI memory system using FastAPI and ChromaDB.",
        "category": "Project",
        "importance": 0.9,
        "status": "active"
    },
    {
        "id": "mem-pref-003",
        "doc": "User enjoys drinking green tea in the morning while reading research papers.",
        "category": "Preference",
        "importance": 0.6,
        "status": "active"
    }
]

# 6. Comprehensive 10-Query Retrieval Benchmark Suite
RETRIEVAL_BENCHMARK_DATASET_10 = [
    {
        "id": "Q1",
        "type": "preferences",
        "query": "What programming languages do I like to code in?",
        "relevant_docs": [
            "User prefers Python, Rust, and TypeScript for software development."
        ],
        "k": 5,
        "description": "Technical programming language preferences query"
    },
    {
        "id": "Q2",
        "type": "goals",
        "query": "What is my primary career goal for 2026?",
        "relevant_docs": [
            "User's primary career goal for 2026 is to publish a patent on AI memory retention systems."
        ],
        "k": 5,
        "description": "Long-term career goal retrieval"
    },
    {
        "id": "Q3",
        "type": "projects",
        "query": "What project am I building right now?",
        "relevant_docs": [
            "User is currently building Memory OS, a multi-tiered conversational AI memory system using FastAPI and ChromaDB."
        ],
        "k": 5,
        "description": "Current active project details"
    },
    {
        "id": "Q4",
        "type": "conflicting_updated",
        "query": "Where do I live currently?",
        "relevant_docs": [
            "User's full name is Aravi and user lives in San Francisco, California."
        ],
        "irrelevant_docs": [
            "User previously lived in Seattle, Washington."
        ],
        "k": 5,
        "description": "Current location vs superseded location query"
    },
    {
        "id": "Q5",
        "type": "skills",
        "query": "What are my main technical skills?",
        "relevant_docs": [
            "User is skilled in distributed systems design, vector retrieval optimization, and FastAPI."
        ],
        "k": 5,
        "description": "User core engineering skills"
    },
    {
        "id": "Q6",
        "type": "preferences",
        "query": "What hardware and UI preferences do I have?",
        "relevant_docs": [
            "User prefers dark mode themes and mechanical keyboards with tactile switches."
        ],
        "k": 5,
        "description": "Hardware and theme preferences"
    },
    {
        "id": "Q7",
        "type": "personal_facts",
        "query": "Who am I and what is my name?",
        "relevant_docs": [
            "User's full name is Aravi and user lives in San Francisco, California."
        ],
        "k": 5,
        "description": "Personal identity fact"
    },
    {
        "id": "Q8",
        "type": "paraphrased_questions",
        "query": "Tell me about my background in vector memory architectures.",
        "relevant_docs": [
            "User is skilled in distributed systems design, vector retrieval optimization, and FastAPI.",
            "User is currently building Memory OS, a multi-tiered conversational AI memory system using FastAPI and ChromaDB."
        ],
        "k": 5,
        "description": "Paraphrased query matching skills and project"
    },
    {
        "id": "Q9",
        "type": "irrelevant",
        "query": "What is quantum computing error mitigation?",
        "relevant_docs": [],
        "k": 5,
        "description": "Irrelevant query (Negative control: expected 0 relevant hits)"
    },
    {
        "id": "Q10",
        "type": "general_knowledge",
        "query": "What is the capital of France?",
        "relevant_docs": [],
        "k": 5,
        "description": "General knowledge query (Negative control: expected 0 relevant hits)"
    }
]

# Legacy dataset kept for backward compatibility with existing tests
RETRIEVAL_BENCHMARK_DATASET = RETRIEVAL_BENCHMARK_DATASET_10[:3]

# 7. Retrieval Relevance Filtering Test Cases
RELEVANCE_TEST_CASES = [
    {
        "seed_memories": [
            "User's dog is named Rex.",
            "User's favorite food is Italian sushi."
        ],
        "query": "What is quantum computing error mitigation?",
        "should_retrieve_count": 0,
        "description": "Irrelevant query against personal memories"
    }
]

# 8. Persona Synthesis Expected Verification Dataset
PERSONA_TEST_CASES = [
    {
        "memories": [
            {"doc": "My name is Aravi", "cat": "Fact"},
            {"doc": "I live in San Francisco", "cat": "Fact"},
            {"doc": "I prefer Python and Rust", "cat": "Preference"},
            {"doc": "I am skilled in distributed systems design", "cat": "Skill"}
        ],
        "expected_name": "Aravi",
        "expected_location": "San Francisco",
        "description": "Extraction of structured persona attributes"
    }
]
