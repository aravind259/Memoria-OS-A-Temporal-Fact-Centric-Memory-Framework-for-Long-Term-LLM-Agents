"""
Evaluator 4: Persona Synthesis & Memory Compression Effectiveness
"""

from typing import Dict, Any
from app.memory.persona import UserPersonaEngine
from app.memory.working_memory import WorkingMemory
from app.memory.chroma import clear_all_memories, save_memory
from app.embeddings.encoder import get_embedding
from tests.dataset import PERSONA_TEST_CASES

EVAL_USER_ID = "eval_user_persona_comp_test"


def evaluate_persona_and_compression() -> Dict[str, Any]:
    test_logs = []
    persona_engine = UserPersonaEngine()
    wm = WorkingMemory()

    clear_all_memories()
    wm.clear()

    # -------------------------------------------------------------------------
    # 1. Persona Synthesis Accuracy
    # -------------------------------------------------------------------------
    persona_passed = 0
    persona_total = len(PERSONA_TEST_CASES)

    for case in PERSONA_TEST_CASES:
        for mem in case["memories"]:
            save_memory(
                memory=mem["doc"],
                embedding=get_embedding(mem["doc"]),
                category=mem["cat"],
                importance=0.9,
                user_id=EVAL_USER_ID
            )

        synth = persona_engine.synthesize_persona(user_id=EVAL_USER_ID)
        name_ok = (synth.get("name") == case["expected_name"])
        loc_ok = (synth.get("location") == case["expected_location"])
        total_mems_ok = (synth.get("total_active_memories") == len(case["memories"]))

        passed = (name_ok and loc_ok and total_mems_ok)
        if passed:
            persona_passed += 1

        test_logs.append({
            "name": f"Persona Synthesis: {case['description']}",
            "status": "PASS" if passed else "FAIL",
            "details": f"Name: '{synth.get('name')}' (exp: {case['expected_name']}), Loc: '{synth.get('location')}' (exp: {case['expected_location']})"
        })

    persona_accuracy = (persona_passed / persona_total * 100.0) if persona_total > 0 else 0.0

    # -------------------------------------------------------------------------
    # 2. Memory Compression Effectiveness
    # -------------------------------------------------------------------------
    # Test mid-term episodic memory compression ratio
    raw_chars = 0
    for i in range(10):
        user_msg = f"In iteration {i}, I stated detailed technical preference regarding distributed vector database partitioning schema #{i}."
        ai_resp = f"Response {i} acknowledging detailed technical configuration for server cluster node #{i}."
        raw_chars += len(user_msg) + len(ai_resp)
        wm.add_turn(user_msg, ai_resp, category="Preference", importance=0.85)

    mid_term_summaries = wm.get_mid_term_summaries()
    compressed_chars = sum(len(s.get("summary", "")) for s in mid_term_summaries)

    compression_ratio = (1.0 - (compressed_chars / raw_chars)) * 100.0 if raw_chars > 0 else 0.0
    comp_passed = (compression_ratio > 30.0)  # At least 30% text compression

    test_logs.append({
        "name": "Mid-Term Memory Summarization & Compression",
        "status": "PASS" if comp_passed else "FAIL",
        "details": f"Raw input: {raw_chars} chars -> Compressed: {compressed_chars} chars ({compression_ratio:.1f}% reduction)"
    })

    return {
        "persona_accuracy": persona_accuracy,
        "compression_effectiveness": compression_ratio if comp_passed else 0.0,
        "test_logs": test_logs
    }
