"""
Evaluator 1: Ingestion, Rejection, Duplicate Detection, and Memory Reconciliation
"""

from typing import Dict, Any
from app.memory.storage import MemoryStorage
from app.memory.duplicate import DuplicateDetector
from app.memory.chroma import get_all_memories, clear_all_memories
from tests.dataset import (
    INGESTION_TEST_CASES,
    REJECTION_TEST_CASES,
    DUPLICATE_TEST_CASES,
    RECONCILIATION_TEST_CASES
)

EVAL_USER_ID = "eval_user_ingest_test"


def evaluate_ingestion_and_rejection() -> Dict[str, Any]:
    storage = MemoryStorage()
    duplicate_detector = DuplicateDetector()

    # Clear isolated evaluation test user memories before evaluation
    clear_all_memories()

    test_logs = []
    
    # -------------------------------------------------------------------------
    # 1. Ingestion Evaluation
    # -------------------------------------------------------------------------
    ingest_passed = 0
    ingest_total = len(INGESTION_TEST_CASES)

    for case in INGESTION_TEST_CASES:
        res = storage.store(
            user_message=case["input"],
            ai_response="Acknowledged.",
            user_id=EVAL_USER_ID
        )
        stored = res.get("stored", False)
        cat = res.get("category", "")
        passed = (stored == case["should_store"])
        if passed:
            ingest_passed += 1

        test_logs.append({
            "name": f"Ingestion: {case['description']}",
            "status": "PASS" if passed else "FAIL",
            "details": f"Expected stored={case['should_store']}, got stored={stored}, category='{cat}'"
        })

    ingestion_accuracy = (ingest_passed / ingest_total * 100.0) if ingest_total > 0 else 0.0

    # -------------------------------------------------------------------------
    # 2. Rejection Evaluation
    # -------------------------------------------------------------------------
    reject_passed = 0
    reject_total = len(REJECTION_TEST_CASES)

    for case in REJECTION_TEST_CASES:
        res = storage.store(
            user_message=case["input"],
            ai_response="Here is some information.",
            user_id=EVAL_USER_ID
        )
        stored = res.get("stored", False)
        passed = (stored == case["should_store"])
        if passed:
            reject_passed += 1

        test_logs.append({
            "name": f"Rejection: {case['description']}",
            "status": "PASS" if passed else "FAIL",
            "details": f"Expected stored={case['should_store']}, got stored={stored}, reason='{res.get('reason')}'"
        })

    rejection_accuracy = (reject_passed / reject_total * 100.0) if reject_total > 0 else 0.0

    # -------------------------------------------------------------------------
    # 3. Duplicate Detection Evaluation
    # -------------------------------------------------------------------------
    dup_passed = 0
    dup_total = len(DUPLICATE_TEST_CASES)

    for case in DUPLICATE_TEST_CASES:
        # Initial store
        res1 = storage.store(
            user_message=case["initial"],
            ai_response="Noted.",
            user_id=EVAL_USER_ID
        )
        # Duplicate store
        res2 = storage.store(
            user_message=case["repeat"],
            ai_response="Noted again.",
            user_id=EVAL_USER_ID
        )
        
        status = res2.get("status", "")
        action = res2.get("action", "")
        passed = (status == case["expected_status"] or action == "reinforce")
        if passed:
            dup_passed += 1

        test_logs.append({
            "name": f"Duplicate: {case['description']}",
            "status": "PASS" if passed else "FAIL",
            "details": f"Expected status='{case['expected_status']}', got status='{status}', action='{action}'"
        })

    duplicate_accuracy = (dup_passed / dup_total * 100.0) if dup_total > 0 else 0.0

    # -------------------------------------------------------------------------
    # 4. Memory Reconciliation & Lineage Update Evaluation
    # -------------------------------------------------------------------------
    rec_passed = 0
    rec_total = len(RECONCILIATION_TEST_CASES)

    for case in RECONCILIATION_TEST_CASES:
        # Store initial fact
        res1 = storage.store(
            user_message=case["initial"],
            ai_response="Recorded.",
            user_id=EVAL_USER_ID
        )
        old_id = res1.get("memory_id")

        # Store updating/contradicting fact
        res2 = storage.store(
            user_message=case["update"],
            ai_response="Updated.",
            user_id=EVAL_USER_ID
        )
        status = res2.get("status", "")
        action = res2.get("action", "")

        # Check lineage status in Chroma DB
        all_mems = get_all_memories(include_superseded=True, user_id=EVAL_USER_ID)
        active_mems = get_all_memories(include_superseded=False, user_id=EVAL_USER_ID)

        superseded_found = any(m.get("metadata", {}).get("status") == "superseded" for m in all_mems)
        active_has_new = any(case["expected_active_contain"].lower() in m.get("document", "").lower() for m in active_mems)

        passed = (status == case["expected_status"] or action == "supersede" or superseded_found) and active_has_new
        if passed:
            rec_passed += 1

        test_logs.append({
            "name": f"Reconciliation: {case['description']}",
            "status": "PASS" if passed else "FAIL",
            "details": f"Expected status='{case['expected_status']}', got status='{status}', superseded_found={superseded_found}"
        })

    update_accuracy = (rec_passed / rec_total * 100.0) if rec_total > 0 else 0.0

    return {
        "ingestion_accuracy": ingestion_accuracy,
        "rejection_accuracy": rejection_accuracy,
        "duplicate_accuracy": duplicate_accuracy,
        "update_accuracy": update_accuracy,
        "test_logs": test_logs
    }
