"""
Evaluator 3: Multi-Tier Hierarchy (L1, L2, L3), Ebbinghaus Retention Decay, Archival & Restoration
"""

from typing import Dict, Any
from datetime import datetime, timedelta
from app.memory.working_memory import WorkingMemory
from app.memory.archive_storage import ColdArchiveStorage
from app.memory.tier_manager import MemoryTierManager
from app.memory.adaptive_decay import AdaptiveDecayEngine
from app.memory.compactor import OSMemoryCompactor
from app.memory.chroma import clear_all_memories, get_all_memories, save_memory
from app.embeddings.encoder import get_embedding

EVAL_USER_ID = "eval_user_tiers_decay_test"


def evaluate_tiers_and_decay() -> Dict[str, Any]:
    test_logs = []

    # Clean isolated state
    clear_all_memories()
    archive = ColdArchiveStorage()
    archive.clear_all()
    wm = WorkingMemory()
    tier_mgr = MemoryTierManager(working_memory=wm, archive_storage=archive)
    decay_engine = AdaptiveDecayEngine()
    compactor = OSMemoryCompactor(archive_storage=archive)

    # -------------------------------------------------------------------------
    # 1. Tier Retrieval Behavior (L1, L2, L3)
    # -------------------------------------------------------------------------
    tier_passed_count = 0
    tier_tests_total = 4

    # Test 1.1: Promote to L1 Fast RAM
    mem_l1_test = {
        "id": "tier-test-l1-001",
        "document": "User works at Microsoft as a Principal Architect.",
        "metadata": {"category": "Fact", "importance": 0.9, "user_id": EVAL_USER_ID}
    }
    tier_mgr.promote_to_l1(mem_l1_test)
    l1_hits = wm.search_l1("Microsoft Architect", user_id=EVAL_USER_ID)
    if len(l1_hits) > 0:
        tier_passed_count += 1
    test_logs.append({
        "name": "L1 RAM Buffer Search Hit",
        "status": "PASS" if len(l1_hits) > 0 else "FAIL",
        "details": f"L1 search returned {len(l1_hits)} hits"
    })

    # Test 1.2: Move to L2 ChromaDB Vector Store
    mem_l2_res = tier_mgr.move_to_l2(mem_l1_test)
    l2_memories = get_all_memories(include_superseded=False, user_id=EVAL_USER_ID)
    if len(l2_memories) > 0:
        tier_passed_count += 1
    test_logs.append({
        "name": "L2 Vector Store Persistence",
        "status": "PASS" if len(l2_memories) > 0 else "FAIL",
        "details": f"L2 active memories count: {len(l2_memories)}"
    })

    # Test 1.3: Archive to L3 SQLite Disk
    arch_ok = tier_mgr.archive_to_l3(mem_l1_test)
    l3_mems = archive.get_archived_memories(user_id=EVAL_USER_ID)
    if arch_ok and len(l3_mems) > 0:
        tier_passed_count += 1
    test_logs.append({
        "name": "L3 Cold SQLite Archive Write",
        "status": "PASS" if (arch_ok and len(l3_mems) > 0) else "FAIL",
        "details": f"L3 archived memories count: {len(l3_mems)}"
    })

    # Test 1.4: L3 Search Fallback
    l3_search_hits = archive.search_l3("Microsoft", user_id=EVAL_USER_ID)
    if len(l3_search_hits) > 0:
        tier_passed_count += 1
    test_logs.append({
        "name": "L3 Cold Storage Search Fallback",
        "status": "PASS" if len(l3_search_hits) > 0 else "FAIL",
        "details": f"L3 search hits: {len(l3_search_hits)}"
    })

    tier_retrieval_accuracy = (tier_passed_count / tier_tests_total * 100.0)

    # -------------------------------------------------------------------------
    # 2. Ebbinghaus Retention Decay & Stability Scoring Evaluation
    # -------------------------------------------------------------------------
    decay_passed_count = 0
    decay_tests_total = 3

    # Test 2.1: Immediate Retention (Delta t = 0)
    now_iso = datetime.utcnow().isoformat()
    r_fresh = decay_engine.calculate_retention(
        created_at_iso=now_iso,
        importance=0.8,
        access_count=0,
        category="Fact"
    )
    if r_fresh > 0.95:
        decay_passed_count += 1
    test_logs.append({
        "name": "Ebbinghaus Fresh Memory Retention R(0)",
        "status": "PASS" if r_fresh > 0.95 else "FAIL",
        "details": f"Fresh retention score R(0): {r_fresh:.4f}"
    })

    # Test 2.2: Decay Over Elapsed Time (Delta t = 100 hours)
    past_iso = (datetime.utcnow() - timedelta(hours=100)).isoformat()
    r_decayed = decay_engine.calculate_retention(
        created_at_iso=past_iso,
        importance=0.3,
        access_count=0,
        category="Fact"
    )
    if r_decayed < r_fresh:
        decay_passed_count += 1
    test_logs.append({
        "name": "Ebbinghaus Decay Over Time Delta",
        "status": "PASS" if r_decayed < r_fresh else "FAIL",
        "details": f"Retention after 100h: {r_decayed:.4f} vs Fresh: {r_fresh:.4f}"
    })

    # Test 2.3: Stability Reinforcement by Category & Access Count
    stab_fact = decay_engine.calculate_adaptive_stability(importance=0.5, access_count=0, category="Fact")
    stab_pref_reinforced = decay_engine.calculate_adaptive_stability(importance=0.5, access_count=5, category="Preference")
    if stab_pref_reinforced > stab_fact:
        decay_passed_count += 1
    test_logs.append({
        "name": "Stability Reinforcement Scaling S(t)",
        "status": "PASS" if stab_pref_reinforced > stab_fact else "FAIL",
        "details": f"Reinforced Preference S: {stab_pref_reinforced} vs Base Fact S: {stab_fact}"
    })

    decay_accuracy = (decay_passed_count / decay_tests_total * 100.0)

    # -------------------------------------------------------------------------
    # 3. Archival & Restoration Evaluation
    # -------------------------------------------------------------------------
    restore_passed_count = 0
    restore_tests_total = 2

    # Test 3.1: Automated Garbage Collection Compaction
    # Seed an old low-importance decayed memory in L2
    old_decayed_id = save_memory(
        memory="User temporarily mentioned looking at weather in 2020.",
        embedding=get_embedding("weather in 2020"),
        category="Conversation",
        importance=0.1,
        user_id=EVAL_USER_ID
    )
    # Run compaction
    compaction_res = compactor.run_garbage_collection(user_id=EVAL_USER_ID)
    if compaction_res.get("status") == "COMPACTION_COMPLETE":
        restore_passed_count += 1
    test_logs.append({
        "name": "OS Memory Compaction & Garbage Collection",
        "status": "PASS" if compaction_res.get("status") == "COMPACTION_COMPLETE" else "FAIL",
        "details": f"Paged out count: {compaction_res.get('paged_out_count')}"
    })

    # Test 3.2: Memory Restoration from L3 back to L2/L1
    mem_to_restore_id = "restore-test-id-999"
    archive.archive_memory({
        "id": mem_to_restore_id,
        "document": "User holds a patent in Quantum AI memory systems.",
        "metadata": {
            "id": mem_to_restore_id,
            "category": "Skill",
            "importance": 0.95,
            "user_id": EVAL_USER_ID,
            "status": "active"
        }
    })
    restored_mem = tier_mgr.restore_from_l3(mem_to_restore_id, promote_l1=True)
    l1_restored_hits = wm.search_l1("Quantum AI", user_id=EVAL_USER_ID)

    if restored_mem and len(l1_restored_hits) > 0:
        restore_passed_count += 1
    test_logs.append({
        "name": "Memory Restoration L3 -> L2 & L1 Promotion",
        "status": "PASS" if (restored_mem and len(l1_restored_hits) > 0) else "FAIL",
        "details": f"Restored memory ID: {restored_mem.get('id') if restored_mem else None}"
    })

    restoration_accuracy = (restore_passed_count / restore_tests_total * 100.0)

    return {
        "tier_retrieval_accuracy": tier_retrieval_accuracy,
        "decay_accuracy": decay_accuracy,
        "restoration_accuracy": restoration_accuracy,
        "test_logs": test_logs
    }
