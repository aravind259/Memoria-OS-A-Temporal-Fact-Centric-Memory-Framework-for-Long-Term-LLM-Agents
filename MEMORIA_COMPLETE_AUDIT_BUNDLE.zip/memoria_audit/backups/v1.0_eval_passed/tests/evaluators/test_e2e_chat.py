"""
Evaluator 5: End-to-End Chat Workflow Integration
"""

from typing import Dict, Any
from app.core.container import memory_manager, working_memory
from app.memory.chroma import clear_all_memories

EVAL_USER_ID = "eval_user_e2e_chat_test"


def evaluate_e2e_chat() -> Dict[str, Any]:
    test_logs = []

    clear_all_memories()
    working_memory.clear()

    # Step 1: Tell assistant a key personal fact
    msg1 = "I am a Senior DevOps Engineer based in Austin, Texas."
    res1 = memory_manager.chat(message=msg1, user_id=EVAL_USER_ID)

    resp1_ok = (res1.get("stored") is True and res1.get("response") is not None)
    test_logs.append({
        "name": "E2E Chat Turn 1: Fact Ingestion & Response",
        "status": "PASS" if resp1_ok else "FAIL",
        "details": f"Stored={res1.get('stored')}, Category={res1.get('category')}, Response len={len(res1.get('response', ''))}"
    })

    # Step 2: Query assistant to retrieve stored memory in next turn
    msg2 = "What is my job title and where do I live?"
    res2 = memory_manager.chat(message=msg2, user_id=EVAL_USER_ID)

    memories_used = res2.get("memories_used", [])
    used_has_fact = any("DevOps" in m.get("document", "") or "Austin" in m.get("document", "") for m in memories_used)

    resp2_ok = (len(memories_used) > 0 and used_has_fact)
    test_logs.append({
        "name": "E2E Chat Turn 2: Context Retrieval & RAG Generation",
        "status": "PASS" if resp2_ok else "FAIL",
        "details": f"Memories retrieved: {len(memories_used)}, Relevant context matched: {used_has_fact}"
    })

    e2e_passed = (resp1_ok and resp2_ok)

    return {
        "e2e_chat_accuracy": 100.0 if e2e_passed else 0.0,
        "test_logs": test_logs
    }
