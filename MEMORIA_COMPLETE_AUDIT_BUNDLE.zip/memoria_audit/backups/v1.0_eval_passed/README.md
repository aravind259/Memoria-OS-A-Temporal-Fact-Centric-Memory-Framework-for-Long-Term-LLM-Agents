# 🧠 Memory OS

**Memory OS** is a state-of-the-art AI Conversational Memory System featuring a dynamic, multi-stage long-term vector memory pipeline with mathematical **Ebbinghaus Retention Decay**, **Automated Contradiction Resolution**, **Hybrid BM25 + Dense Vector Search**, and a **Web UI Dashboard**.

---

## 📐 System Storage Architecture

```text
                USER MESSAGE
                     │
                     ▼
        ┌────────────────────────┐
        │ Memory Classifier      │
        │ Fact                   │
        │ Preference             │
        │ Goal                   │
        │ Project                │
        │ Skill                  │
        └──────────┬─────────────┘
                   │
                   ▼
        ┌────────────────────────┐
        │ Importance Scorer      │
        │ 0.0 ───────────► 1.0    │
        └──────────┬─────────────┘
                   │
                   ▼
        ┌────────────────────────┐
        │ Memory Gate            │
        │ Store?                 │
        │ Yes / No               │
        └──────────┬─────────────┘
                   │
                   ▼
        ┌────────────────────────┐
        │ Memory Extractor       │
        │ NLP → Structured Fact  │
        └──────────┬─────────────┘
                   │
                   ▼
        ┌────────────────────────┐
        │ Duplicate Detector     │
        └──────────┬─────────────┘
                   │
         ┌─────────┴─────────┐
         ▼                   ▼
 Duplicate             New Memory
 Ignore                    │
                            ▼
                 ┌────────────────────┐
                 │ Embedding Encoder  │
                 └──────────┬─────────┘
                            ▼
                 ┌────────────────────┐
                 │ ChromaDB Storage   │
                 └────────────────────┘
```

---

## ✨ Features

- **Semantic Memory Classification**: Classifies statements into `Fact`, `Preference`, `Goal`, `Project`, `Skill`, etc.
- **Dynamic Importance Scoring**: Scores memory permanence ($0.0 \text{ to } 1.0$).
- **Memory Gate Filter**: LLM prompt filter preventing ephemeral small talk or questions from polluting long-term memory.
- **Fact Distillation**: Converts raw user utterances into clean third-person atomic assertions.
- **Contradiction & Lineage Resolution**: Detects factual progression (*"Seattle"* $\rightarrow$ *"San Francisco"*), marking old memories `SUPERSEDED` and new facts `ACTIVE`.
- **Ebbinghaus Retention Decay**: Dynamic retention recall score $R(\Delta t) = \exp\left(-\frac{\Delta t}{S \cdot (1 + \ln(1 + \text{AccessCount}))}\right)$.
- **Hybrid RAG Reranking**: Combines dense vector similarity ($45\%$), BM25 lexical score ($20\%$), Ebbinghaus decay ($25\%$), and importance ($10\%$).
- **9-Model Failover Chain**: Automatic failover across 9 Gemini API models to prevent free-tier 429 quota blockages.
- **Web UI Dashboard**: Interactive dark-mode dashboard hosted at `http://127.0.0.1:8000`.

---

## 🚀 Quick Start & Usage

### 1. Installation & Environment Activation
```powershell
.\.venv\Scripts\Activate.ps1
```

### 2. Start Web Server
```bash
uvicorn app.main:app --reload --port 8000
```
Open **[http://127.0.0.1:8000](http://127.0.0.1:8000)** in your browser!

### 3. Run Verification Tests
```bash
python test_memory.py
```

---

## 📑 Patent Documentation
Complete patent application specification and claims are available at [patent_specification.md](file:///c:/Users/Aravi/OneDrive/Desktop/major/patent_specification.md).
