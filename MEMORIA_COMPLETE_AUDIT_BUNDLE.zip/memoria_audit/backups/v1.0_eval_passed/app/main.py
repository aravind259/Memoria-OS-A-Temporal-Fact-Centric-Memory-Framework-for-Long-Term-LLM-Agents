from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

from app.api.chat import router as chat_router
from app.api.memory import router as memory_router

app = FastAPI(
    title="Memory OS",
    version="1.0"
)

app.include_router(chat_router)
app.include_router(memory_router)

# Resolve absolute root workspace directory
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
static_dir = os.path.join(BASE_DIR, "static")

if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/")
def read_root():
    index_path = os.path.join(static_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "Memory OS Backend Server Running"}