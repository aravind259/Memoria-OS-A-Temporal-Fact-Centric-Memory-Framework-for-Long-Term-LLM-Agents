class PromptBuilder:
    """
    Responsible for constructing clean, high-precision prompts for the LLM,
    injecting long-term memories, user persona profile, and multimodal visual context.
    """

    def build(self, memories, user_message: str, persona_summary: str = "", visual_summary: str = ""):
        memory_lines = []
        if memories:
            for memory in memories:
                doc = memory.get('document', '')
                meta = memory.get('metadata', {})
                if meta.get('modality') == 'multimodal' and meta.get('visual_summary'):
                    memory_lines.append(f"- {doc} (Visual Context: {meta.get('visual_summary')})")
                else:
                    memory_lines.append(f"- {doc}")

        memory_block = "\n".join(memory_lines) if memory_lines else "No specific memory retrieved for this turn."

        prompt = f"""SYSTEM:
You are a helpful, direct, and conversational AI assistant with persistent memory.

USER PROFILE:
{persona_summary if persona_summary else "No persistent user profile recorded yet."}

RELEVANT MEMORY:
{memory_block}
"""

        if visual_summary:
            prompt += f"\nATTACHED VISUAL CONTEXT:\n{visual_summary}\n"

        prompt += f"""
CURRENT USER MESSAGE:
{user_message}

INSTRUCTIONS:
- Answer the user's CURRENT question first, directly, naturally, and concisely.
- Use profile/memory ONLY when it is directly relevant to the current user message.
- Never output the profile or memory list itself.
- Never expose raw memory records, IDs, metadata, distances, scores, or profile dumps.
- Never mention that you retrieved memories or database records unless explicitly asked.
- Do not repeat unrelated personal information.
- If the user asks for real-time live data (such as current weather or stock prices) that is unavailable, state so honestly.
"""

        return prompt