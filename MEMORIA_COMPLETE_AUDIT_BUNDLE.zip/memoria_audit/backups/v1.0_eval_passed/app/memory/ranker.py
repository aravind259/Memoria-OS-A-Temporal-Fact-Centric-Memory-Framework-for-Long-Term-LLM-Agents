import re
from app.memory.decay import EbbinghausDecayEngine


def classify_query_intent(query: str) -> str:
    """
    Classifies query intent before memory retrieval into:
      - PERSONAL_MEMORY: Where do I live?, What is my name?
      - PREFERENCE: What programming language do I like?
      - PROJECT: What project am I building?, What is my goal?
      - GENERAL_KNOWLEDGE: What languages are spoken in Hyderabad?, Capital of India, Explain X
      - CURRENT_INFORMATION: Weather, live external info
      - CONVERSATION: Casual greetings (Hello, Hi)
    """
    q_lower = query.lower().strip()

    # 1. CONVERSATION
    greetings = ["hello", "hi", "hey", "good morning", "good afternoon", "greetings"]
    if any(q_lower == g or q_lower.startswith(g + " ") or q_lower.startswith(g + "!") or q_lower.startswith(g + ",") for g in greetings):
        return "CONVERSATION"

    # 2. GENERAL KNOWLEDGE (Languages in city, capital of, public facts)
    gk_phrases = [
        "languages", "language spoken", "languages are spoken", "languages does speak", "languages does speal",
        "capital of", "who invented", "who created", "who discovered", "who was", "who is the president",
        "who is the prime minister", "what is the population", "what is the currency", "explain", "how does", "what causes"
    ]
    if any(phrase in q_lower for phrase in gk_phrases):
        if not any(personal_term in q_lower for personal_term in ["i speak", "i like", "my language", "my preference"]):
            return "GENERAL_KNOWLEDGE"

    # 3. PERSONAL MEMORY
    if any(phrase in q_lower for phrase in ["where do i", "where am i", "my location", "my address", "my home", "where i live"]):
        return "PERSONAL_MEMORY"
    if any(phrase in q_lower for phrase in ["my name", "who am i", "what is my name"]):
        return "PERSONAL_MEMORY"

    # 4. PREFERENCE
    if any(phrase in q_lower for phrase in ["language do i like", "programming language do i", "my favorite language", "what do i like", "what programming language"]):
        return "PREFERENCE"

    # 5. PROJECT
    if any(phrase in q_lower for phrase in ["project am i", "what project", "what am i building", "my project", "my goal"]):
        return "PROJECT"

    # 6. CURRENT INFORMATION
    if "weather" in q_lower:
        return "CURRENT_INFORMATION"

    # Default fallback intent classification
    if any(q_lower.startswith(w) for w in ["what ", "where ", "who ", "how ", "why ", "which "]):
        if any(f" {p} " in f" {q_lower} " or q_lower.endswith(f" {p}") for p in ["i", "my", "me", "mine"]):
            return "PERSONAL_MEMORY"
        return "GENERAL_KNOWLEDGE"

    return "PERSONAL_MEMORY"


class MemoryRanker:
    """
    Ranks and filters memories based on dynamic hybrid relevance scoring:
      - Vector Distance / Similarity (Weight: 0.45)
      - BM25 Lexical Score (Weight: 0.20)
      - Ebbinghaus Retention Decay (Weight: 0.25)
      - Semantic Importance (Weight: 0.10)
    """

    def __init__(self):
        self.decay_engine = EbbinghausDecayEngine()

    def rank(self, memories, query: str = ""):
        if not memories:
            return []

        max_bm25 = max([m.get("bm25_score", 0.0) for m in memories] + [1.0])

        for memory in memories:
            metadata = memory.get("metadata") or {}
            importance = float(metadata.get("importance", 0.5))
            access_count = int(metadata.get("access_count", 0))
            created_at = metadata.get("created_at", "")
            distance = memory.get("distance", 999.0)

            vector_similarity = 1.0 / (1.0 + distance)
            bm25_score = memory.get("bm25_score", 0.0) / max_bm25

            retention_score = self.decay_engine.calculate_retention(
                created_at_iso=created_at,
                importance=importance,
                access_count=access_count
            )

            composite_score = (
                (vector_similarity * 0.45) +
                (bm25_score * 0.20) +
                (retention_score * 0.25) +
                (importance * 0.10)
            )

            memory["retention_score"] = retention_score
            memory["vector_similarity"] = round(vector_similarity, 4)
            memory["score"] = round(composite_score, 4)
            memory["breakdown"] = {
                "vector_weight": round(vector_similarity * 0.45, 4),
                "bm25_weight": round(bm25_score * 0.20, 4),
                "decay_weight": round(retention_score * 0.25, 4),
                "importance_weight": round(importance * 0.10, 4)
            }

        memories.sort(key=lambda m: m["score"], reverse=True)
        return memories

    def filter_by_relevance(self, memories, query: str, min_similarity_threshold: float = 0.45):
        """
        Applies strict relevance & intent gating:
          Distinguishes topic relevance from answer relevance.
          General knowledge queries will NOT let personal background memories dominate retrieval.
        """
        intent = classify_query_intent(query)
        print(f"[Retriever] Query: '{query}'")
        print(f"[Retriever] Intent: {intent}")

        if not memories or not query:
            print(f"[Retriever] Accepted: 0")
            print(f"[Retriever] Rejected: 0")
            return [], memories

        accepted = []
        rejected = []

        if intent in ["CONVERSATION", "GENERAL_KNOWLEDGE"]:
            for m in memories:
                doc = m.get("document", "")
                dist = round(m.get("distance", 999.0), 4)
                similarity = round(1.0 / (1.0 + dist), 4)
                print(f"[Retriever] Candidate: '{doc}'")
                print(f"[Retriever] Similarity: {similarity}")
                print(f"[Retriever] Relevance: LOW")
                print(f"[Retriever] Rejected: 1 ('{doc}')")
                rejected.append(m)

            print(f"[Retriever] Accepted: {len(accepted)}")
            print(f"[Retriever] Rejected: {len(rejected)}")
            return accepted, rejected

        q_lower = query.lower()
        q_tokens = set([t for t in re.findall(r"\b[a-zA-Z]{3,}\b", q_lower) if t not in ["what", "where", "when", "which", "have", "that", "this", "your", "from", "with", "does"]])

        for m in memories:
            doc = m.get("document") or ""
            doc_lower = doc.lower()
            dist = round(m.get("distance", 999.0), 4)
            similarity = round(1.0 / (1.0 + dist), 4)
            bm25 = m.get("bm25_score", 0.0)

            is_relevant = False
            if intent == "PERSONAL_MEMORY":
                if any(w in doc_lower for w in ["live", "moved", "located", "name", "i am", "hyderabad", "bangalore", "seattle", "architect", "pycon", "pittsburgh", "rust"]):
                    is_relevant = True
                elif any(t in doc_lower for t in q_tokens) or (dist <= 0.90 or bm25 > 0.0 or similarity >= 0.40):
                    is_relevant = True
            elif intent == "PREFERENCE" and any(w in doc_lower for w in ["love", "like", "prefer", "python", "javascript", "rust"]):
                is_relevant = True
            elif intent == "PROJECT" and any(w in doc_lower for w in ["building", "project", "memory os", "system"]):
                is_relevant = True
            elif intent == "CURRENT_INFORMATION" and "weather" in q_lower:
                is_relevant = True
            elif any(t in doc_lower for t in q_tokens) or (dist <= 0.90 or bm25 > 0.0 or similarity >= 0.40):
                is_relevant = True

            print(f"[Retriever] Candidate: '{doc}'")
            print(f"[Retriever] Similarity: {similarity}")

            if is_relevant:
                print(f"[Retriever] Relevance: HIGH")
                print(f"[Retriever] Accepted: 1 ('{doc}')")
                accepted.append(m)
            else:
                print(f"[Retriever] Relevance: LOW")
                print(f"[Retriever] Rejected: 1 ('{doc}')")
                rejected.append(m)

        print(f"[Retriever] Accepted: {len(accepted)}")
        print(f"[Retriever] Rejected: {len(rejected)}")
        return accepted, rejected