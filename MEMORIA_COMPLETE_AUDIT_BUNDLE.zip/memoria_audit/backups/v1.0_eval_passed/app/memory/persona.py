import re
from typing import Dict, Any, List, Optional
from app.memory.chroma import get_all_memories


class UserPersonaEngine:
    """
    Enhanced Personalization Engine:
    Dynamically synthesizes user memories into structured persona attributes
    and provides relevance-gated persona context injection.
    """

    def synthesize_persona(self, user_id: str = "default_user") -> Dict[str, Any]:
        memories = get_all_memories(include_superseded=False, user_id=user_id)
        
        categories = {
            "Preference": [],
            "Skill": [],
            "Goal": [],
            "Project": [],
            "Fact": [],
            "Multimodal": []
        }

        name_val = ""
        location_val = ""

        for mem in memories:
            doc = mem.get("document", "")
            meta = mem.get("metadata", {})
            cat = meta.get("category", "Fact")
            modality = meta.get("modality", "text")

            doc_lower = doc.lower()
            
            # Extract structured name if present
            m_name = re.search(r"(?:my name is|i am|name:)\s*([a-zA-Z]+)", doc_lower)
            if m_name and not any(w in m_name.group(1).lower() for w in ["a", "the", "building", "living", "working", "lead", "developer", "architect"]):
                name_val = m_name.group(1).capitalize()

            # Extract structured location if present
            m_loc = re.search(r"(?:i live in|i moved to|located in|location:)\s*([a-zA-Z\s]+)", doc_lower)
            if m_loc:
                location_val = m_loc.group(1).strip().title()

            if modality == "multimodal":
                categories["Multimodal"].append(doc)

            if cat in categories:
                categories[cat].append(doc)
            else:
                categories["Fact"].append(doc)

        summary_text = self._build_persona_summary_text(categories, name_val, location_val)

        return {
            "user_id": user_id,
            "total_active_memories": len(memories),
            "name": name_val,
            "location": location_val,
            "traits": {
                "preferences": categories["Preference"],
                "skills": categories["Skill"],
                "goals": categories["Goal"],
                "projects": categories["Project"],
                "facts": categories["Fact"],
                "multimodal_memories": categories["Multimodal"]
            },
            "summary_text": summary_text
        }

    def get_relevant_persona(self, query: str, user_id: str = "default_user") -> str:
        """
        Returns ONLY relevant persona attributes for the given user query.
        For general knowledge, greetings, or non-personal queries, returns empty string.
        """
        q_lower = query.lower()
        
        # 1. Casual Greetings & General Knowledge -> NO persona injection!
        greetings = ["hello", "hi", "hey", "good morning", "good afternoon", "greetings"]
        if any(q_lower == g or q_lower.startswith(g + " ") or q_lower.startswith(g + "!") for g in greetings):
            return ""

        # General knowledge questions -> NO persona injection!
        if any(p in q_lower for p in ["capital of", "who is", "who was", "what is 2", "where is the eiffel", "how many kilometers"]):
            return ""

        persona = self.synthesize_persona(user_id=user_id)
        relevant_lines = []

        # 2. Name Query
        if "name" in q_lower and any(w in q_lower for w in ["what", "who", "my"]):
            if persona.get("name"):
                relevant_lines.append(f"- Name: {persona['name']}")
            else:
                # Fallback search in raw facts for name
                for f in persona["traits"]["facts"]:
                    if "name" in f.lower() or "i am " in f.lower():
                        relevant_lines.append(f"- Name Fact: {f}")

        # 3. Location Query
        elif "where" in q_lower and any(w in q_lower for w in ["live", "located", "from", "my city"]):
            if persona.get("location"):
                relevant_lines.append(f"- Location: {persona['location']}")
            else:
                for f in persona["traits"]["facts"]:
                    if "live" in f.lower() or "moved" in f.lower():
                        relevant_lines.append(f"- Location Fact: {f}")

        # 4. Programming Language / Preference Query
        elif "programming language" in q_lower or ("language" in q_lower and "like" in q_lower) or "preference" in q_lower:
            if persona["traits"]["preferences"]:
                relevant_lines.append(f"- User Preferences: {'; '.join(persona['traits']['preferences'])}")

        # 5. Project Query
        elif "project" in q_lower or "building" in q_lower or "working on" in q_lower:
            if persona["traits"]["projects"]:
                relevant_lines.append(f"- Active Projects: {'; '.join(persona['traits']['projects'])}")

        # 6. Profile Overview Query ("Tell me something about my profile")
        elif any(p in q_lower for p in ["about my profile", "know about me", "my information", "my profile", "summarize my profile"]):
            return persona.get("summary_text", "")

        return "\n".join(relevant_lines)

    def _build_persona_summary_text(self, categories: Dict[str, List[str]], name: str = "", location: str = "") -> str:
        lines = []
        if name:
            lines.append(f"- User Name: {name}")
        if location:
            lines.append(f"- Current Location: {location}")
        if categories["Preference"]:
            lines.append(f"- User Preferences: {'; '.join(categories['Preference'])}")
        if categories["Skill"]:
            lines.append(f"- User Skills: {'; '.join(categories['Skill'])}")
        if categories["Goal"]:
            lines.append(f"- User Goals: {'; '.join(categories['Goal'])}")
        if categories["Project"]:
            lines.append(f"- Active Projects: {'; '.join(categories['Project'])}")
        if categories["Fact"]:
            lines.append(f"- Background Facts: {'; '.join(categories['Fact'][:5])}")
        
        if not lines:
            return "No persistent user profile recorded yet."
        return "\n".join(lines)
