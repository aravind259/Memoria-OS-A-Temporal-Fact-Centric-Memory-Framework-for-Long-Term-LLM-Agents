from app.embeddings.encoder import get_embedding
from app.memory.chroma import search_memory
from app.memory.reconciler import MemoryReconciler


class DuplicateDetector:
    """
    Detects duplicate, conflicting, or updating memories using embedding proximity + MemoryReconciler.
    """

    def __init__(self):
        self.reconciler = MemoryReconciler()

    def find_duplicate_or_reconcile(
        self,
        memory: str,
        max_distance: float = 1.35
    ) -> dict:
        """
        Searches ChromaDB for nearest active memory matches.
        If distance <= max_distance, runs LLM reconciliation to evaluate relationship.
        """
        embedding = get_embedding(memory)
        results = search_memory(embedding=embedding, n_results=3, include_superseded=False)

        if not results:
            return {"status": "NEW", "match": None}

        for best_match in results:
            distance = best_match.get("distance", 999.0)
            print(f"[DuplicateDetector] Candidate Match: '{best_match['document']}' | Distance: {distance:.4f}")

            if distance <= max_distance:
                reconciliation = self.reconciler.reconcile(
                    new_memory=memory,
                    existing_memory=best_match["document"]
                )
                rel = reconciliation.get("relationship", "DISTINCT")
                if rel in ["SUPERSEDES", "REINFORCES", "CONTRADICTS"]:
                    return {
                        "status": rel,
                        "reconciliation": reconciliation,
                        "match": best_match
                    }

        return {"status": "DISTINCT", "match": None}