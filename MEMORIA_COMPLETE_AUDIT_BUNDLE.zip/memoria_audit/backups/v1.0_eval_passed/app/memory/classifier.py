import json
import re
from app.llm.gemini import ask_gemini


class MemoryClassifier:
    """
    Classifies user messages and distilled facts into semantic memory categories:
    Preference, Goal, Task, Project, Skill, Event, Fact, Conversation.
    Uses LLM zero-shot classification with heuristic fallback.
    """

    CATEGORIES = ["Preference", "Goal", "Task", "Project", "Skill", "Event", "Fact", "Conversation"]

    def classify(self, text: str) -> str:
        # Step 1: Fast Heuristic Rules
        heuristic_cat = self._heuristic_classify(text)
        if heuristic_cat != "Conversation":
            return heuristic_cat

        # Step 2: Zero-shot LLM Classification for ambiguity
        prompt = f"""
Classify the following user message into EXACTLY ONE of these categories:
{", ".join(self.CATEGORIES)}

User Message: "{text}"

Return ONLY a JSON object:
{{"category": "<category_name>"}}
"""
        try:
            response = ask_gemini(prompt)
            cleaned = re.sub(r"^```(?:json)?\s*", "", response.strip(), flags=re.IGNORECASE)
            cleaned = re.sub(r"\s*```$", "", cleaned)
            match = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if match:
                cleaned = match.group(0)
            data = json.loads(cleaned)
            cat = data.get("category", "Conversation")
            if cat in self.CATEGORIES:
                return cat
        except Exception:
            pass

        return heuristic_cat

    def _heuristic_classify(self, text: str) -> str:
        t = text.lower()
        if any(w in t for w in ["favorite", "favourite", "like", "love", "prefer", "hate", "dislike"]):
            return "Preference"
        if any(w in t for w in ["goal", "want to", "dream", "aspire", "plan to", "aim"]):
            return "Goal"
        if any(w in t for w in ["todo", "task", "remind", "must do"]):
            return "Task"
        if any(w in t for w in ["project", "building", "developing", "creating", "coding"]):
            return "Project"
        if any(w in t for w in ["know", "learned", "experience", "skill", "speak", "expert"]):
            return "Skill"
        if any(w in t for w in ["yesterday", "today", "last week", "visited", "went", "met"]):
            return "Event"
        if any(w in t for w in ["live", "age", "name", "born", "work", "located"]):
            return "Fact"
        return "Conversation"