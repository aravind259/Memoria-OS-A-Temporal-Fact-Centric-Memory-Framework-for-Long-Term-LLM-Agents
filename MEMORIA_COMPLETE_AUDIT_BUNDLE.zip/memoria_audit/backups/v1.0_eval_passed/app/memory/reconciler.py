import json
import re
from app.llm.gemini import ask_gemini


class MemoryReconciler:
    """
    Automated Contradiction & Knowledge Graph Update Engine.
    Determines relationships between new incoming facts and existing vector DB memories:
      - SUPERSEDES: New fact updates/replaces an existing fact.
      - CONTRADICTS: New fact conflicts with an existing fact.
      - REINFORCES: New fact confirms an existing fact.
      - DISTINCT: New fact is separate and novel.
    """

    def reconcile(self, new_memory: str, existing_memory: str) -> dict:
        prompt = f"""
You are a Memory Reconciliation Engine for an AI Memory OS.

Compare the NEW incoming memory statement with an EXISTING stored memory statement and determine their semantic relationship.

Existing Memory: "{existing_memory}"
New Memory: "{new_memory}"

Classify their relationship into EXACTLY ONE of the following types:
1. "SUPERSEDES"  : The new memory updates, replaces, or evolves the existing memory (e.g. "User lives in NY" -> "User moved to SF").
2. "REINFORCES"  : The new memory repeats, reinforces, or confirms the existing memory.
3. "CONTRADICTS" : The new memory directly contradicts the existing memory without indicating time progression.
4. "DISTINCT"    : The memories are about different topics or entities despite sharing some context.

Return ONLY valid JSON in this exact structure:
{{
  "relationship": "SUPERSEDES" | "REINFORCES" | "CONTRADICTS" | "DISTINCT",
  "reason": "Brief explanation",
  "action": "SUPERSEDE_OLD" | "INCREMENT_COUNT" | "FLAG_CONTRADICTION" | "STORE_NEW"
}}
"""
        try:
            response = ask_gemini(prompt)
            if not response:
                return {"relationship": "DISTINCT", "action": "STORE_NEW", "reason": "Empty LLM response"}

            cleaned = response.strip()
            cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
            cleaned = re.sub(r"\s*```$", "", cleaned)
            match = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if match:
                cleaned = match.group(0)

            result = json.loads(cleaned)
            return result
        except Exception as e:
            print(f"[MemoryReconciler] Error during reconciliation: {e}")
            return {
                "relationship": "DISTINCT",
                "action": "STORE_NEW",
                "reason": f"Reconciler error: {str(e)}"
            }
