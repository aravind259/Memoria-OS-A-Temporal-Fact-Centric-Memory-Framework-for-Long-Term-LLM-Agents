import sqlite3

conn = sqlite3.connect("llm_cache.db")
c = conn.cursor()
c.execute("DELETE FROM cache WHERE response LIKE '%Hello! How can I help you today?%'")
deleted_1 = c.rowcount
c.execute("DELETE FROM cache WHERE response LIKE '%I''m here to help! What would you like to discuss%'")
deleted_2 = c.rowcount
conn.commit()
print(f"Cleaned {deleted_1 + deleted_2} fallback responses from cache.")
